import { create } from "zustand";

export type NavTab =
  | "dashboard"
  | "futureroom"
  | "missions"
  | "pomodoro"
  | "crm"
  | "income"
  | "portfolio"
  | "skills"
  | "achievements"
  | "calendar"
  | "journal"
  | "goals"
  | "analytics"
  | "aicoach"
  | "visionboard"
  | "quotes"
  | "legacy"
  | "promise"
  | "whyatlas"
  | "settings";

export interface AtlasState {
  // Navigation & UI
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isCmdOpen: boolean;
  setCmdOpen: (open: boolean) => void;
  isLoading: boolean;
  offlineMode: boolean;
  setOfflineMode: (offline: boolean) => void;
  missionCompleteModalOpen: boolean;
  setMissionCompleteModalOpen: (open: boolean) => void;

  // Level Up & Project Details Modals
  levelUpModalOpen: boolean;
  setLevelUpModalOpen: (open: boolean) => void;
  levelUpData: {
    newLevel: number;
    newTitle: string;
    xpAwarded: number;
  } | null;
  setLevelUpData: (data: any) => void;
  projectModalOpen: boolean;
  setProjectModalOpen: (open: boolean) => void;
  selectedProject: any | null;
  setSelectedProject: (project: any | null) => void;

  promiseReminderModalOpen: boolean;
  setPromiseReminderModalOpen: (open: boolean) => void;
  anniversaryModalOpen: boolean;
  setAnniversaryModalOpen: (open: boolean) => void;
  installModalOpen: boolean;
  setInstallModalOpen: (open: boolean) => void;

  // Data State
  profile: any;
  dailyMissions: any[];
  pomodoroSessions: any[];
  focusStats: {
    todayHours: number;
    weeklyHours: number;
    monthlyHours: number;
    totalHours: number;
    longestSessionMinutes: number;
  };
  clients: any[];
  incomeTransactions: any[];
  incomeStats: {
    monthlyIncome: number;
    yearlyIncome: number;
    totalIncome: number;
    avgProjectValue: number;
    highestPayingClient: { name: string; amount: number };
  };
  portfolioProjects: any[];
  portfolioStats: {
    totalProjects: number;
    websitesBuilt: number;
    afterEffectsProgress: number;
  };
  skills: any[];
  achievements: any[];
  calendarDays: any[];
  journalEntries: any[];
  goals: any[];
  visionBoardItems: any[];
  legacyEntries: any[];
  quote: any;
  allQuotes: any[];
  aiCoachAnalysis: any[];

  // The Promise State
  promiseState: {
    id: number;
    isSigned: boolean;
    promiseText: string;
    whoFor: string[];
    whatIfQuit: string;
    whatIfConsistent: string;
    signatureName: string;
    signedDate: string;
  };
  promiseWallMilestones: {
    id: number;
    title: string;
    date: string;
    category: string;
    orderIndex: number;
  }[];

  // Future Room State
  futureRoomData: {
    config: {
      id: number;
      letterFromFuture: string;
      whyIStarted: string;
      costOfQuitting: string[];
      rewardOfConsistency: string[];
      legacyTraits: string[];
      studioItems: {
        id: string;
        name: string;
        category: string;
        imageUrl: string;
        achieved: boolean;
      }[];
    };
    identityStatements: { id: number; statement: string; orderIndex: number }[];
    dreamTimeline: {
      id: number;
      year: number;
      title: string;
      milestones: string[];
      orderIndex: number;
    }[];
  };

  // Actions
  fetchState: () => Promise<void>;
  fetchFutureRoom: () => Promise<void>;
  saveFutureRoomConfig: (configData: any) => Promise<void>;
  addIdentityStatement: (statement: string) => Promise<void>;
  updateIdentityStatement: (id: number, statement: string) => Promise<void>;
  deleteIdentityStatement: (id: number) => Promise<void>;
  addTimelineItem: (year: number, title: string, milestones: string[]) => Promise<void>;
  updateTimelineItem: (id: number, year: number, title: string, milestones: string[]) => Promise<void>;
  deleteTimelineItem: (id: number) => Promise<void>;

  toggleMission: (id: number, completed: boolean) => Promise<boolean>;
  addMission: (category: string, taskName: string) => Promise<void>;
  deleteMission: (id: number) => Promise<void>;
  resetTodayMissions: () => Promise<void>;
  logPomodoro: (
    durationMinutes: number,
    mode: string,
    notes: string,
    skillId?: number
  ) => Promise<void>;
  addClient: (clientData: any) => Promise<void>;
  updateClient: (id: number, clientData: any) => Promise<void>;
  deleteClient: (id: number) => Promise<void>;
  addIncome: (incomeData: any) => Promise<void>;
  deleteIncome: (id: number) => Promise<void>;
  addProject: (projectData: any) => Promise<void>;
  updateProject: (id: number, projectData: any) => Promise<void>;
  deleteProject: (id: number) => Promise<void>;
  addSkillXp: (skillId: number, amount: number) => Promise<void>;
  saveJournalEntry: (entryData: any) => Promise<void>;
  addGoal: (goalData: any) => Promise<void>;
  updateGoal: (id: number, goalData: any) => Promise<void>;
  deleteGoal: (id: number) => Promise<void>;
  addVisionBoardItem: (itemData: any) => Promise<void>;
  updateVisionBoardItem: (id: number, itemData: any) => Promise<void>;
  deleteVisionBoardItem: (id: number) => Promise<void>;
  saveLegacyEntry: (entryData: any) => Promise<void>;
  updateProfile: (profileData: any) => Promise<void>;
  rotateQuote: () => Promise<void>;
  addQuote: (quoteData: any) => Promise<void>;
  savePromise: (data: any) => Promise<void>;
  signPromise: (data: any) => Promise<void>;
  resetPromise: () => Promise<void>;
  addPromiseWallMilestone: (title: string, date: string, category: string) => Promise<void>;
  deletePromiseWallMilestone: (id: number) => Promise<void>;
  resetDemoData: () => Promise<void>;
  resetToEmptyState: () => Promise<void>;
}

export const useAtlasStore = create<AtlasState>((set, get) => ({
  activeTab: "futureroom",
  setActiveTab: (tab) => set({ activeTab: tab }),
  isCmdOpen: false,
  setCmdOpen: (open) => set({ isCmdOpen: open }),
  isLoading: false,
  offlineMode: false,
  setOfflineMode: (offline) => set({ offlineMode: offline }),
  missionCompleteModalOpen: false,
  setMissionCompleteModalOpen: (open) =>
    set({ missionCompleteModalOpen: open }),

  levelUpModalOpen: false,
  setLevelUpModalOpen: (open) => set({ levelUpModalOpen: open }),
  levelUpData: null,
  setLevelUpData: (data) => set({ levelUpData: data }),
  projectModalOpen: false,
  setProjectModalOpen: (open) => set({ projectModalOpen: open }),
  selectedProject: null,
  setSelectedProject: (project) => set({ selectedProject: project }),

  promiseReminderModalOpen: false,
  setPromiseReminderModalOpen: (open) =>
    set({ promiseReminderModalOpen: open }),
  anniversaryModalOpen: false,
  setAnniversaryModalOpen: (open) => set({ anniversaryModalOpen: open }),
  installModalOpen: false,
  setInstallModalOpen: (open) => set({ installModalOpen: open }),

  // Initial data state with Gift Safari defaults (0 progress from nothing)
  promiseState: {
    id: 1,
    isSigned: false,
    promiseText:
      "I promise that I will show up every single day, build my creative portfolio, and honor the vision I have for my family and my future. I refuse to settle for an ordinary life.",
    whoFor: ["Myself", "My family", "My future children", "My dreams"],
    whatIfQuit:
      "I'll remain stuck. I'll never build my business. I'll waste my potential. I'll regret not trying.",
    whatIfConsistent:
      "Financial freedom. Creative confidence. Helping my family. Owning my studio. Working with dream clients. Building a meaningful life.",
    signatureName: "Gift Safari",
    signedDate: "",
  },
  promiseWallMilestones: [],
  profile: {
    name: "Gift Safari",
    title: "Creative Entrepreneur",
    tagline: "Build. Create. Grow. Every Single Day.",
    theme: "dark",
    profilePhotoUrl:
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80",
    currentStreak: 0,
    longestStreak: 0,
    dayOfChallenge: 1,
    totalChallengeDays: 30,
    xp: 0,
    level: 1,
    levelTitle: "Creative Apprentice",
    soundEnabled: true,
    notificationsEnabled: true,
    dailyReminderTime: "08:00",
  },
  dailyMissions: [],
  pomodoroSessions: [],
  focusStats: {
    todayHours: 0,
    weeklyHours: 0,
    monthlyHours: 0,
    totalHours: 0,
    longestSessionMinutes: 0,
  },
  clients: [],
  incomeTransactions: [],
  incomeStats: {
    monthlyIncome: 0,
    yearlyIncome: 0,
    totalIncome: 0,
    avgProjectValue: 0,
    highestPayingClient: { name: "None yet", amount: 0 },
  },
  portfolioProjects: [],
  portfolioStats: {
    totalProjects: 0,
    websitesBuilt: 0,
    afterEffectsProgress: 0,
  },
  skills: [],
  achievements: [],
  calendarDays: [],
  journalEntries: [],
  goals: [],
  visionBoardItems: [],
  legacyEntries: [],
  quote: { quote: "Discipline creates freedom.", author: "Jocko Willink" },
  allQuotes: [],
  aiCoachAnalysis: [],

  // Default Future Room Data
  futureRoomData: {
    config: {
      id: 1,
      letterFromFuture: `Dear Gift,\n\nThank you for refusing to quit.\n\nThe mornings you wanted to stay in bed...\nThe nights you kept practicing...\nThe projects nobody noticed...\n\nThey changed everything.\n\nYou now own the studio you once dreamed about.\nClients respect your work.\nYour family is proud.\n\nKeep going.\nI'm waiting for you.`,
      whyIStarted:
        "Because I refused to settle for an ordinary life. Every day I wake up with the opportunity to build my own future, achieve financial freedom, and create work that inspires the world.",
      costOfQuitting: [
        "The opportunities I lose.",
        "The clients I'll never meet.",
        "The life I'll never live.",
        "The family I won't be able to support.",
        "The dreams I'll abandon.",
      ],
      rewardOfConsistency: [
        "Financial freedom.",
        "Creative confidence.",
        "Better health.",
        "My own office.",
        "Helping my family.",
        "Working with dream clients.",
        "Traveling the world.",
        "Owning my time.",
      ],
      legacyTraits: [
        "Disciplined",
        "Faithful",
        "Kind",
        "Reliable",
        "Creative",
        "Generous",
        "Fearless",
        "Patient",
      ],
      studioItems: [
        {
          id: "desk",
          name: "Custom Walnut Executive Desk",
          category: "Desk",
          imageUrl:
            "https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=800&q=80",
          achieved: true,
        },
        {
          id: "monitor",
          name: "Apple Pro Display XDR Dual",
          category: "Monitor",
          imageUrl:
            "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=800&q=80",
          achieved: true,
        },
        {
          id: "laptop",
          name: "MacBook Pro M3 Max 64GB",
          category: "Laptop",
          imageUrl:
            "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80",
          achieved: true,
        },
        {
          id: "chair",
          name: "Herman Miller Embody Ergonomic Chair",
          category: "Chair",
          imageUrl:
            "https://images.unsplash.com/photo-1580481077494-e3299ac2fef6?auto=format&fit=crop&w=800&q=80",
          achieved: false,
        },
        {
          id: "lighting",
          name: "Cinematic Diffused Softbox Studio Light",
          category: "Lighting",
          imageUrl:
            "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80",
          achieved: false,
        },
        {
          id: "camera",
          name: "Sony FX3 Full-Frame Cinema Setup",
          category: "Camera",
          imageUrl:
            "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80",
          achieved: false,
        },
        {
          id: "inspiration",
          name: "Architectural Floor-to-Ceiling Windows",
          category: "Studio Inspiration",
          imageUrl:
            "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80",
          achieved: false,
        },
      ],
    },
    identityStatements: [
      { id: 1, statement: "I am disciplined.", orderIndex: 1 },
      { id: 2, statement: "I finish what I start.", orderIndex: 2 },
      { id: 3, statement: "I attract great clients.", orderIndex: 3 },
      { id: 4, statement: "I create world-class work.", orderIndex: 4 },
      { id: 5, statement: "I am financially independent.", orderIndex: 5 },
      { id: 6, statement: "I stay consistent.", orderIndex: 6 },
      { id: 7, statement: "I build every day.", orderIndex: 7 },
    ],
    dreamTimeline: [
      {
        id: 1,
        year: 2026,
        title: "Foundation & Velocity",
        milestones: [
          "Master After Effects",
          "Earn first consistent design income",
          "Graduate Diploma",
        ],
        orderIndex: 1,
      },
      {
        id: 2,
        year: 2027,
        title: "Agency & Scale",
        milestones: [
          "Own creative agency",
          "Buy professional equipment",
          "Hire first employee",
        ],
        orderIndex: 2,
      },
      {
        id: 3,
        year: 2028,
        title: "Mastery & Freedom",
        milestones: [
          "Open studio",
          "Reach international clients",
          "Passive income",
        ],
        orderIndex: 3,
      },
    ],
  },

  fetchState: async () => {
    set({ isLoading: true });
    try {
      const res = await fetch("/api/state");
      if (res.ok) {
        const data = await res.json();
        set({
          profile: data.profile || get().profile,
          dailyMissions: data.dailyMissions || [],
          pomodoroSessions: data.pomodoroSessions || [],
          focusStats: data.focusStats || get().focusStats,
          clients: data.clients || [],
          incomeTransactions: data.incomeTransactions || [],
          incomeStats: data.incomeStats || get().incomeStats,
          portfolioProjects: data.portfolioProjects || [],
          portfolioStats: data.portfolioStats || get().portfolioStats,
          skills: data.skills || [],
          achievements: data.achievements || [],
          calendarDays: data.calendarDays || [],
          journalEntries: data.journalEntries || [],
          goals: data.goals || [],
          visionBoardItems: data.visionBoardItems || [],
          legacyEntries: data.legacyEntries || [],
          promiseState: data.promiseState || get().promiseState,
          promiseWallMilestones:
            data.promiseWallMilestones || get().promiseWallMilestones,
          quote: data.quote || get().quote,
          allQuotes: data.allQuotes || [],
          aiCoachAnalysis: data.aiCoachAnalysis || [],
        });
      }
      await get().fetchFutureRoom();
    } catch (e) {
      console.error("Error fetching state:", e);
    } finally {
      set({ isLoading: false });
    }
  },

  fetchFutureRoom: async () => {
    try {
      const res = await fetch("/api/futureroom");
      if (res.ok) {
        const data = await res.json();
        set({
          futureRoomData: {
            config: data.config || get().futureRoomData.config,
            identityStatements:
              data.identityStatements || get().futureRoomData.identityStatements,
            dreamTimeline:
              data.dreamTimeline || get().futureRoomData.dreamTimeline,
          },
        });
      }
    } catch (e) {
      console.error("Error fetching Future Room:", e);
    }
  },

  saveFutureRoomConfig: async (configData) => {
    try {
      await fetch("/api/futureroom", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(configData),
      });
      await get().fetchFutureRoom();
    } catch (e) {
      console.error("Error saving Future Room config:", e);
    }
  },

  addIdentityStatement: async (statement) => {
    await fetch("/api/futureroom/identity", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "add", statement }),
    });
    await get().fetchFutureRoom();
  },

  updateIdentityStatement: async (id, statement) => {
    await fetch("/api/futureroom/identity", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "update", id, statement }),
    });
    await get().fetchFutureRoom();
  },

  deleteIdentityStatement: async (id) => {
    await fetch("/api/futureroom/identity", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", id }),
    });
    await get().fetchFutureRoom();
  },

  addTimelineItem: async (year, title, milestones) => {
    await fetch("/api/futureroom/timeline", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "add", year, title, milestones }),
    });
    await get().fetchFutureRoom();
  },

  updateTimelineItem: async (id, year, title, milestones) => {
    await fetch("/api/futureroom/timeline", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "update", id, year, title, milestones }),
    });
    await get().fetchFutureRoom();
  },

  deleteTimelineItem: async (id) => {
    await fetch("/api/futureroom/timeline", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", id }),
    });
    await get().fetchFutureRoom();
  },

  toggleMission: async (id, completed) => {
    try {
      const res = await fetch("/api/missions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "toggle", id, completed }),
      });
      const data = await res.json();
      await get().fetchState();

      if (data.leveledUp) {
        set({
          levelUpData: {
            newLevel: data.newLevel,
            newTitle: data.newLevelTitle,
            xpAwarded: data.awardedXp,
          },
          levelUpModalOpen: true,
        });
      }

      if (data.allCompleted) {
        set({ missionCompleteModalOpen: true });
        return true;
      }
    } catch (e) {
      console.error("Error toggling mission:", e);
    }
    return false;
  },

  addMission: async (category, taskName) => {
    await fetch("/api/missions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "add", category, taskName }),
    });
    await get().fetchState();
  },

  deleteMission: async (id) => {
    await fetch("/api/missions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", id }),
    });
    await get().fetchState();
  },

  resetTodayMissions: async () => {
    await fetch("/api/missions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "resetToday" }),
    });
    await get().fetchState();
  },

  logPomodoro: async (durationMinutes, mode, notes, skillId) => {
    await fetch("/api/pomodoro", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ durationMinutes, mode, notes, skillId }),
    });
    await get().fetchState();
  },

  addClient: async (clientData) => {
    await fetch("/api/clients", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(clientData),
    });
    await get().fetchState();
  },

  updateClient: async (id, clientData) => {
    await fetch(`/api/clients/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(clientData),
    });
    await get().fetchState();
  },

  deleteClient: async (id) => {
    await fetch(`/api/clients/${id}`, {
      method: "DELETE",
    });
    await get().fetchState();
  },

  addIncome: async (incomeData) => {
    await fetch("/api/income", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(incomeData),
    });
    await get().fetchState();
  },

  deleteIncome: async (id) => {
    await fetch(`/api/income/${id}`, {
      method: "DELETE",
    });
    await get().fetchState();
  },

  addProject: async (projectData) => {
    await fetch("/api/portfolio", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(projectData),
    });
    await get().fetchState();
  },

  updateProject: async (id, projectData) => {
    await fetch(`/api/portfolio/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(projectData),
    });
    await get().fetchState();
  },

  deleteProject: async (id) => {
    await fetch(`/api/portfolio/${id}`, {
      method: "DELETE",
    });
    await get().fetchState();
  },

  addSkillXp: async (skillId, amount) => {
    await fetch("/api/skills/xp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ skillId, amount }),
    });
    await get().fetchState();
  },

  saveJournalEntry: async (entryData) => {
    await fetch("/api/journal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(entryData),
    });
    await get().fetchState();
  },

  addGoal: async (goalData) => {
    await fetch("/api/goals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(goalData),
    });
    await get().fetchState();
  },

  updateGoal: async (id, goalData) => {
    await fetch(`/api/goals/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(goalData),
    });
    await get().fetchState();
  },

  deleteGoal: async (id) => {
    await fetch(`/api/goals/${id}`, {
      method: "DELETE",
    });
    await get().fetchState();
  },

  addVisionBoardItem: async (itemData) => {
    await fetch("/api/vision-board", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(itemData),
    });
    await get().fetchState();
  },

  updateVisionBoardItem: async (id, itemData) => {
    await fetch(`/api/vision-board/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(itemData),
    });
    await get().fetchState();
  },

  deleteVisionBoardItem: async (id) => {
    await fetch(`/api/vision-board/${id}`, {
      method: "DELETE",
    });
    await get().fetchState();
  },

  saveLegacyEntry: async (entryData) => {
    await fetch("/api/legacy", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(entryData),
    });
    await get().fetchState();
  },

  updateProfile: async (profileData) => {
    await fetch("/api/profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(profileData),
    });
    await get().fetchState();
  },

  rotateQuote: async () => {
    const res = await fetch("/api/quotes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "rotate" }),
    });
    if (res.ok) {
      await get().fetchState();
    }
  },

  addQuote: async (quoteData) => {
    await fetch("/api/quotes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "add", ...quoteData }),
    });
    await get().fetchState();
  },

  savePromise: async (data) => {
    await fetch("/api/promise", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "update", ...data }),
    });
    await get().fetchState();
  },

  signPromise: async (data) => {
    await fetch("/api/promise", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "sign", ...data }),
    });
    await get().fetchState();
  },

  resetPromise: async () => {
    await fetch("/api/promise", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "reset" }),
    });
    await get().fetchState();
  },

  addPromiseWallMilestone: async (title, date, category) => {
    await fetch("/api/promise/wall", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "add", title, date, category }),
    });
    await get().fetchState();
  },

  deletePromiseWallMilestone: async (id) => {
    await fetch("/api/promise/wall", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", id }),
    });
    await get().fetchState();
  },

  resetDemoData: async () => {
    await fetch("/api/reset-data", {
      method: "POST",
    });
    await get().fetchState();
  },

  resetToEmptyState: async () => {
    await fetch("/api/reset-data?mode=empty", {
      method: "POST",
    });
    await get().fetchState();
  },
}));
