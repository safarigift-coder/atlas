// Local onboarding storage for ATLAS OS multi-user support
// Stores onboarding completion state and local profile backup

export interface AtlasOnboardingData {
  firstName: string;
  lastName: string;
  preferredName: string;
  profilePhotoUrl?: string;
  birthday?: string;
  country: string;
  city?: string;
  occupation: string;
  journey: string[]; // e.g. ["Designer", "Creative Entrepreneur"]
  skills: { name: string; level: string }[];
  goals: string[];
  visionText: string;
  promiseText: string;
  promiseSignature: string;
  preferences: {
    theme: "dark" | "light" | "system";
    reminderTime: string;
    startOfWeek: "Monday" | "Sunday";
    language: string;
    notifications: boolean;
  };
}

const ONBOARDING_KEY = "atlas_os_onboarding_completed_v1";
const DATA_KEY = "atlas_os_onboarding_data_v1";

export function isLocalOnboardingCompleted(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return localStorage.getItem(ONBOARDING_KEY) === "true";
  } catch (e) {
    return false;
  }
}

export function getLocalOnboardingData(): AtlasOnboardingData | null {
  if (typeof window === "undefined") return null;
  try {
    const item = localStorage.getItem(DATA_KEY);
    return item ? JSON.parse(item) : null;
  } catch (e) {
    return null;
  }
}

export function saveLocalOnboardingData(data: AtlasOnboardingData): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(ONBOARDING_KEY, "true");
    localStorage.setItem(DATA_KEY, JSON.stringify(data));
  } catch (e) {
    console.error("Failed to save local onboarding data:", e);
  }
}

export function clearLocalOnboarding(): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(ONBOARDING_KEY);
    localStorage.removeItem(DATA_KEY);
  } catch (e) {
    console.error("Failed to clear local onboarding data:", e);
  }
}
