// Procedural Web Audio Ambient Soundscapes for ATLAS OS Future Room
// Generates Rain, Forest, Cafe, Lo-fi, and Ocean soothing soundscapes

export type AmbientTrack = "rain" | "forest" | "cafe" | "lofi" | "ocean" | "off";

class AmbientAudioPlayer {
  private ctx: AudioContext | null = null;
  private activeTrack: AmbientTrack = "off";
  private sourceNode: any = null;
  private gainNode: GainNode | null = null;
  private intervalId: any = null;

  private getCtx(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public stop() {
    this.activeTrack = "off";
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    if (this.gainNode && this.ctx) {
      try {
        this.gainNode.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.5);
      } catch (e) {}
    }
    setTimeout(() => {
      if (this.sourceNode) {
        try {
          this.sourceNode.stop();
          this.sourceNode.disconnect();
        } catch (e) {}
        this.sourceNode = null;
      }
    }, 600);
  }

  public play(track: AmbientTrack, volume: number = 0.15) {
    if (track === "off") {
      this.stop();
      return;
    }
    this.stop();
    this.activeTrack = track;

    const ctx = this.getCtx();
    if (!ctx) return;

    try {
      if (track === "rain" || track === "ocean" || track === "forest") {
        // Pink / Brown noise rain/ocean generator
        const bufferSize = ctx.sampleRate * 4;
        const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        let b0 = 0,
          b1 = 0,
          b2 = 0,
          b3 = 0,
          b4 = 0,
          b5 = 0,
          b6 = 0;

        for (let i = 0; i < bufferSize; i++) {
          const white = Math.random() * 2 - 1;
          b0 = 0.99886 * b0 + white * 0.0555179;
          b1 = 0.99332 * b1 + white * 0.0750759;
          b2 = 0.969 * b2 + white * 0.153852;
          b3 = 0.8665 * b3 + white * 0.3104856;
          b4 = 0.55 * b4 + white * 0.5329522;
          b5 = -0.7616 * b5 - white * 0.016898;
          output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
          output[i] *= 0.11;
          b6 = white * 0.115926;
        }

        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const filter = ctx.createBiquadFilter();
        if (track === "rain") {
          filter.type = "lowpass";
          filter.frequency.setValueAtTime(1000, ctx.currentTime);
        } else if (track === "ocean") {
          filter.type = "lowpass";
          filter.frequency.setValueAtTime(450, ctx.currentTime);
          // Wave modulation
          this.intervalId = setInterval(() => {
            if (this.activeTrack !== "ocean" || !this.ctx) return;
            const now = this.ctx.currentTime;
            filter.frequency.linearRampToValueAtTime(
              250 + Math.random() * 400,
              now + 3
            );
          }, 4000);
        } else {
          filter.type = "bandpass";
          filter.frequency.setValueAtTime(1400, ctx.currentTime);
          filter.Q.setValueAtTime(0.7, ctx.currentTime);
        }

        const gain = ctx.createGain();
        gain.gain.setValueAtTime(volume, ctx.currentTime);

        whiteNoise.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        whiteNoise.start();
        this.sourceNode = whiteNoise;
        this.gainNode = gain;
      } else {
        // Cafe / Lofi warm chord drone
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();

        osc.type = "sine";
        osc.frequency.setValueAtTime(track === "lofi" ? 220 : 180, ctx.currentTime);

        filter.type = "lowpass";
        filter.frequency.setValueAtTime(600, ctx.currentTime);

        gain.gain.setValueAtTime(volume * 0.6, ctx.currentTime);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        this.sourceNode = osc;
        this.gainNode = gain;
      }
    } catch (e) {
      // Ignore Web Audio context blocks
    }
  }

  public getActiveTrack(): AmbientTrack {
    return this.activeTrack;
  }
}

export const ambientAudioPlayer = new AmbientAudioPlayer();
