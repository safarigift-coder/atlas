export interface RpgLevelInfo {
  level: number;
  levelTitle: string;
  currentXp: number;
  nextLevelXp: number;
  progressPercent: number;
}

export function getRpgLevelInfo(xp: number): RpgLevelInfo {
  let level = 1;
  let levelTitle = "Creative Apprentice";
  let nextLevelXp = 1000;

  if (xp >= 20000) {
    level = Math.min(100 + Math.floor((xp - 20000) / 1000), 100);
    levelTitle = "Creative Legend";
    nextLevelXp = 50000;
  } else if (xp >= 12000) {
    level = 70 + Math.floor(((xp - 12000) / 8000) * 30);
    levelTitle = "Creative Master";
    nextLevelXp = 20000;
  } else if (xp >= 6000) {
    level = 40 + Math.floor(((xp - 6000) / 6000) * 30);
    levelTitle = "Creative Expert";
    nextLevelXp = 12000;
  } else if (xp >= 2500) {
    level = 20 + Math.floor(((xp - 2500) / 3500) * 20);
    levelTitle = "Creative Professional";
    nextLevelXp = 6000;
  } else if (xp >= 1000) {
    level = 10 + Math.floor(((xp - 1000) / 1500) * 10);
    levelTitle = "Creative Explorer";
    nextLevelXp = 2500;
  } else {
    level = 1 + Math.floor((xp / 1000) * 9);
    levelTitle = "Creative Apprentice";
    nextLevelXp = 1000;
  }

  const prevThreshold =
    levelTitle === "Creative Legend"
      ? 20000
      : levelTitle === "Creative Master"
      ? 12000
      : levelTitle === "Creative Expert"
      ? 6000
      : levelTitle === "Creative Professional"
      ? 2500
      : levelTitle === "Creative Explorer"
      ? 1000
      : 0;

  const range = nextLevelXp - prevThreshold;
  const progress = Math.min(
    100,
    Math.max(0, Math.round(((xp - prevThreshold) / (range || 1)) * 100))
  );

  return {
    level,
    levelTitle,
    currentXp: xp,
    nextLevelXp,
    progressPercent: progress,
  };
}

export function getTaskXpReward(taskName: string): number {
  const lower = taskName.toLowerCase();
  if (lower.includes("make bed") || lower.includes("made bed")) return 10;
  if (lower.includes("exercise") || lower.includes("workout")) return 20;
  if (lower.includes("deep work") || lower.includes("focus")) return 100;
  if (lower.includes("portfolio")) return 150;
  if (lower.includes("client outreach") || lower.includes("contacted"))
    return 200;
  if (lower.includes("website") || lower.includes("dev")) return 500;
  if (lower.includes("paid client") || lower.includes("invoice")) return 1000;
  return 50;
}
