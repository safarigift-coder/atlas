import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  real,
} from "drizzle-orm/pg-core";

export const userProfile = pgTable("user_profile", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("Creative Entrepreneur"),
  firstName: text("first_name").notNull().default("Creator"),
  lastName: text("last_name").notNull().default(""),
  preferredName: text("preferred_name").notNull().default("Creator"),
  title: text("title").notNull().default("Creative Entrepreneur"),
  tagline: text("tagline").notNull().default("Build. Create. Grow. Every Single Day."),
  theme: text("theme").notNull().default("dark"), // "dark" | "light" | "system"
  profilePhotoUrl: text("profile_photo_url").notNull().default("https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80"),
  birthday: text("birthday").default(""),
  country: text("country").default("Global"),
  city: text("city").default(""),
  occupation: text("occupation").notNull().default("Creative Entrepreneur"),
  journey: text("journey").notNull().default(JSON.stringify(["Creative Entrepreneur"])),
  startOfWeek: text("start_of_week").notNull().default("Monday"),
  language: text("language").notNull().default("English"),
  onboardingCompleted: boolean("onboarding_completed").notNull().default(false),
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  dayOfChallenge: integer("day_of_challenge").notNull().default(1),
  totalChallengeDays: integer("total_challenge_days").notNull().default(30),
  xp: integer("xp").notNull().default(0), // Total RPG XP
  level: integer("level").notNull().default(1), // RPG Level
  levelTitle: text("level_title").notNull().default("Creative Apprentice"),
  soundEnabled: boolean("sound_enabled").notNull().default(true),
  notificationsEnabled: boolean("notifications_enabled").notNull().default(true),
  dailyReminderTime: text("daily_reminder_time").notNull().default("08:00"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const dailyMissions = pgTable("daily_missions", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD
  category: text("category").notNull(), // "morning" | "creative" | "business" | "night"
  taskName: text("task_name").notNull(),
  completed: boolean("completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
  orderIndex: integer("order_index").notNull().default(0),
  xpReward: integer("xp_reward").notNull().default(50),
});

export const pomodoroSessions = pgTable("pomodoro_sessions", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD
  durationMinutes: integer("duration_minutes").notNull(),
  mode: text("mode").notNull(), // "25/5" | "50/10" | "90min" | "custom" | "Deep Work"
  notes: text("notes"),
  interruptions: integer("interruptions").notNull().default(0),
  completedAt: timestamp("completed_at").defaultNow(),
});

export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  business: text("business").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  services: text("services").notNull(),
  price: integer("price").notNull(), // USD
  deadline: text("deadline").notNull(), // YYYY-MM-DD
  status: text("status").notNull(), // "Lead" | "Contacted" | "Meeting" | "Proposal Sent" | "Negotiation" | "Working" | "Revision" | "Completed" | "Paid"
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const incomeTransactions = pgTable("income_transactions", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD
  clientId: integer("client_id"),
  clientName: text("client_name").notNull(),
  amount: integer("amount").notNull(), // USD
  service: text("service").notNull(),
  status: text("status").notNull(), // "Paid" | "Pending"
  createdAt: timestamp("created_at").defaultNow(),
});

export const portfolioProjects = pgTable("portfolio_projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // "Branding" | "Logos" | "Posters" | "Flyers" | "Websites" | "UI" | "UI Design" | "Video Editing" | "Video" | "Motion Graphics" | "Motion" | "Photography"
  thumbnail: text("thumbnail").notNull(),
  description: text("description").notNull(),
  toolsUsed: text("tools_used").notNull(), // comma separated
  completionDate: text("completion_date").notNull(), // YYYY-MM-DD
  client: text("client").notNull(),
  behanceLink: text("behance_link").notNull().default("https://behance.net"),
  liveWebsite: text("live_website").notNull().default("https://example.com"),
  status: text("status").notNull().default("Completed"), // "Completed" | "In Progress" | "Concept"
  createdAt: timestamp("created_at").defaultNow(),
});

export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(), // "Design" | "Video & Motion" | "Tech" | "Business"
  currentXp: integer("current_xp").notNull().default(0), // 0 - 1000 per level
  level: text("level").notNull().default("Creative Explorer"), // "Creative Beginner" | "Creative Explorer" | "Creative Professional" | "Creative Expert" | "Creative Master" | "Legend"
  levelIndex: integer("level_index").notNull().default(2), // 1 to 6
  iconName: text("icon_name").notNull().default("Sparkles"),
  tasksCompletedCount: integer("tasks_completed_count").notNull().default(0),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  badgeId: text("badge_id").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  category: text("category").notNull(), // "streak" | "income" | "creative" | "discipline"
  unlocked: boolean("unlocked").notNull().default(false),
  unlockedAt: text("unlocked_at"),
});

export const calendarDays = pgTable("calendar_days", {
  id: serial("id").primaryKey(),
  date: text("date").notNull().unique(), // YYYY-MM-DD
  status: text("status").notNull().default("Green"), // "Green" | "Yellow" | "Red" | "Future"
  hoursFocused: real("hours_focused").notNull().default(0),
  mood: text("mood").notNull().default("🔥 Unstoppable"), // "🔥 Unstoppable" | "⚡ Focused" | "🧘 Steady" | "🌊 Tired"
  projectsCompleted: integer("projects_completed").notNull().default(0),
  incomeEarned: integer("income_earned").notNull().default(0),
  notes: text("notes"),
});

export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  date: text("date").notNull().unique(), // YYYY-MM-DD
  qCompleted: text("q_completed").notNull().default(""),
  qChallenged: text("q_challenged").notNull().default(""),
  qLearned: text("q_learned").notNull().default(""),
  qGrateful: text("q_grateful").notNull().default(""),
  qTomorrow: text("q_tomorrow").notNull().default(""),
  contentMarkdown: text("content_markdown").notNull().default(""),
  mood: text("mood").notNull().default("🔥 Unstoppable"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // "Finance" | "Skill" | "Portfolio" | "Career" | "Education"
  targetValue: integer("target_value").notNull().default(100),
  currentValue: integer("current_value").notNull().default(0),
  unit: text("unit").notNull().default("%"),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const visionBoardItems = pgTable("vision_board_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // "Dream Workspace" | "Dream Laptop" | "Dream Camera" | "Dream Office" | "Dream House" | "Dream Car" | "Dream Lifestyle" | "Travel Goals" | "Family Goals" | "Health Goals" | "Creative Goals" | "Financial Goals" | "Personal Growth"
  imageUrl: text("image_url").notNull(),
  caption: text("caption").notNull(),
  targetDate: text("target_date").notNull(),
  progress: integer("progress").notNull().default(40), // 0 to 100
  achieved: boolean("achieved").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const motivationalQuotes = pgTable("motivational_quotes", {
  id: serial("id").primaryKey(),
  quote: text("quote").notNull(),
  author: text("author").notNull().default("ATLAS OS"),
  activeForToday: boolean("active_for_today").notNull().default(false),
});

export const legacyEntries = pgTable("legacy_entries", {
  id: serial("id").primaryKey(),
  date: text("date").notNull().unique(), // YYYY-MM-DD
  meaningful: boolean("meaningful").notNull().default(true),
  reflection: text("reflection").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const futureRoomConfig = pgTable("future_room_config", {
  id: serial("id").primaryKey(),
  letterFromFuture: text("letter_from_future").notNull().default(`Dear Gift,\n\nThank you for refusing to quit.\n\nThe mornings you wanted to stay in bed...\nThe nights you kept practicing...\nThe projects nobody noticed...\n\nThey changed everything.\n\nYou now own the studio you once dreamed about.\nClients respect your work.\nYour family is proud.\n\nKeep going.\nI'm waiting for you.`),
  whyIStarted: text("why_i_started").notNull().default("Because I refused to settle for an ordinary life. Every day I wake up with the opportunity to build my own future, achieve financial freedom, and create work that inspires the world."),
  costOfQuitting: text("cost_of_quitting").notNull().default(JSON.stringify([
    "The opportunities I lose.",
    "The clients I'll never meet.",
    "The life I'll never live.",
    "The family I won't be able to support.",
    "The dreams I'll abandon."
  ])),
  rewardOfConsistency: text("reward_of_consistency").notNull().default(JSON.stringify([
    "Financial freedom.",
    "Creative confidence.",
    "Better health.",
    "My own office.",
    "Helping my family.",
    "Working with dream clients.",
    "Traveling the world.",
    "Owning my time."
  ])),
  legacyTraits: text("legacy_traits").notNull().default(JSON.stringify([
    "Disciplined",
    "Faithful",
    "Kind",
    "Reliable",
    "Creative",
    "Generous",
    "Fearless",
    "Patient"
  ])),
  studioItems: text("studio_items").notNull().default(JSON.stringify([
    { id: "desk", name: "Custom Walnut Executive Desk", category: "Desk", imageUrl: "https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=800&q=80", achieved: true },
    { id: "monitor", name: "Apple Pro Display XDR Dual", category: "Monitor", imageUrl: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=800&q=80", achieved: true },
    { id: "laptop", name: "MacBook Pro M3 Max 64GB", category: "Laptop", imageUrl: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80", achieved: true },
    { id: "chair", name: "Herman Miller Embody Ergonomic Chair", category: "Chair", imageUrl: "https://images.unsplash.com/photo-1580481077494-e3299ac2fef6?auto=format&fit=crop&w=800&q=80", achieved: false },
    { id: "lighting", name: "Cinematic Diffused Softbox Studio Light", category: "Lighting", imageUrl: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80", achieved: false },
    { id: "camera", name: "Sony FX3 Full-Frame Cinema Setup", category: "Camera", imageUrl: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80", achieved: false },
    { id: "inspiration", name: "Architectural Floor-to-Ceiling Windows", category: "Studio Inspiration", imageUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80", achieved: false }
  ])),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const identityStatements = pgTable("identity_statements", {
  id: serial("id").primaryKey(),
  statement: text("statement").notNull(),
  orderIndex: integer("order_index").notNull().default(0),
});

export const dreamTimeline = pgTable("dream_timeline", {
  id: serial("id").primaryKey(),
  year: integer("year").notNull(),
  title: text("title").notNull(),
  milestones: text("milestones").notNull(), // JSON string array
  orderIndex: integer("order_index").notNull().default(0),
});

export const userPromise = pgTable("user_promise", {
  id: serial("id").primaryKey(),
  isSigned: boolean("is_signed").notNull().default(false),
  promiseText: text("promise_text").notNull().default(
    "I promise that I will show up every single day, build my creative portfolio, and honor the vision I have for my family and my future. I refuse to settle for an ordinary life."
  ),
  whoFor: text("who_for").notNull().default(
    JSON.stringify(["Myself", "My family", "My future children", "My dreams"])
  ),
  whatIfQuit: text("what_if_quit").notNull().default(
    "I'll remain stuck. I'll never build my business. I'll waste my potential. I'll regret not trying."
  ),
  whatIfConsistent: text("what_if_consistent").notNull().default(
    "Financial freedom. Creative confidence. Helping my family. Owning my studio. Working with dream clients. Building a meaningful life."
  ),
  signatureName: text("signature_name").notNull().default(""),
  signedDate: text("signed_date").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const promiseWallMilestones = pgTable("promise_wall_milestones", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  category: text("category").notNull().default("milestone"), // "promise" | "streak" | "income" | "creative" | "milestone"
  orderIndex: integer("order_index").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});
