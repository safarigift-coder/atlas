import { ensureSeedData } from "./seed";

let seedPromise: Promise<void> | null = null;

export async function checkAndSeed() {
  if (!seedPromise) {
    seedPromise = ensureSeedData().catch((err) => {
      console.error("Error in ensureSeedData:", err);
      seedPromise = null;
    });
  }
  return seedPromise;
}
