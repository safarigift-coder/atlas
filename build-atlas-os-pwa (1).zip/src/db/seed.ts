import { db } from "./index";
import {
  userProfile,
  dailyMissions,
  pomodoroSessions,
  clients,
  incomeTransactions,
  portfolioProjects,
  skills,
  achievements,
  calendarDays,
  journalEntries,
  goals,
  visionBoardItems,
  motivationalQuotes,
  legacyEntries,
  futureRoomConfig,
  identityStatements,
  dreamTimeline,
  userPromise,
  promiseWallMilestones,
} from "./schema";
import { count } from "drizzle-orm";

function getRecentDateStr(daysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

// ============================================================================
// CLEAN NEW USER FROM NOTHING (0 progress across all metrics)
// ============================================================================
export async function ensureSeedData() {
  const profileCount = await db.select({ c: count() }).from(userProfile);
  if (profileCount[0].c > 0) {
    return; // Already seeded
  }

  const todayStr = getRecentDateStr(0);

  // 1. User Profile - Clean new user (0 streak, 0 XP, onboardingCompleted: false)
  await db.insert(userProfile).values({
    name: "Creator",
    firstName: "",
    lastName: "",
    preferredName: "Creator",
    title: "Creative Entrepreneur",
    tagline: "Build. Create. Grow. Every Single Day.",
    theme: "dark",
    profilePhotoUrl:
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80",
    occupation: "Creative Entrepreneur",
    journey: JSON.stringify(["Creative Entrepreneur"]),
    startOfWeek: "Monday",
    language: "English",
    onboardingCompleted: false,
    currentStreak: 0,
    longestStreak: 0,
    dayOfChallenge: 1,
    totalChallengeDays: 30,
    xp: 0,
    level: 1,
    levelTitle: "Creative Apprentice",
    soundEnabled: true,
    notificationsEnabled: true,
    dailyReminderTime: "08:00",
  });

  // 2. Motivational Quotes
  const quotes = [
    {
      quote: "Discipline creates freedom.",
      author: "Jocko Willink",
      activeForToday: true,
    },
    {
      quote: "Never miss two days in a row.",
      author: "James Clear",
      activeForToday: false,
    },
    {
      quote: "Professionals show up.",
      author: "Steven Pressfield",
      activeForToday: false,
    },
    {
      quote: "Small actions. Massive results.",
      author: "ATLAS OS",
      activeForToday: false,
    },
    {
      quote: "Consistency beats motivation.",
      author: "Naval Ravikant",
      activeForToday: false,
    },
    {
      quote: "Work until your portfolio introduces you.",
      author: "Creative Wisdom",
      activeForToday: false,
    },
    {
      quote: "Nobody owes you success.",
      author: "Gift Safari",
      activeForToday: false,
    },
    {
      quote: "Action cures fear.",
      author: "David J. Schwartz",
      activeForToday: false,
    },
    { quote: "Stay locked in.", author: "ATLAS OS", activeForToday: false },
  ];
  await db.insert(motivationalQuotes).values(quotes);

  // 3. Daily Missions for Today (Clean checklist: 0/14 completed, 0% progress)
  const defaultMissions = [
    // Morning
    {
      date: todayStr,
      category: "morning",
      taskName: "Made Bed",
      completed: false,
      orderIndex: 1,
      xpReward: 10,
    },
    {
      date: todayStr,
      category: "morning",
      taskName: "Exercised",
      completed: false,
      orderIndex: 2,
      xpReward: 20,
    },
    {
      date: todayStr,
      category: "morning",
      taskName: "Prayed / Reflected",
      completed: false,
      orderIndex: 3,
      xpReward: 20,
    },
    {
      date: todayStr,
      category: "morning",
      taskName: "Planned Day",
      completed: false,
      orderIndex: 4,
      xpReward: 20,
    },
    // Creative
    {
      date: todayStr,
      category: "creative",
      taskName: "Graphic Design",
      completed: false,
      orderIndex: 5,
      xpReward: 100,
    },
    {
      date: todayStr,
      category: "creative",
      taskName: "Website Development",
      completed: false,
      orderIndex: 6,
      xpReward: 500,
    },
    {
      date: todayStr,
      category: "creative",
      taskName: "After Effects Practice",
      completed: false,
      orderIndex: 7,
      xpReward: 100,
    },
    {
      date: todayStr,
      category: "creative",
      taskName: "Portfolio Project",
      completed: false,
      orderIndex: 8,
      xpReward: 150,
    },
    // Business
    {
      date: todayStr,
      category: "business",
      taskName: "Contacted 5 Clients",
      completed: false,
      orderIndex: 9,
      xpReward: 200,
    },
    {
      date: todayStr,
      category: "business",
      taskName: "Posted My Work",
      completed: false,
      orderIndex: 10,
      xpReward: 50,
    },
    {
      date: todayStr,
      category: "business",
      taskName: "Learned Marketing",
      completed: false,
      orderIndex: 11,
      xpReward: 50,
    },
    // Night
    {
      date: todayStr,
      category: "night",
      taskName: "Planned Tomorrow",
      completed: false,
      orderIndex: 12,
      xpReward: 20,
    },
    {
      date: todayStr,
      category: "night",
      taskName: "Journal Entry",
      completed: false,
      orderIndex: 13,
      xpReward: 50,
    },
    {
      date: todayStr,
      category: "night",
      taskName: "Screen Time Under 1 Hour",
      completed: false,
      orderIndex: 14,
      xpReward: 50,
    },
  ];
  await db.insert(dailyMissions).values(defaultMissions);

  // 4. Pomodoro Focus Sessions (0 sessions logged)
  // [No insert into pomodoroSessions]

  // 5. CRM Clients (0 CRM clients -> EmptyState: "No Clients Yet — The first client changes everything.")
  // [No insert into clients]

  // 6. Income Transactions (0 income -> EmptyState: "No Income Tracked Yet — Your value compounds with every rep.")
  // [No insert into incomeTransactions]

  // 7. Portfolio Projects (0 projects -> EmptyState: "No Portfolio — Every masterpiece begins with one project.")
  // [No insert into portfolioProjects]

  // 8. Skill Tree (10 Core Skills starting at 0 XP / Beginner level)
  const sampleSkills = [
    {
      name: "Photoshop",
      category: "Design",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "Image",
      tasksCompletedCount: 0,
    },
    {
      name: "Illustrator",
      category: "Design",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "PenTool",
      tasksCompletedCount: 0,
    },
    {
      name: "After Effects",
      category: "Video & Motion",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "Video",
      tasksCompletedCount: 0,
    },
    {
      name: "Premiere Pro",
      category: "Video & Motion",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "Film",
      tasksCompletedCount: 0,
    },
    {
      name: "Lightroom",
      category: "Design",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "Camera",
      tasksCompletedCount: 0,
    },
    {
      name: "Web Development",
      category: "Tech",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "Code",
      tasksCompletedCount: 0,
    },
    {
      name: "UI Design",
      category: "Design",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "Layout",
      tasksCompletedCount: 0,
    },
    {
      name: "Motion Design",
      category: "Video & Motion",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "Activity",
      tasksCompletedCount: 0,
    },
    {
      name: "Marketing",
      category: "Business",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "TrendingUp",
      tasksCompletedCount: 0,
    },
    {
      name: "Sales",
      category: "Business",
      currentXp: 0,
      level: "Creative Beginner",
      levelIndex: 1,
      iconName: "DollarSign",
      tasksCompletedCount: 0,
    },
  ];
  await db.insert(skills).values(sampleSkills);

  // 9. Achievements / Trophy Room (All 9 badges locked)
  const sampleAchievements = [
    {
      badgeId: "streak_7",
      title: "🔥 7-Day Streak",
      description: "Completed all daily missions for 7 consecutive days.",
      icon: "Flame",
      category: "streak",
      unlocked: false,
      unlockedAt: null,
    },
    {
      badgeId: "streak_14",
      title: "⚡ 14-Day Streak",
      description: "Showed up every single day for 2 weeks straight.",
      icon: "Zap",
      category: "streak",
      unlocked: false,
      unlockedAt: null,
    },
    {
      badgeId: "lockin_30",
      title: "🚀 30-Day Lock-In",
      description: "Complete the 30-day challenge without missing a day.",
      icon: "Rocket",
      category: "streak",
      unlocked: false,
      unlockedAt: null,
    },
    {
      badgeId: "first_client",
      title: "💼 First Client",
      description: "Signed your very first paying client.",
      icon: "Briefcase",
      category: "income",
      unlocked: false,
      unlockedAt: null,
    },
    {
      badgeId: "first_100",
      title: "💰 First $100 Earned",
      description:
        "Earned your first $100 from your creative skills.",
      icon: "DollarSign",
      category: "income",
      unlocked: false,
      unlockedAt: null,
    },
    {
      badgeId: "designs_50",
      title: "🎨 50 Designs",
      description: "Created and shipped over 50 design assets.",
      icon: "Palette",
      category: "creative",
      unlocked: false,
      unlockedAt: null,
    },
    {
      badgeId: "first_website",
      title: "🌐 First Website",
      description:
        "Built and deployed a production client website.",
      icon: "Globe",
      category: "creative",
      unlocked: false,
      unlockedAt: null,
    },
    {
      badgeId: "first_animation",
      title: "🎬 First Animation",
      description:
        "Rendered your first motion graphics piece in After Effects.",
      icon: "Film",
      category: "creative",
      unlocked: false,
      unlockedAt: null,
    },
    {
      badgeId: "one_month_consistent",
      title: "🏆 One Month Consistent",
      description:
        "One full month of daily discipline and creative growth.",
      icon: "Trophy",
      category: "discipline",
      unlocked: false,
      unlockedAt: null,
    },
  ];
  await db.insert(achievements).values(sampleAchievements);

  // 10. Calendar Days (0 calendar consistency days logged)
  // [No insert into calendarDays]

  // 11. Journal Entries (0 journal entries -> EmptyState: "No Journal Entries — Your story begins today.")
  // [No insert into journalEntries]

  // 12. Goals (6 goals starting at 0 progress)
  const sampleGoals = [
    {
      title: "Become financially independent",
      category: "Finance",
      targetValue: 100000,
      currentValue: 0,
      unit: "$/yr",
      completed: false,
    },
    {
      title: "Master After Effects",
      category: "Skill",
      targetValue: 100,
      currentValue: 0,
      unit: "XP %",
      completed: false,
    },
    {
      title: "Build 100 portfolio projects",
      category: "Portfolio",
      targetValue: 100,
      currentValue: 0,
      unit: "projects",
      completed: false,
    },
    {
      title: "Earn from design every month",
      category: "Finance",
      targetValue: 12,
      currentValue: 0,
      unit: "months",
      completed: false,
    },
    {
      title: "Build a premium personal brand",
      category: "Career",
      targetValue: 10000,
      currentValue: 0,
      unit: "followers",
      completed: false,
    },
    {
      title: "Complete Building Technology diploma",
      category: "Education",
      targetValue: 100,
      currentValue: 0,
      unit: "%",
      completed: false,
    },
  ];
  await db.insert(goals).values(sampleGoals);

  // 13. Vision Board Items (Vision milestones ready, 0 progress)
  const sampleVisionBoard = [
    {
      title: "Dream Workspace Setup",
      category: "Dream Workspace",
      imageUrl:
        "https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=800&q=80",
      caption:
        "Floor-to-ceiling windows, acoustic wood panels, matte black furniture, natural sunlight.",
      targetDate: "2026-12-31",
      progress: 0,
      achieved: false,
    },
    {
      title: "MacBook Pro M3 Max Workstation",
      category: "Dream Laptop",
      imageUrl:
        "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80",
      caption:
        "64GB Unified Memory, Dual Studio Displays — rendering After Effects in real time.",
      targetDate: "2026-06-30",
      progress: 0,
      achieved: false,
    },
    {
      title: "Sony FX3 Full-Frame Cinema Camera",
      category: "Dream Camera",
      imageUrl:
        "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80",
      caption:
        "Full-frame cinematic video camera for documentary and brand storytelling.",
      targetDate: "2026-09-15",
      progress: 0,
      achieved: false,
    },
    {
      title: "Private Executive Creative Office",
      category: "Dream Office",
      imageUrl:
        "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80",
      caption:
        "Dedicated design agency space with client presentation lounge.",
      targetDate: "2027-04-01",
      progress: 0,
      achieved: false,
    },
    {
      title: "Architectural Glass Modern Home",
      category: "Dream House",
      imageUrl:
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80",
      caption:
        "Minimalist concrete and wood architecture overlooking the forest.",
      targetDate: "2028-12-31",
      progress: 0,
      achieved: false,
    },
    {
      title: "Porsche Taycan 4S Black Edition",
      category: "Dream Car",
      imageUrl:
        "https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=800&q=80",
      caption:
        "Quiet, effortless electric performance and precision German engineering.",
      targetDate: "2028-06-01",
      progress: 0,
      achieved: false,
    },
    {
      title: "Total Time & Creative Freedom",
      category: "Dream Lifestyle",
      imageUrl:
        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80",
      caption:
        "Working only on projects that inspire me, with clients who respect my vision.",
      targetDate: "2027-01-01",
      progress: 0,
      achieved: false,
    },
    {
      title: "Kyoto & Swiss Alps Sabbatical",
      category: "Travel Goals",
      imageUrl:
        "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80",
      caption:
        "Annual creative retreat to study traditional Japanese architecture and Swiss typography.",
      targetDate: "2027-10-01",
      progress: 0,
      achieved: false,
    },
    {
      title: "Supporting Family & Generational Stability",
      category: "Family Goals",
      imageUrl:
        "https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=800&q=80",
      caption:
        "Providing financial freedom and opportunity for my parents and siblings.",
      targetDate: "2026-11-01",
      progress: 0,
      achieved: false,
    },
    {
      title: "Peak Physical Vitality & Endurance",
      category: "Health Goals",
      imageUrl:
        "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80",
      caption:
        "Daily exercise, clean nutrition, and unbreakable mental clarity.",
      targetDate: "2026-08-01",
      progress: 0,
      achieved: false,
    },
    {
      title: "Top-Tier Personal Creative Brand",
      category: "Creative Goals",
      imageUrl:
        "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80",
      caption:
        "Recognized internationally for design excellence and creative discipline.",
      targetDate: "2027-01-01",
      progress: 0,
      achieved: false,
    },
    {
      title: "Financial Independence ($10K/mo Solo)",
      category: "Financial Goals",
      imageUrl:
        "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=800&q=80",
      caption:
        "Consistent high-ticket creative retainers and digital products.",
      targetDate: "2026-11-01",
      progress: 0,
      achieved: false,
    },
    {
      title: "Unshakable Professional Discipline",
      category: "Personal Growth",
      imageUrl:
        "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=800&q=80",
      caption: "Becoming the person I promised myself I would become.",
      targetDate: "2026-07-01",
      progress: 0,
      achieved: false,
    },
  ];
  await db.insert(visionBoardItems).values(sampleVisionBoard);

  // 14. Legacy System Entries (0 legacy days logged -> 0% Legacy score)
  // [No insert into legacyEntries]

  // 15. The Future Room Config
  await db.insert(futureRoomConfig).values({
    letterFromFuture: `Dear Gift,\n\nThank you for refusing to quit.\n\nThe mornings you wanted to stay in bed...\nThe nights you kept practicing...\nThe projects nobody noticed...\n\nThey changed everything.\n\nYou now own the studio you once dreamed about.\nClients respect your work.\nYour family is proud.\n\nKeep going.\nI'm waiting for you.`,
    whyIStarted:
      "Because I refused to settle for an ordinary life. Every day I wake up with the opportunity to build my own future, achieve financial freedom, and create work that inspires the world.",
    costOfQuitting: JSON.stringify([
      "The opportunities I lose.",
      "The clients I'll never meet.",
      "The life I'll never live.",
      "The family I won't be able to support.",
      "The dreams I'll abandon.",
    ]),
    rewardOfConsistency: JSON.stringify([
      "Financial freedom.",
      "Creative confidence.",
      "Better health.",
      "My own office.",
      "Helping my family.",
      "Working with dream clients.",
      "Traveling the world.",
      "Owning my time.",
    ]),
    legacyTraits: JSON.stringify([
      "Disciplined",
      "Faithful",
      "Kind",
      "Reliable",
      "Creative",
      "Generous",
      "Fearless",
      "Patient",
    ]),
    studioItems: JSON.stringify([
      {
        id: "desk",
        name: "Custom Walnut Executive Desk",
        category: "Desk",
        imageUrl:
          "https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=800&q=80",
        achieved: false,
      },
      {
        id: "monitor",
        name: "Apple Pro Display XDR Dual",
        category: "Monitor",
        imageUrl:
          "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=800&q=80",
        achieved: false,
      },
      {
        id: "laptop",
        name: "MacBook Pro M3 Max 64GB",
        category: "Laptop",
        imageUrl:
          "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80",
        achieved: false,
      },
      {
        id: "chair",
        name: "Herman Miller Embody Ergonomic Chair",
        category: "Chair",
        imageUrl:
          "https://images.unsplash.com/photo-1580481077494-e3299ac2fef6?auto=format&fit=crop&w=800&q=80",
        achieved: false,
      },
      {
        id: "lighting",
        name: "Cinematic Diffused Softbox Studio Light",
        category: "Lighting",
        imageUrl:
          "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80",
        achieved: false,
      },
      {
        id: "camera",
        name: "Sony FX3 Full-Frame Cinema Setup",
        category: "Camera",
        imageUrl:
          "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80",
        achieved: false,
      },
      {
        id: "inspiration",
        name: "Architectural Floor-to-Ceiling Windows",
        category: "Studio Inspiration",
        imageUrl:
          "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80",
        achieved: false,
      },
    ]),
  });

  // 16. Identity Statements ("The Person I Am Becoming")
  const defaultStatements = [
    { statement: "I am disciplined.", orderIndex: 1 },
    { statement: "I finish what I start.", orderIndex: 2 },
    { statement: "I attract great clients.", orderIndex: 3 },
    { statement: "I create world-class work.", orderIndex: 4 },
    { statement: "I am financially independent.", orderIndex: 5 },
    { statement: "I stay consistent.", orderIndex: 6 },
    { statement: "I build every day.", orderIndex: 7 },
  ];
  await db.insert(identityStatements).values(defaultStatements);

  // 17. Dream Life Timeline
  const defaultTimeline = [
    {
      year: 2026,
      title: "Foundation & Velocity",
      milestones: JSON.stringify([
        "Master After Effects",
        "Earn first consistent design income",
        "Graduate Diploma",
      ]),
      orderIndex: 1,
    },
    {
      year: 2027,
      title: "Agency & Scale",
      milestones: JSON.stringify([
        "Own creative agency",
        "Buy professional equipment",
        "Hire first employee",
      ]),
      orderIndex: 2,
    },
    {
      year: 2028,
      title: "Mastery & Freedom",
      milestones: JSON.stringify([
        "Open studio",
        "Reach international clients",
        "Passive income",
      ]),
      orderIndex: 3,
    },
  ];
  await db.insert(dreamTimeline).values(defaultTimeline);

  // 18. User Promise (isSigned: false -> opens Sacred Onboarding mirror for the new user!)
  await db.insert(userPromise).values({
    isSigned: false,
    promiseText:
      "I promise that I will show up every single day, build my creative portfolio, and honor the vision I have for my family and my future. I refuse to settle for an ordinary life.",
    whoFor: JSON.stringify([
      "Myself",
      "My family",
      "My future children",
      "My dreams",
    ]),
    whatIfQuit:
      "I'll remain stuck. I'll never build my business. I'll waste my potential. I'll regret not trying.",
    whatIfConsistent:
      "Financial freedom. Creative confidence. Helping my family. Owning my studio. Working with dream clients. Building a meaningful life.",
    signatureName: "",
    signedDate: "",
  });

  // 19. Promise Wall Milestones (0 milestones -> clean wall until signed or earned)
  // [No insert into promiseWallMilestones]
}

// ============================================================================
// SAMPLE DEMO DATA SEED (For users clicking "Load Demo Data" to test features)
// ============================================================================
export async function seedDemoData() {
  const todayStr = getRecentDateStr(0);

  // 1. Profile with streak 14, xp 1450, level 14
  await db.insert(userProfile).values({
    name: "Gift Safari",
    title: "Creative Entrepreneur",
    tagline: "Build. Create. Grow. Every Single Day.",
    theme: "dark",
    profilePhotoUrl:
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80",
    currentStreak: 14,
    longestStreak: 18,
    dayOfChallenge: 18,
    totalChallengeDays: 30,
    xp: 1450,
    level: 14,
    levelTitle: "Creative Explorer",
    soundEnabled: true,
    notificationsEnabled: true,
    dailyReminderTime: "08:00",
  });

  // 2. Quotes
  const quotes = [
    {
      quote: "Discipline creates freedom.",
      author: "Jocko Willink",
      activeForToday: true,
    },
    {
      quote: "Never miss two days in a row.",
      author: "James Clear",
      activeForToday: false,
    },
    {
      quote: "Professionals show up.",
      author: "Steven Pressfield",
      activeForToday: false,
    },
  ];
  await db.insert(motivationalQuotes).values(quotes);

  // 3. Missions (several completed: true)
  const demoMissions = [
    {
      date: todayStr,
      category: "morning",
      taskName: "Made Bed",
      completed: true,
      orderIndex: 1,
      xpReward: 10,
    },
    {
      date: todayStr,
      category: "morning",
      taskName: "Exercised",
      completed: true,
      orderIndex: 2,
      xpReward: 20,
    },
    {
      date: todayStr,
      category: "creative",
      taskName: "Graphic Design",
      completed: true,
      orderIndex: 5,
      xpReward: 100,
    },
    {
      date: todayStr,
      category: "creative",
      taskName: "Website Development",
      completed: true,
      orderIndex: 6,
      xpReward: 500,
    },
    {
      date: todayStr,
      category: "business",
      taskName: "Contacted 5 Clients",
      completed: true,
      orderIndex: 9,
      xpReward: 200,
    },
    {
      date: todayStr,
      category: "night",
      taskName: "Journal Entry",
      completed: false,
      orderIndex: 13,
      xpReward: 50,
    },
  ];
  await db.insert(dailyMissions).values(demoMissions);

  // 4. Pomodoros
  const demoSessions = [
    {
      date: getRecentDateStr(0),
      durationMinutes: 50,
      mode: "50/10",
      notes: "Hero animation in After Effects",
      interruptions: 0,
    },
    {
      date: getRecentDateStr(0),
      durationMinutes: 90,
      mode: "90min",
      notes: "Next.js client landing page build",
      interruptions: 1,
    },
    {
      date: getRecentDateStr(1),
      durationMinutes: 90,
      mode: "90min",
      notes: "3D brand logo rendering in Blender",
      interruptions: 0,
    },
  ];
  await db.insert(pomodoroSessions).values(demoSessions);

  // 5. Clients
  const demoClients = [
    {
      name: "Marcus Thorne",
      business: "Aura Audio Studios",
      phone: "+1 (415) 883-9201",
      email: "marcus@aura-audio.co",
      services: "Brand Identity & Motion Reel",
      price: 3500,
      deadline: getRecentDateStr(-10),
      status: "Working",
      notes: "Delivered first round of animated logos.",
    },
    {
      name: "Elena Rostova",
      business: "Veloce Robotics",
      phone: "+1 (212) 554-1920",
      email: "elena@velocerobotics.io",
      services: "Full Website UI/UX & Next.js Build",
      price: 6800,
      deadline: getRecentDateStr(-18),
      status: "Paid",
      notes: "Website launched successfully on Vercel.",
    },
  ];
  const insertedC = await db.insert(clients).values(demoClients).returning();

  // 6. Transactions
  const demoTx = [
    {
      date: getRecentDateStr(2),
      clientId: insertedC[1]?.id || 2,
      clientName: "Veloce Robotics",
      amount: 6800,
      service: "Full Website UI/UX & Next.js Build",
      status: "Paid",
    },
    {
      date: getRecentDateStr(8),
      clientId: insertedC[0]?.id || 1,
      clientName: "Aura Audio Studios (Deposit)",
      amount: 1750,
      service: "Brand Identity & Motion Reel",
      status: "Paid",
    },
  ];
  await db.insert(incomeTransactions).values(demoTx);

  // 7. Portfolio
  const demoProjects = [
    {
      title: "Veloce AI Robotics Operating System UI",
      category: "UI",
      thumbnail:
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80",
      description: "Dark-mode AI dashboard design with real-time telemetry charts.",
      toolsUsed: "Figma, Next.js, Framer Motion, Tailwind",
      completionDate: getRecentDateStr(5),
      client: "Veloce Robotics",
      behanceLink: "https://behance.net/gallery/veloce-os",
      liveWebsite: "https://veloce-robotics-demo.vercel.app",
      status: "Completed",
    },
    {
      title: "Aura Soundwaves Kinetic Typography",
      category: "Motion",
      thumbnail:
        "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80",
      description: "Fluid 60fps kinetic typography and audio-reactive waveforms.",
      toolsUsed: "After Effects, Cinema 4D, Illustrator",
      completionDate: getRecentDateStr(12),
      client: "Aura Audio Studios",
      behanceLink: "https://behance.net/gallery/aura-soundwaves",
      liveWebsite: "https://aura-audio.co",
      status: "Completed",
    },
  ];
  await db.insert(portfolioProjects).values(demoProjects);

  // 8. Skills with XP
  const demoSkills = [
    {
      name: "Photoshop",
      category: "Design",
      currentXp: 850,
      level: "Creative Master",
      levelIndex: 5,
      iconName: "Image",
      tasksCompletedCount: 42,
    },
    {
      name: "UI Design",
      category: "Design",
      currentXp: 950,
      level: "Legend",
      levelIndex: 6,
      iconName: "Layout",
      tasksCompletedCount: 55,
    },
  ];
  await db.insert(skills).values(demoSkills);

  // 9. Achievements with unlocked
  const demoBadges = [
    {
      badgeId: "streak_7",
      title: "🔥 7-Day Streak",
      description: "Completed all daily missions for 7 consecutive days.",
      icon: "Flame",
      category: "streak",
      unlocked: true,
      unlockedAt: getRecentDateStr(5),
    },
    {
      badgeId: "first_client",
      title: "💼 First Client",
      description: "Signed your very first paying client.",
      icon: "Briefcase",
      category: "income",
      unlocked: true,
      unlockedAt: getRecentDateStr(25),
    },
  ];
  await db.insert(achievements).values(demoBadges);

  // 10. Journals
  await db.insert(journalEntries).values([
    {
      date: getRecentDateStr(0),
      qCompleted: "Built the client CRM pipeline.",
      qChallenged: "Balancing revisions.",
      qLearned: "Framer Motion layoutId.",
      qGrateful: "Creative freedom.",
      qTomorrow: "90min deep work.",
      contentMarkdown: `# Daily Review - ${getRecentDateStr(0)}\n\nGreat focus today.`,
      mood: "🔥 Unstoppable",
    },
  ]);

  // 11. Legacy
  await db.insert(legacyEntries).values([
    {
      date: getRecentDateStr(0),
      meaningful: true,
      reflection: "Focused on high-impact work.",
    },
    {
      date: getRecentDateStr(1),
      meaningful: true,
      reflection: "Shipped Veloce UI project.",
    },
  ]);

  // 12. User Promise
  await db.insert(userPromise).values({
    isSigned: true,
    promiseText:
      "I promise that I will show up every single day, build my creative portfolio, and honor the vision I have for my family and my future. I refuse to settle for an ordinary life.",
    whoFor: JSON.stringify([
      "Myself",
      "My family",
      "My future children",
      "My dreams",
    ]),
    whatIfQuit:
      "I'll remain stuck. I'll never build my business. I'll waste my potential. I'll regret not trying.",
    whatIfConsistent:
      "Financial freedom. Creative confidence. Helping my family. Owning my studio. Working with dream clients. Building a meaningful life.",
    signatureName: "Gift Safari",
    signedDate: "2026-03-01",
  });

  // 13. Promise Wall Milestones
  await db.insert(promiseWallMilestones).values([
    {
      title: "Signed the Promise",
      date: "2026-03-01",
      category: "promise",
      orderIndex: 1,
    },
    {
      title: "First 7-Day Streak",
      date: "2026-03-08",
      category: "streak",
      orderIndex: 2,
    },
    {
      title: "First Client",
      date: "2026-03-09",
      category: "income",
      orderIndex: 3,
    },
  ]);
}
