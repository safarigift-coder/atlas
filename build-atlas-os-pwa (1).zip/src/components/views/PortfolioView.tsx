"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Palette,
  Search,
  Plus,
  ExternalLink,
  Globe,
  Trash2,
  Calendar,
  Layers,
  X,
  CheckCircle2,
  Eye,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";
import { EmptyState } from "@/components/brand/EmptyState";

export function PortfolioView() {
  const {
    portfolioProjects,
    addProject,
    deleteProject,
    setSelectedProject,
    setProjectModalOpen,
  } = useAtlasStore();

  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("UI");
  const [thumbnail, setThumbnail] = useState("");
  const [description, setDescription] = useState("");
  const [toolsUsed, setToolsUsed] = useState("Figma, Next.js, Framer Motion");
  const [client, setClient] = useState("Personal Creative Work");
  const [behanceLink, setBehanceLink] = useState("https://behance.net");
  const [liveWebsite, setLiveWebsite] = useState("https://example.com");
  const [status, setStatus] = useState("Completed");

  const categories = [
    "All",
    "Branding",
    "Logos",
    "Websites",
    "UI",
    "Motion",
    "Video",
    "Photography",
  ];

  const filteredProjects = portfolioProjects.filter((p) => {
    // Map category aliases if needed
    const normalizedCat =
      p.category === "UI Design"
        ? "UI"
        : p.category === "Motion Graphics"
        ? "Motion"
        : p.category === "Video Editing"
        ? "Video"
        : p.category;

    const matchesCat =
      activeCategory === "All" || normalizedCat === activeCategory;
    const matchesSearch =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.toolsUsed.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.client.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await addProject({
      title: title || "New Case Study",
      category: category || "UI",
      thumbnail:
        thumbnail ||
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80",
      description: description || "Creative exploration and production.",
      toolsUsed: toolsUsed || "Figma, Illustrator, Tailwind",
      completionDate: new Date().toISOString().split("T")[0],
      client: client || "Client",
      behanceLink: behanceLink || "https://behance.net",
      liveWebsite: liveWebsite || "https://example.com",
      status: status || "Completed",
    });
    setIsModalOpen(false);
    setTitle("");
    setDescription("");
  };

  const handleCardClick = (project: any) => {
    setSelectedProject(project);
    setProjectModalOpen(true);
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
            <Palette className="w-4 h-4" /> Creative Portfolio Gallery
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Visual Portfolio Exhibition
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            "Work until your portfolio introduces you." Showcasing {portfolioProjects.length} completed works.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition flex items-center gap-2 shadow-lg shadow-emerald-600/20"
        >
          <Plus className="w-4 h-4" /> Add Project
        </button>
      </div>

      {/* Search and Category Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Category Pill Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
          {categories.map((cat) => {
            const count =
              cat === "All"
                ? portfolioProjects.length
                : portfolioProjects.filter((p) => {
                    const normalized =
                      p.category === "UI Design"
                        ? "UI"
                        : p.category === "Motion Graphics"
                        ? "Motion"
                        : p.category === "Video Editing"
                        ? "Video"
                        : p.category;
                    return normalized === cat;
                  }).length;
            const isSelected = activeCategory === cat;

            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap border ${
                  isSelected
                    ? "bg-zinc-800 text-white border-emerald-500/50 shadow-sm"
                    : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white"
                }`}
              >
                <span>{cat}</span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                    isSelected
                      ? "bg-emerald-500/20 text-emerald-400"
                      : "bg-zinc-800 text-zinc-500"
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search Bar */}
        <div className="relative md:w-64">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search projects..."
            className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl pl-10 pr-4 py-2 text-xs focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Gallery Grid */}
      {portfolioProjects.length === 0 ? (
        <EmptyState
          title="No Portfolio"
          subtitle="Every masterpiece begins with one project."
          actionLabel="Add Your First Project"
          onAction={() => setIsModalOpen(true)}
          streak={14}
        />
      ) : (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProjects.length === 0 ? (
          <div className="col-span-full py-16 text-center text-zinc-500 text-sm bg-[#121215] border border-zinc-800 rounded-3xl">
            No projects found in this category.
          </div>
        ) : (
          filteredProjects.map((project) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ y: -5 }}
              onClick={() => handleCardClick(project)}
              className="group bg-[#121215] border border-zinc-800 rounded-3xl overflow-hidden shadow-xl hover:border-emerald-500/40 transition flex flex-col justify-between cursor-pointer"
            >
              <div>
                {/* Thumbnail Image */}
                <div className="relative h-56 w-full overflow-hidden bg-zinc-900">
                  <img
                    src={project.thumbnail}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
                    <span className="px-4 py-2 rounded-xl bg-black/80 text-white text-xs font-bold border border-white/20 flex items-center gap-2 backdrop-blur-md">
                      <Eye className="w-4 h-4 text-emerald-400" /> View Case Study
                    </span>
                  </div>
                  <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-bold text-white uppercase tracking-wider">
                    {project.category}
                  </div>
                  <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-emerald-500/90 text-black text-[11px] font-extrabold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    {project.status}
                  </div>
                </div>

                {/* Project Details */}
                <div className="p-6">
                  <h3 className="text-xl font-extrabold text-white tracking-tight group-hover:text-emerald-400 transition">
                    {project.title}
                  </h3>
                  <div className="text-xs text-zinc-500 mt-1 mb-3">
                    Client: <span className="text-zinc-300 font-semibold">{project.client}</span> • {project.completionDate}
                  </div>

                  <p className="text-xs text-zinc-400 line-clamp-3 mb-4 leading-relaxed">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {project.toolsUsed
                      .split(",")
                      .map((tool: string, idx: number) => (
                        <span
                          key={idx}
                          className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 text-[11px] font-semibold text-zinc-300"
                        >
                          {tool.trim()}
                        </span>
                      ))}
                  </div>
                </div>
              </div>

              {/* Action Links Footer */}
              <div
                onClick={(e) => e.stopPropagation()}
                className="p-4 px-6 border-t border-zinc-800/80 bg-zinc-900/30 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <a
                    href={project.behanceLink}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-bold text-zinc-400 hover:text-white flex items-center gap-1 transition"
                  >
                    <span>Behance</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <span className="text-zinc-700">•</span>
                  <a
                    href={project.liveWebsite}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition"
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>Live Site</span>
                  </a>
                </div>

                <button
                  onClick={() => deleteProject(project.id)}
                  className="p-1.5 text-zinc-500 hover:text-red-400 rounded-lg transition"
                  title="Delete project"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))
        )}
      </div>
      )}

      {/* Add Project Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.form
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleSubmit}
              className="w-full max-w-lg bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <h3 className="text-xl font-extrabold text-white">
                  Add Creative Portfolio Project
                </h3>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-zinc-500 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Project Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Tokyo Architecture Noir Series"
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  >
                    {categories.slice(1).map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Client / Brand
                  </label>
                  <input
                    type="text"
                    value={client}
                    onChange={(e) => setClient(e.target.value)}
                    placeholder="Tokyo Design Journal"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Thumbnail Image URL (Unsplash or custom)
                </label>
                <input
                  type="url"
                  value={thumbnail}
                  onChange={(e) => setThumbnail(e.target.value)}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Tools Used (comma separated)
                </label>
                <input
                  type="text"
                  value={toolsUsed}
                  onChange={(e) => setToolsUsed(e.target.value)}
                  placeholder="Sony FX3, Lightroom, Photoshop"
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Behance Link
                  </label>
                  <input
                    type="url"
                    value={behanceLink}
                    onChange={(e) => setBehanceLink(e.target.value)}
                    placeholder="https://behance.net/..."
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Live Website URL
                  </label>
                  <input
                    type="url"
                    value={liveWebsite}
                    onChange={(e) => setLiveWebsite(e.target.value)}
                    placeholder="https://..."
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Description & Case Study
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Brief summary of the creative problem solved..."
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs"
                >
                  Publish Project
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
