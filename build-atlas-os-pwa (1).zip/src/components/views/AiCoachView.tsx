"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Sparkles,
  TrendingUp,
  Award,
  Timer,
  CheckCircle2,
  Briefcase,
  Flame,
  ArrowRight,
  Send,
  UserCheck,
  ShieldCheck,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";

export function AiCoachView() {
  const {
    profile,
    aiCoachAnalysis,
    focusStats,
    dailyMissions,
    setActiveTab,
  } = useAtlasStore();

  const [customPrompt, setCustomPrompt] = useState("");
  const [conversations, setConversations] = useState<
    { sender: "user" | "mentor"; text: string; time: string }[]
  >([
    {
      sender: "mentor",
      text: `Good morning ${profile.name}. Yesterday you completed 9 of 10 missions. You missed Client Outreach. Today's recommendation: Finish the Architecture Website before noon.`,
      time: "08:00 AM",
    },
    {
      sender: "mentor",
      text: `Your consistency score increased by 6% this week. You're only 4 days away from your longest streak of ${profile.longestStreak} days. Keep your momentum steady!`,
      time: "08:01 AM",
    },
  ]);

  const handleAskMentor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customPrompt.trim()) return;

    const userText = customPrompt.trim();
    const nowTime = new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });

    const newConvo = [
      ...conversations,
      { sender: "user" as const, text: userText, time: nowTime },
    ];

    setCustomPrompt("");

    // Simulate encouraging mentor response
    setTimeout(() => {
      let mentorReply = `Excellent focus, ${profile.name}. Every rep you put in compounds toward your long-term legacy. Stay locked in on your highest-leverage task today.`;
      const lower = userText.toLowerCase();

      if (lower.includes("client") || lower.includes("crm")) {
        mentorReply = `Your CRM currently has active deals in the pipeline. Reach out to 3 new leads before lunch—action cures fear.`;
      } else if (lower.includes("focus") || lower.includes("after effects")) {
        mentorReply = `Try a 90-minute Deep Work block with phone notifications muted. Your After Effects progress is growing consistently.`;
      } else if (lower.includes("streak") || lower.includes("tired")) {
        mentorReply = `Rest is part of professional discipline. Never guilt yourself for taking a recovery evening—just never miss two days in a row!`;
      }

      setConversations((prev) => [
        ...prev,
        {
          sender: "mentor" as const,
          text: mentorReply,
          time: new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
        },
      ]);
    }, 600);

    setConversations(newConvo);
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-6xl mx-auto">
      {/* Mentor Hero Banner */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#121215] via-[#171a25] to-[#121215] border border-white/10 p-8 sm:p-10 shadow-2xl backdrop-blur-2xl"
      >
        <div className="absolute top-0 right-0 w-[450px] h-[450px] bg-gradient-to-br from-emerald-500/15 via-purple-500/15 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-8 space-y-3">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-extrabold uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5" /> ATLAS AI EXECUTIVE MENTOR
            </div>

            <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              Personal Creative Coach
            </h1>

            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
              "Good morning {profile.name}. Yesterday you completed 9 of 10 missions. You missed Client Outreach. Today's recommendation: Finish the Architecture Website before noon."
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs font-bold text-emerald-400">
              <span className="px-3 py-1.5 rounded-xl bg-zinc-900/80 border border-white/10">
                Consistency Score: +6%
              </span>
              <span className="px-3 py-1.5 rounded-xl bg-zinc-900/80 border border-white/10">
                Streak Target: {profile.longestStreak} Days
              </span>
              <span className="px-3 py-1.5 rounded-xl bg-zinc-900/80 border border-white/10 text-zinc-300">
                Always Positive. Zero Guilt.
              </span>
            </div>
          </div>

          <div className="lg:col-span-4 flex flex-col items-center justify-center bg-zinc-900/60 border border-white/10 rounded-3xl p-6 text-center shadow-xl">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 to-blue-500 flex items-center justify-center text-black font-black text-xl mb-3 shadow-lg shadow-emerald-500/20">
              AI
            </div>
            <div className="text-lg font-black text-white">
              Executive Mentor
            </div>
            <div className="text-xs text-emerald-400 font-bold mt-0.5">
              Active Monitoring
            </div>
            <div className="mt-3 text-[11px] text-zinc-400">
              Analyzing daily discipline, focus velocity & CRM pipeline
            </div>
          </div>
        </div>
      </motion.div>

      {/* 2. DAILY COACHING CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {aiCoachAnalysis.map((item: any) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#121215] border border-zinc-800 hover:border-zinc-700 rounded-3xl p-6 shadow-xl flex flex-col justify-between transition"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="px-3 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-xs font-bold text-emerald-400 uppercase tracking-wider">
                  Daily Briefing
                </span>
                <span className="text-xs text-zinc-500 font-mono">
                  {item.date}
                </span>
              </div>

              <h3 className="text-lg font-extrabold text-white tracking-tight mb-2">
                {item.title}
              </h3>

              <p className="text-sm text-zinc-300 leading-relaxed">
                {item.message}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs text-zinc-400">
              <span className="text-emerald-400 font-semibold">
                Positive Coaching Analysis
              </span>
              <button
                onClick={() => setActiveTab("missions")}
                className="text-white hover:text-emerald-400 font-bold flex items-center gap-1 transition"
              >
                <span>Take Action</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* 3. INTERACTIVE MENTOR CHAT STREAM */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-emerald-400">
              Real-Time Guidance
            </div>
            <h3 className="text-xl font-black text-white">
              Executive Mentor Dialogue
            </h3>
          </div>
          <span className="text-xs font-semibold text-zinc-500">
            AI Coach Session Active
          </span>
        </div>

        {/* Message Thread */}
        <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
          {conversations.map((msg, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex flex-col ${
                msg.sender === "user" ? "items-end" : "items-start"
              }`}
            >
              <div
                className={`max-w-xl p-4 rounded-2xl text-sm leading-relaxed ${
                  msg.sender === "user"
                    ? "bg-emerald-600 text-black font-semibold rounded-br-none shadow-lg shadow-emerald-600/10"
                    : "bg-zinc-900 border border-zinc-800 text-zinc-200 rounded-bl-none"
                }`}
              >
                {msg.text}
              </div>
              <span className="text-[10px] text-zinc-500 mt-1 px-1">
                {msg.sender === "user" ? "You" : "Atlas Mentor"} • {msg.time}
              </span>
            </motion.div>
          ))}
        </div>

        {/* Ask Mentor Form */}
        <form
          onSubmit={handleAskMentor}
          className="flex items-center gap-3 pt-2"
        >
          <input
            type="text"
            value={customPrompt}
            onChange={(e) => setCustomPrompt(e.target.value)}
            placeholder="Ask your mentor for strategic advice or accountability..."
            className="flex-1 bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-2xl px-4 py-3.5 text-sm focus:outline-none focus:border-emerald-500"
          />
          <button
            type="submit"
            className="px-6 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-sm transition shadow-lg shadow-emerald-500/20 flex items-center gap-2"
          >
            <span>Ask</span>
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
