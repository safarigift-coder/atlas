"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  BookOpen,
  Search,
  Save,
  CheckCircle2,
  Calendar,
  Sparkles,
  Eye,
  Edit3,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";
import { EmptyState } from "@/components/brand/EmptyState";

export function JournalView() {
  const { journalEntries, saveJournalEntry } = useAtlasStore();

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [isPreview, setIsPreview] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Find existing or initialize empty answers
  const currentEntry =
    journalEntries.find((j) => j.date === selectedDate) || {
      qCompleted: "",
      qChallenged: "",
      qLearned: "",
      qGrateful: "",
      qTomorrow: "",
      contentMarkdown: "",
      mood: "🔥 Unstoppable",
    };

  const [qCompleted, setQCompleted] = useState(currentEntry.qCompleted);
  const [qChallenged, setQChallenged] = useState(currentEntry.qChallenged);
  const [qLearned, setQLearned] = useState(currentEntry.qLearned);
  const [qGrateful, setQGrateful] = useState(currentEntry.qGrateful);
  const [qTomorrow, setQTomorrow] = useState(currentEntry.qTomorrow);
  const [contentMarkdown, setContentMarkdown] = useState(
    currentEntry.contentMarkdown ||
      `# Daily Review - ${selectedDate}\n\n### Key Reflections\nConsistency is the only bridge between vision and reality.`
  );
  const [mood, setMood] = useState(currentEntry.mood || "🔥 Unstoppable");

  const handleDateChange = (dateStr: string) => {
    setSelectedDate(dateStr);
    const existing = journalEntries.find((j) => j.date === dateStr);
    if (existing) {
      setQCompleted(existing.qCompleted);
      setQChallenged(existing.qChallenged);
      setQLearned(existing.qLearned);
      setQGrateful(existing.qGrateful);
      setQTomorrow(existing.qTomorrow);
      setContentMarkdown(existing.contentMarkdown);
      setMood(existing.mood);
    } else {
      setQCompleted("");
      setQChallenged("");
      setQLearned("");
      setQGrateful("");
      setQTomorrow("");
      setContentMarkdown(
        `# Daily Review - ${dateStr}\n\n### Key Reflections\n`
      );
      setMood("🔥 Unstoppable");
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const combinedMarkdown = `# Daily Review - ${selectedDate} (${mood})\n\n### What did I complete?\n${qCompleted}\n\n### What challenged me?\n${qChallenged}\n\n### What did I learn?\n${qLearned}\n\n### What am I grateful for?\n${qGrateful}\n\n### Tomorrow's mission?\n${qTomorrow}\n\n---\n\n${contentMarkdown}`;

    await saveJournalEntry({
      date: selectedDate,
      qCompleted,
      qChallenged,
      qLearned,
      qGrateful,
      qTomorrow,
      contentMarkdown: combinedMarkdown,
      mood,
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 4000);
  };

  const filteredEntries = journalEntries.filter(
    (j) =>
      j.date.includes(searchQuery) ||
      j.contentMarkdown.toLowerCase().includes(searchQuery.toLowerCase()) ||
      j.qCompleted.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-6xl mx-auto">
      {/* Top Bar */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
            <BookOpen className="w-4 h-4" /> Daily Reflection & Markdown
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Creative Journal
          </h1>
          <p className="text-sm text-zinc-400 mt-1">
            "Small actions. Massive results." Document your daily discipline and extract actionable wisdom.
          </p>
        </div>

        {/* Date Selector & Mood */}
        <div className="flex items-center gap-3">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => handleDateChange(e.target.value)}
            className="bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:border-emerald-500"
          />

          <select
            value={mood}
            onChange={(e) => setMood(e.target.value)}
            className="bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-emerald-500"
          >
            <option value="🔥 Unstoppable">🔥 Unstoppable</option>
            <option value="⚡ Focused">⚡ Focused</option>
            <option value="🧘 Steady">🧘 Steady</option>
            <option value="🌊 Tired">🌊 Tired</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Structured Questions & Markdown Editor */}
        <form onSubmit={handleSave} className="lg:col-span-2 space-y-6">
          {/* 5 Daily Questions Card */}
          <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl space-y-5">
            <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>The 5 Daily Discipline Questions</span>
            </h3>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-emerald-400 mb-1.5">
                1. What did I complete today?
              </label>
              <textarea
                rows={2}
                value={qCompleted}
                onChange={(e) => setQCompleted(e.target.value)}
                placeholder="e.g. Shipped 2 After Effects animations and reached out to 5 leads..."
                className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-blue-400 mb-1.5">
                2. What challenged me?
              </label>
              <textarea
                rows={2}
                value={qChallenged}
                onChange={(e) => setQChallenged(e.target.value)}
                placeholder="e.g. Managing energy after lunch..."
                className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-purple-400 mb-1.5">
                3. What did I learn?
              </label>
              <textarea
                rows={2}
                value={qLearned}
                onChange={(e) => setQLearned(e.target.value)}
                placeholder="e.g. After Effects kinetic typography expressions..."
                className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-amber-400 mb-1.5">
                4. What am I grateful for?
              </label>
              <textarea
                rows={2}
                value={qGrateful}
                onChange={(e) => setQGrateful(e.target.value)}
                placeholder="e.g. My creative freedom, good health, and workstation..."
                className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-orange-400 mb-1.5">
                5. Tomorrow's mission?
              </label>
              <textarea
                rows={2}
                value={qTomorrow}
                onChange={(e) => setQTomorrow(e.target.value)}
                placeholder="e.g. 90min deep work on new case study..."
                className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Markdown Editor / Preview */}
          <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="text-lg font-extrabold text-white">
                Markdown Freeform Notes
              </h3>
              <button
                type="button"
                onClick={() => setIsPreview(!isPreview)}
                className="px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold flex items-center gap-1.5"
              >
                {isPreview ? (
                  <>
                    <Edit3 className="w-3.5 h-3.5" /> Edit
                  </>
                ) : (
                  <>
                    <Eye className="w-3.5 h-3.5" /> Preview Markdown
                  </>
                )}
              </button>
            </div>

            {!isPreview ? (
              <textarea
                rows={8}
                value={contentMarkdown}
                onChange={(e) => setContentMarkdown(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 text-white font-mono text-sm rounded-2xl p-4 focus:outline-none focus:border-emerald-500 leading-relaxed"
              />
            ) : (
              <div className="w-full min-h-[200px] bg-zinc-900/60 border border-zinc-800 text-white font-sans text-sm rounded-2xl p-4 whitespace-pre-wrap leading-relaxed">
                {contentMarkdown || "No markdown content written yet."}
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              {saveSuccess && (
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" /> Journal entry saved to
                  database!
                </span>
              )}

              <button
                type="submit"
                className="ml-auto px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-extrabold text-xs transition shadow-lg shadow-emerald-600/20 flex items-center gap-2"
              >
                <Save className="w-4 h-4" /> Save Journal Entry
              </button>
            </div>
          </div>
        </form>

        {/* Right Col: Search Past Entries */}
        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl h-fit space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
            <h3 className="text-base font-extrabold text-white">
              Search Journal Archive
            </h3>
            <span className="text-xs text-zinc-500">
              {journalEntries.length} entries
            </span>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search past notes..."
              className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl pl-9 pr-3 py-2 text-xs focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredEntries.length === 0 ? (
              <EmptyState
                title="No Journal Entries"
                subtitle="Your story begins today."
                streak={14}
              />
            ) : (
              filteredEntries.map((entry) => (
                <button
                  key={entry.id}
                  onClick={() => handleDateChange(entry.date)}
                  className={`w-full text-left p-3.5 rounded-2xl border transition ${
                    selectedDate === entry.date
                      ? "bg-zinc-800 border-emerald-500/50 text-white"
                      : "bg-zinc-900/60 border-zinc-800/80 hover:border-zinc-700 text-zinc-300"
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-bold mb-1">
                    <span className="font-mono text-emerald-400">
                      {entry.date}
                    </span>
                    <span>{entry.mood}</span>
                  </div>
                  <p className="text-xs text-zinc-400 line-clamp-2">
                    {entry.qCompleted || entry.contentMarkdown}
                  </p>
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
