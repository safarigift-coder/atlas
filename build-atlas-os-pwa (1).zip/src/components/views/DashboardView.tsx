"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Flame,
  Calendar,
  Timer,
  DollarSign,
  Palette,
  Users,
  Video,
  Globe,
  Quote,
  RefreshCw,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  Award,
  Zap,
  Briefcase,
  BookOpen,
  TrendingUp,
  Layout,
  CheckSquare,
  Compass,
  Shield,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useAtlasStore } from "@/store/atlas-store";
import { getRpgLevelInfo, getTaskXpReward } from "@/lib/rpg";
import { soundManager } from "@/lib/sound";

export function DashboardView() {
  const {
    profile,
    focusStats,
    incomeStats,
    portfolioStats,
    clients,
    dailyMissions,
    calendarDays,
    quote,
    rotateQuote,
    setActiveTab,
    toggleMission,
  } = useAtlasStore();

  // RPG level info
  const rpgInfo = getRpgLevelInfo(profile.xp || 1450);

  const missionsCompleted = dailyMissions.filter((m) => m.completed).length;
  const missionsTotal = dailyMissions.length;
  const completionPercent =
    missionsTotal > 0
      ? Math.round((missionsCompleted / missionsTotal) * 100)
      : 80;

  // Streak encouraging message
  const getStreakMessage = (streak: number) => {
    if (streak >= 100) return "You are unstoppable.";
    if (streak >= 30) return "You've changed your life.";
    if (streak >= 14) return "Discipline is becoming identity.";
    return "Momentum is building.";
  };

  // Top priorities for Command Center
  const topPriorities = [
    { name: "Portfolio Project", icon: Palette, defaultCategory: "creative" },
    { name: "After Effects", icon: Video, defaultCategory: "creative" },
    { name: "Client Outreach", icon: Briefcase, defaultCategory: "business" },
    { name: "Website Development", icon: Globe, defaultCategory: "creative" },
    { name: "Journal", icon: BookOpen, defaultCategory: "night" },
  ];

  // Find matching daily mission from dailyMissions
  const findMissionForPriority = (pName: string) => {
    return dailyMissions.find(
      (m) =>
        m.taskName.toLowerCase().includes(pName.toLowerCase()) ||
        pName.toLowerCase().includes(m.taskName.toLowerCase())
    );
  };

  const handlePriorityToggle = async (priorityName: string) => {
    const existing = findMissionForPriority(priorityName);
    soundManager.playCheck(profile.soundEnabled);
    if (existing) {
      await toggleMission(existing.id, !existing.completed);
    }
  };

  // Prepare weekly chart data from last 7 calendar days
  const last7Days = calendarDays.slice(0, 7).reverse();
  const chartData =
    last7Days.length > 0
      ? last7Days.map((day) => ({
          name: day.date.split("-").slice(1).join("/"),
          hours: day.hoursFocused,
          projects: day.projectsCompleted,
        }))
      : [
          { name: "Mon", hours: 2.5, projects: 0 },
          { name: "Tue", hours: 3.8, projects: 1 },
          { name: "Wed", hours: 1.5, projects: 0 },
          { name: "Thu", hours: 4.2, projects: 1 },
          { name: "Fri", hours: 3.0, projects: 0 },
          { name: "Sat", hours: 5.0, projects: 1 },
          { name: "Sun", hours: 2.8, projects: 0 },
        ];

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-7xl mx-auto">
      {/* 1. HERO SECTION */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#121215] via-[#16161a] to-[#121215] border border-white/10 p-6 sm:p-10 shadow-2xl backdrop-blur-2xl"
      >
        {/* Subtle Ambient Glass & Noise Glow */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-emerald-500/15 via-blue-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Hero Details (8 cols) */}
          <div className="lg:col-span-8 space-y-4">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="px-3.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-extrabold uppercase tracking-widest flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5" /> Day {profile.dayOfChallenge} of
                Operation Lock In
              </span>

              <span className="px-3.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-extrabold uppercase tracking-widest">
                Today's Focus: Deep Creative Execution
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
              Good Morning, {profile.name} 👋
            </h1>

            <div className="bg-zinc-900/60 border border-white/5 rounded-2xl p-4 max-w-2xl">
              <div className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-1 flex items-center gap-1.5">
                <Quote className="w-3.5 h-3.5" /> Motivational Directive
              </div>
              <blockquote className="text-base sm:text-lg font-extrabold text-zinc-100 tracking-tight italic">
                "{quote.quote}"
              </blockquote>
              <div className="text-xs font-semibold text-zinc-500 mt-1">
                — {quote.author}
              </div>
            </div>

            {/* Quick Action Navigation */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setActiveTab("promise")}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-blue-500 hover:from-emerald-400 hover:to-blue-400 text-black font-black text-xs uppercase tracking-widest transition shadow-lg shadow-emerald-500/25 flex items-center gap-2"
              >
                <Shield className="w-4 h-4" />
                <span>The Promise</span>
              </button>

              <button
                onClick={() => setActiveTab("futureroom")}
                className="px-5 py-3 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-white font-black text-xs uppercase tracking-widest transition border border-zinc-700 flex items-center gap-2"
              >
                <Compass className="w-4 h-4 text-emerald-400" />
                <span>The Future Room</span>
              </button>

              <button
                onClick={() => setActiveTab("missions")}
                className="px-5 py-3 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-white font-black text-xs transition border border-zinc-700 flex items-center gap-2"
              >
                <span>Daily Mission Checklist</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setActiveTab("pomodoro")}
                className="px-5 py-3 rounded-2xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white font-bold text-xs border border-zinc-700/60 transition flex items-center gap-2"
              >
                <Timer className="w-4 h-4 text-emerald-400" />
                <span>Start Deep Work Mode</span>
              </button>

              <button
                onClick={() => rotateQuote()}
                title="Rotate quote"
                className="p-3 rounded-2xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 transition"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right Circular Progress Ring (4 cols) */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center text-center bg-zinc-900/50 border border-white/5 rounded-3xl p-6 backdrop-blur-md">
            <div className="text-xs font-bold uppercase tracking-widest text-zinc-400 mb-2">
              Today's Mission
            </div>

            <div className="relative w-44 h-44 flex items-center justify-center my-1">
              <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  className="stroke-zinc-800"
                  strokeWidth="8"
                  fill="transparent"
                />
                <motion.circle
                  cx="50"
                  cy="50"
                  r="40"
                  className="stroke-emerald-500"
                  strokeWidth="8"
                  strokeDasharray={2 * Math.PI * 40}
                  strokeDashoffset={
                    2 * Math.PI * 40 * (1 - completionPercent / 100)
                  }
                  strokeLinecap="round"
                  fill="transparent"
                  initial={{ strokeDashoffset: 2 * Math.PI * 40 }}
                  animate={{
                    strokeDashoffset:
                      2 * Math.PI * 40 * (1 - completionPercent / 100),
                  }}
                  transition={{ duration: 1.2, ease: "easeInOut" }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="text-4xl font-black text-white">
                  {completionPercent}%
                </div>
                <div className="text-[11px] font-extrabold text-emerald-400 uppercase tracking-widest">
                  Completed
                </div>
              </div>
            </div>

            <div className="mt-3 text-xs font-mono font-bold text-zinc-400 flex items-center gap-1">
              <span>████████░░</span>
              <span className="text-white">{completionPercent}%</span>
            </div>

            <div className="mt-2 text-xs text-zinc-500">
              {missionsCompleted} of {missionsTotal} daily tasks checked off
            </div>
          </div>
        </div>
      </motion.div>

      {/* 2. TODAY'S COMMAND CENTER & RPG PROFILE CARD GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Today's Command Center (7 cols) */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-7 bg-[#121215] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800/80 mb-5">
              <div>
                <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-widest text-emerald-400">
                  <CheckSquare className="w-4 h-4" /> Priority Executive Action
                </div>
                <h2 className="text-2xl font-black text-white tracking-tight">
                  Today's Command Center
                </h2>
              </div>
              <span className="text-xs font-bold px-3 py-1 rounded-full bg-zinc-800 text-zinc-300">
                Top Priorities
              </span>
            </div>

            {/* Checkbox Priority List */}
            <div className="space-y-3">
              {topPriorities.map((item) => {
                const mission = findMissionForPriority(item.name);
                const isCompleted = mission ? mission.completed : false;
                const Icon = item.icon;
                const reward = getTaskXpReward(item.name);

                return (
                  <div
                    key={item.name}
                    onClick={() => handlePriorityToggle(item.name)}
                    className={`group flex items-center justify-between p-4 rounded-2xl border transition cursor-pointer select-none ${
                      isCompleted
                        ? "bg-emerald-500/10 border-emerald-500/40 text-zinc-400"
                        : "bg-zinc-900/60 border-zinc-800/80 hover:border-zinc-700 text-zinc-200"
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <div
                        className={`w-6 h-6 rounded-lg flex items-center justify-center border transition ${
                          isCompleted
                            ? "bg-emerald-500 border-emerald-400 text-black shadow-md shadow-emerald-500/20"
                            : "bg-zinc-800 border-zinc-700 text-transparent group-hover:border-zinc-500"
                        }`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div className="flex items-center gap-2.5">
                        <Icon
                          className={`w-4 h-4 ${
                            isCompleted ? "text-emerald-400" : "text-zinc-500"
                          }`}
                        />
                        <span
                          className={`text-sm font-bold transition ${
                            isCompleted
                              ? "line-through text-zinc-500"
                              : "text-white"
                          }`}
                        >
                          {item.name}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`text-xs font-mono font-bold px-2.5 py-1 rounded-lg ${
                        isCompleted
                          ? "bg-emerald-500/20 text-emerald-400"
                          : "bg-zinc-800 text-amber-400"
                      }`}
                    >
                      +{reward} XP
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-zinc-800/80 flex items-center justify-between text-xs text-zinc-400">
            <span>Click any priority to mark complete & earn XP</span>
            <button
              onClick={() => setActiveTab("missions")}
              className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 transition"
            >
              <span>View Full Checklist</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>

        {/* RPG Profile Card & Streak System (5 cols) */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="lg:col-span-5 bg-[#121215] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col justify-between relative overflow-hidden"
        >
          {/* Top Profile Header */}
          <div>
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3.5">
                <div className="relative w-14 h-14 rounded-2xl overflow-hidden border-2 border-emerald-500/40 shadow-lg shrink-0">
                  <img
                    src={profile.profilePhotoUrl}
                    alt={profile.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-xl font-black text-white tracking-tight">
                    {profile.name}
                  </h3>
                  <div className="text-xs font-bold text-emerald-400">
                    {profile.title}
                  </div>
                  <div className="text-[11px] text-zinc-500">
                    ATLAS OS Creative Executive
                  </div>
                </div>
              </div>

              <div className="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-black">
                Level {rpgInfo.level}
              </div>
            </div>

            {/* RPG XP Progress Bar */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4 mb-5">
              <div className="flex items-center justify-between text-xs font-extrabold mb-2">
                <span className="text-amber-400 flex items-center gap-1.5">
                  <Award className="w-4 h-4" /> {rpgInfo.levelTitle}
                </span>
                <span className="text-zinc-300 font-mono">
                  {profile.xp} / {rpgInfo.nextLevelXp} XP
                </span>
              </div>
              <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${rpgInfo.progressPercent}%` }}
                  transition={{ duration: 1 }}
                  className="h-full bg-gradient-to-r from-amber-500 via-emerald-500 to-blue-500 rounded-full"
                />
              </div>
              <div className="mt-1.5 text-[11px] text-zinc-500 text-right">
                {rpgInfo.nextLevelXp - profile.xp} XP required for next rank
              </div>
            </div>

            {/* Alive Streak Card */}
            <div className="bg-gradient-to-r from-orange-500/15 via-orange-500/5 to-transparent border border-orange-500/30 rounded-2xl p-4 flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ scale: [1, 1.15, 1], rotate: [0, -5, 5, 0] }}
                  transition={{ repeat: Infinity, duration: 2.5 }}
                  className="w-11 h-11 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center border border-orange-500/40 shadow-lg shadow-orange-500/20"
                >
                  <Flame className="w-6 h-6 fill-orange-400" />
                </motion.div>
                <div>
                  <div className="text-xl font-black text-white">
                    {profile.currentStreak} Days
                  </div>
                  <div className="text-xs font-extrabold text-orange-300 italic">
                    "{getStreakMessage(profile.currentStreak)}"
                  </div>
                </div>
              </div>
              <div className="text-[11px] font-bold text-zinc-500 uppercase">
                Alive Streak
              </div>
            </div>

            {/* 4 Creative Metrics Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3 text-center">
                <div className="text-xs text-zinc-500 uppercase font-bold">
                  Total Designs
                </div>
                <div className="text-lg font-black text-purple-400 mt-0.5">
                  54 Designs
                </div>
              </div>

              <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3 text-center">
                <div className="text-xs text-zinc-500 uppercase font-bold">
                  Websites
                </div>
                <div className="text-lg font-black text-emerald-400 mt-0.5">
                  {portfolioStats.websitesBuilt} Built
                </div>
              </div>

              <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3 text-center">
                <div className="text-xs text-zinc-500 uppercase font-bold">
                  Clients Won
                </div>
                <div className="text-lg font-black text-blue-400 mt-0.5">
                  {clients.length} Clients
                </div>
              </div>

              <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3 text-center">
                <div className="text-xs text-zinc-500 uppercase font-bold">
                  Total Revenue
                </div>
                <div className="text-lg font-black text-emerald-300 mt-0.5">
                  ${incomeStats.totalIncome.toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
            <span className="flex items-center gap-1.5 text-amber-400 font-semibold">
              <Award className="w-3.5 h-3.5" /> Creative Explorer
            </span>
            <button
              onClick={() => setActiveTab("skills")}
              className="text-zinc-300 hover:text-white underline font-semibold transition"
            >
              Open Skill Tree
            </button>
          </div>
        </motion.div>
      </div>

      {/* 3. INTELLIGENT DASHBOARD INSIGHTS BAR */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-[#121215] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5 pb-4 border-b border-zinc-800/80">
          <div>
            <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-widest text-emerald-400">
              <TrendingUp className="w-4 h-4" /> Quantitative Telemetry
            </div>
            <h3 className="text-xl font-black text-white">
              Intelligent Dashboard Insights
            </h3>
          </div>
          <button
            onClick={() => setActiveTab("analytics")}
            className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition"
          >
            <span>Full Analytics Report</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col justify-between">
            <div className="text-xs font-bold uppercase text-zinc-500 mb-1">
              Weekly Focus Output
            </div>
            <div className="text-xl font-black text-white">
              {focusStats.weeklyHours} Hours
            </div>
            <div className="text-[11px] text-emerald-400 font-semibold mt-1">
              You've focused {focusStats.weeklyHours} hours this week
            </div>
          </div>

          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col justify-between">
            <div className="text-xs font-bold uppercase text-zinc-500 mb-1">
              Motion Graphics
            </div>
            <div className="text-xl font-black text-indigo-400">
              +18% Growth
            </div>
            <div className="text-[11px] text-zinc-400 mt-1">
              After Effects progress: {portfolioStats.afterEffectsProgress}%
            </div>
          </div>

          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col justify-between">
            <div className="text-xs font-bold uppercase text-zinc-500 mb-1">
              Most Productive Day
            </div>
            <div className="text-xl font-black text-purple-400">Tuesday</div>
            <div className="text-[11px] text-zinc-400 mt-1">
              Avg 4.8h deep work logged
            </div>
          </div>

          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col justify-between">
            <div className="text-xs font-bold uppercase text-zinc-500 mb-1">
              Avg Focus Session
            </div>
            <div className="text-xl font-black text-blue-400">62 Minutes</div>
            <div className="text-[11px] text-zinc-400 mt-1">
              Longest session: {focusStats.longestSessionMinutes} min
            </div>
          </div>

          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col justify-between">
            <div className="text-xs font-bold uppercase text-zinc-500 mb-1">
              Completion Rate
            </div>
            <div className="text-xl font-black text-emerald-400">91%</div>
            <div className="text-[11px] text-emerald-400/80 mt-1">
              Top 1% consistency bracket
            </div>
          </div>
        </div>
      </motion.div>

      {/* 4. WEEKLY PROGRESS CHART & TELEMETRY */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="bg-[#121215] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl"
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-zinc-400">
              Weekly Focus & Output Graph
            </div>
            <h3 className="text-xl font-extrabold text-white tracking-tight">
              Hours Focused Over Last 7 Days
            </h3>
          </div>
          <div className="flex items-center gap-4 text-xs font-semibold">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              Focus Hours
            </div>
          </div>
        </div>

        <div className="w-full h-56">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={chartData}
              margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
            >
              <defs>
                <linearGradient id="focusGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="name"
                stroke="#52525B"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="#52525B"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#18181B",
                  border: "1px solid #27272A",
                  borderRadius: "12px",
                  color: "#fff",
                  fontSize: "12px",
                }}
              />
              <Area
                type="monotone"
                dataKey="hours"
                stroke="#10B981"
                strokeWidth={3}
                fillOpacity={1}
                fill="url(#focusGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>
  );
}
