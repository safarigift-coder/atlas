"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  CheckSquare,
  Plus,
  Trash2,
  RefreshCw,
  Sun,
  Palette,
  Briefcase,
  Moon,
  Trophy,
  CheckCircle2,
  Zap,
} from "lucide-react";
import { soundManager } from "@/lib/sound";
import { useAtlasStore } from "@/store/atlas-store";

export function DailyMissionView() {
  const {
    dailyMissions,
    toggleMission,
    addMission,
    deleteMission,
    resetTodayMissions,
    profile,
  } = useAtlasStore();

  const [newCategory, setNewCategory] = useState("creative");
  const [newTaskName, setNewTaskName] = useState("");
  const [isAdding, setIsAdding] = useState(false);

  const categories = [
    { id: "morning", title: "Morning", icon: Sun, color: "text-amber-400" },
    {
      id: "creative",
      title: "Creative Work",
      icon: Palette,
      color: "text-purple-400",
    },
    {
      id: "business",
      title: "Business",
      icon: Briefcase,
      color: "text-blue-400",
    },
    { id: "night", title: "Night", icon: Moon, color: "text-indigo-400" },
  ];

  const missionsCompleted = dailyMissions.filter((m) => m.completed).length;
  const missionsTotal = dailyMissions.length;
  const isAllComplete =
    missionsTotal > 0 && missionsCompleted === missionsTotal;

  const handleToggle = async (id: number, currentCompleted: boolean) => {
    soundManager.playCheck(profile.soundEnabled);
    await toggleMission(id, !currentCompleted);
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskName.trim()) return;
    await addMission(newCategory, newTaskName.trim());
    setNewTaskName("");
    setIsAdding(false);
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-5xl mx-auto">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
            <CheckSquare className="w-4 h-4" /> Daily Discipline
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Daily Mission Checklist
          </h1>
          <p className="text-sm text-zinc-400 mt-1">
            "Discipline creates freedom." Show up, tick off every item, and level up your OS.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsAdding(!isAdding)}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition flex items-center gap-1.5 shadow-lg shadow-emerald-600/20"
          >
            <Plus className="w-4 h-4" /> Add Mission
          </button>
          <button
            onClick={() => resetTodayMissions()}
            className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-semibold transition flex items-center gap-1.5 border border-zinc-700/60"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Reset Today
          </button>
        </div>
      </div>

      {/* Persistent Routine Carryover Indicator */}
      <div className="bg-zinc-900/80 border border-white/10 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shrink-0">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <div className="font-extrabold text-white">
              AUTOMATIC ROUTINE ROLLOVER ACTIVE
            </div>
            <div className="text-zinc-400">
              Any custom missions you create automatically carry forward to tomorrow. You never start from scratch.
            </div>
          </div>
        </div>
        <div className="text-[11px] font-mono font-bold text-emerald-400 bg-zinc-950 px-3 py-1 rounded-xl border border-zinc-800 shrink-0">
          ✓ PostgreSQL Saved
        </div>
      </div>

      {/* Complete Banner if all checked */}
      {isAllComplete && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-r from-emerald-500/20 via-emerald-500/10 to-transparent border border-emerald-500/40 rounded-3xl p-6 flex items-center justify-between shadow-xl"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <div className="text-lg font-black text-white">
                MISSION COMPLETE
              </div>
              <div className="text-xs text-emerald-300 italic">
                "See you tomorrow." — You have completed 100% of today's checklist.
              </div>
            </div>
          </div>
          <div className="px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-bold text-xs uppercase tracking-wider">
            +Streak Active 🔥
          </div>
        </motion.div>
      )}

      {/* Add Custom Mission Form Drawer */}
      {isAdding && (
        <motion.form
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          onSubmit={handleAdd}
          className="bg-zinc-900/90 border border-emerald-500/30 rounded-2xl p-5 space-y-4"
        >
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="sm:w-48">
              <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                Category
              </label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-emerald-500"
              >
                <option value="morning">Morning</option>
                <option value="creative">Creative Work</option>
                <option value="business">Business</option>
                <option value="night">Night</option>
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                Task Name
              </label>
              <input
                type="text"
                autoFocus
                value={newTaskName}
                onChange={(e) => setNewTaskName(e.target.value)}
                placeholder="e.g. Design 3 custom logomarks"
                className="w-full bg-zinc-800 border border-zinc-700 text-white placeholder-zinc-500 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 text-zinc-400 text-xs font-semibold hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs"
            >
              Save Mission
            </button>
          </div>
        </motion.form>
      )}

      {/* Grouped Checklist by Category */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {categories.map((cat) => {
          const catMissions = dailyMissions.filter(
            (m) => m.category === cat.id
          );
          const completedCount = catMissions.filter((m) => m.completed).length;
          const Icon = cat.icon;

          return (
            <div
              key={cat.id}
              className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl flex flex-col justify-between"
            >
              <div>
                {/* Section Header */}
                <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-4">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-8 h-8 rounded-xl bg-zinc-800/80 flex items-center justify-center ${cat.color}`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="font-extrabold text-white text-base tracking-tight">
                      {cat.title}
                    </span>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-zinc-800 text-zinc-400">
                    {completedCount} / {catMissions.length}
                  </span>
                </div>

                {/* Items */}
                <div className="space-y-2.5">
                  {catMissions.length === 0 ? (
                    <div className="text-center py-6 text-zinc-500 text-xs">
                      No missions added to this category yet.
                    </div>
                  ) : (
                    catMissions.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => handleToggle(item.id, item.completed)}
                        className={`group flex items-center justify-between p-3.5 rounded-2xl border transition cursor-pointer select-none ${
                          item.completed
                            ? "bg-emerald-500/5 border-emerald-500/30 text-zinc-400"
                            : "bg-zinc-900/60 border-zinc-800/80 hover:border-zinc-700 text-zinc-200"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-6 h-6 rounded-lg flex items-center justify-center border transition ${
                              item.completed
                                ? "bg-emerald-500 border-emerald-400 text-black"
                                : "bg-zinc-800 border-zinc-700 text-transparent group-hover:border-zinc-500"
                            }`}
                          >
                            <CheckCircle2 className="w-4 h-4" />
                          </div>
                          <span
                            className={`text-sm font-semibold transition ${
                              item.completed
                                ? "line-through text-zinc-500"
                                : "text-white"
                            }`}
                          >
                            {item.taskName}
                          </span>
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteMission(item.id);
                          }}
                          className="opacity-0 group-hover:opacity-100 p-1.5 text-zinc-500 hover:text-red-400 rounded-lg transition"
                          title="Delete mission"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
