"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Quote as QuoteIcon,
  RefreshCw,
  Plus,
  Trash2,
  CheckCircle2,
  Sparkles,
  X,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";

export function QuotesView() {
  const { quote, allQuotes, rotateQuote, addQuote } = useAtlasStore();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newQuote, setNewQuote] = useState("");
  const [newAuthor, setNewAuthor] = useState("ATLAS OS");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuote.trim()) return;
    await addQuote({
      quote: newQuote.trim(),
      author: newAuthor.trim() || "ATLAS OS",
    });
    setNewQuote("");
    setNewAuthor("ATLAS OS");
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
            <QuoteIcon className="w-4 h-4" /> Psychological Fuel
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Motivational Quote Repository
          </h1>
          <p className="text-sm text-zinc-400 mt-1">
            "Consistency beats motivation." Rotating quotes to program your daily executive mindset.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => rotateQuote()}
            className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white text-xs font-semibold transition flex items-center gap-2 border border-zinc-700"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Rotate Quote</span>
          </button>

          <button
            onClick={() => setIsModalOpen(true)}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition flex items-center gap-1.5 shadow-lg shadow-emerald-600/20"
          >
            <Plus className="w-4 h-4" /> Add Quote
          </button>
        </div>
      </div>

      {/* Active Quote Banner */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-emerald-500/20 via-emerald-500/10 to-transparent border border-emerald-500/40 rounded-3xl p-8 sm:p-10 shadow-xl"
      >
        <div className="text-xs font-bold uppercase tracking-widest text-emerald-400 mb-2 flex items-center gap-2">
          <Sparkles className="w-4 h-4" /> Today's Active Quote
        </div>
        <blockquote className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-snug">
          "{quote.quote}"
        </blockquote>
        <div className="mt-3 text-sm font-bold text-zinc-300">
          — {quote.author}
        </div>
      </motion.div>

      {/* Quote Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {allQuotes.map((q) => (
          <div
            key={q.id}
            className={`bg-[#121215] border rounded-3xl p-6 shadow-xl flex flex-col justify-between transition ${
              q.activeForToday
                ? "border-emerald-500/50 bg-zinc-900/80"
                : "border-zinc-800 hover:border-zinc-700"
            }`}
          >
            <div>
              <QuoteIcon
                className={`w-6 h-6 mb-3 ${
                  q.activeForToday ? "text-emerald-400" : "text-zinc-600"
                }`}
              />
              <p className="text-base font-extrabold text-white tracking-tight leading-relaxed mb-3">
                "{q.quote}"
              </p>
              <div className="text-xs font-semibold text-zinc-400">
                — {q.author}
              </div>
            </div>

            <div className="mt-6 pt-3 border-t border-zinc-800/80 flex items-center justify-between">
              {q.activeForToday ? (
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Active Today
                </span>
              ) : (
                <button
                  onClick={() => rotateQuote()}
                  className="text-xs text-zinc-500 hover:text-white font-semibold underline transition"
                >
                  Set Active
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Add Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.form
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleSubmit}
              className="w-full max-w-md bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <h3 className="text-xl font-extrabold text-white">
                  Add Motivational Quote
                </h3>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-zinc-500 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Quote Text
                </label>
                <textarea
                  rows={3}
                  required
                  value={newQuote}
                  onChange={(e) => setNewQuote(e.target.value)}
                  placeholder="e.g. Work until your portfolio introduces you."
                  className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Author
                </label>
                <input
                  type="text"
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  placeholder="ATLAS OS"
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs"
                >
                  Save Quote
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
