"use client";

import React from "react";
import { motion } from "framer-motion";
import {
  Sparkles,
  Award,
  Plus,
  Zap,
  Image,
  PenTool,
  Video,
  Film,
  Camera,
  Code,
  Layout,
  Activity,
  TrendingUp,
  DollarSign,
  CheckCircle2,
} from "lucide-react";
import { soundManager } from "@/lib/sound";
import { useAtlasStore } from "@/store/atlas-store";

export function SkillTreeView() {
  const { skills, addSkillXp, profile } = useAtlasStore();

  const getLevelColor = (levelIndex: number) => {
    switch (levelIndex) {
      case 6: // Legend
        return "bg-amber-500/10 text-amber-400 border-amber-500/40 shadow-amber-500/20";
      case 5: // Master
        return "bg-purple-500/10 text-purple-400 border-purple-500/40";
      case 4: // Expert
        return "bg-emerald-500/10 text-emerald-400 border-emerald-500/40";
      case 3: // Professional
        return "bg-blue-500/10 text-blue-400 border-blue-500/40";
      case 2: // Explorer
        return "bg-teal-500/10 text-teal-400 border-teal-500/40";
      default: // Beginner
        return "bg-zinc-800 text-zinc-400 border-zinc-700";
    }
  };

  const getSkillIcon = (name: string) => {
    switch (name) {
      case "Photoshop":
        return Image;
      case "Illustrator":
        return PenTool;
      case "After Effects":
        return Video;
      case "Premiere Pro":
        return Film;
      case "Lightroom":
        return Camera;
      case "Web Development":
        return Code;
      case "UI Design":
        return Layout;
      case "Motion Design":
        return Activity;
      case "Marketing":
        return TrendingUp;
      case "Sales":
        return DollarSign;
      default:
        return Sparkles;
    }
  };

  const handleAward = async (skillId: number, xpAmount: number) => {
    soundManager.playCheck(profile.soundEnabled);
    await addSkillXp(skillId, xpAmount);
  };

  const categories = [
    { name: "Design", color: "text-purple-400" },
    { name: "Video & Motion", color: "text-indigo-400" },
    { name: "Tech", color: "text-emerald-400" },
    { name: "Business", color: "text-blue-400" },
  ];

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-6xl mx-auto">
      {/* Header Bar */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
          <Sparkles className="w-4 h-4" /> Gamified Learning
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          Creative Skill Tree
        </h1>
        <p className="text-sm text-zinc-400 mt-1 max-w-2xl">
          Level up your core creative and entrepreneurial skills. Every completed task, focus session, and shipped project awards XP toward mastery.
        </p>

        {/* Level Legend Bar */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-zinc-800">
          <span className="text-xs font-bold uppercase text-zinc-500 mr-2">
            Ranks:
          </span>
          {[
            { label: "Beginner", idx: 1 },
            { label: "Explorer", idx: 2 },
            { label: "Professional", idx: 3 },
            { label: "Expert", idx: 4 },
            { label: "Master", idx: 5 },
            { label: "Legend ⭐", idx: 6 },
          ].map((r) => (
            <span
              key={r.label}
              className={`px-3 py-1 rounded-full text-xs font-bold border ${getLevelColor(
                r.idx
              )}`}
            >
              {r.label}
            </span>
          ))}
        </div>
      </div>

      {/* Skills Grid by Category */}
      <div className="space-y-8">
        {categories.map((cat) => {
          const catSkills = skills.filter((s) => s.category === cat.name);
          if (catSkills.length === 0) return null;

          return (
            <div key={cat.name} className="space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-zinc-400 px-1">
                <span className={cat.color}>●</span> {cat.name} Mastery
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {catSkills.map((skill) => {
                  const Icon = getSkillIcon(skill.name);
                  const progressPercent = Math.min(
                    100,
                    Math.round((skill.currentXp / 2000) * 100)
                  );

                  return (
                    <motion.div
                      key={skill.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-[#121215] border border-zinc-800 hover:border-zinc-700 rounded-3xl p-6 shadow-xl flex flex-col justify-between transition group"
                    >
                      <div>
                        {/* Title and Level Rank Badge */}
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-emerald-400 group-hover:border-emerald-500/40 transition">
                              <Icon className="w-5 h-5" />
                            </div>
                            <div>
                              <h3 className="text-lg font-extrabold text-white tracking-tight">
                                {skill.name}
                              </h3>
                              <div className="text-xs text-zinc-500">
                                {skill.tasksCompletedCount} practice tasks completed
                              </div>
                            </div>
                          </div>

                          <span
                            className={`px-3 py-1 rounded-full text-xs font-bold border ${getLevelColor(
                              skill.levelIndex
                            )}`}
                          >
                            {skill.level}
                          </span>
                        </div>

                        {/* XP Progress Bar */}
                        <div className="mb-4">
                          <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                            <span className="text-zinc-400">
                              XP Mastery Bar
                            </span>
                            <span className="text-emerald-400 font-mono">
                              {skill.currentXp} / 2,000 XP
                            </span>
                          </div>
                          <div className="w-full h-2.5 rounded-full bg-zinc-900 overflow-hidden border border-zinc-800/80">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${progressPercent}%` }}
                              transition={{ duration: 0.8, ease: "easeOut" }}
                              className="h-full bg-gradient-to-r from-emerald-500 to-blue-500 rounded-full"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Quick Award Actions */}
                      <div className="flex items-center justify-between pt-4 border-t border-zinc-800/80 gap-2">
                        <button
                          onClick={() => handleAward(skill.id, 50)}
                          className="flex-1 px-3 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold transition flex items-center justify-center gap-1"
                        >
                          <Plus className="w-3.5 h-3.5 text-emerald-400" />
                          <span>+50 XP Practice</span>
                        </button>

                        <button
                          onClick={() => handleAward(skill.id, 120)}
                          className="flex-1 px-3 py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs font-semibold transition flex items-center justify-center gap-1"
                        >
                          <Zap className="w-3.5 h-3.5" />
                          <span>+120 XP Deep Work</span>
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
