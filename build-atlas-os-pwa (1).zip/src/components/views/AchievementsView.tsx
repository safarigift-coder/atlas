"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Award,
  Flame,
  Zap,
  Rocket,
  Briefcase,
  DollarSign,
  Palette,
  Globe,
  Film,
  Trophy,
  Lock,
  CheckCircle2,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";

export function AchievementsView() {
  const { achievements, profile } = useAtlasStore();
  const [filter, setFilter] = useState<"All" | "Unlocked" | "Locked">("All");

  const getBadgeIcon = (iconName: string) => {
    switch (iconName) {
      case "Flame":
        return Flame;
      case "Zap":
        return Zap;
      case "Rocket":
        return Rocket;
      case "Briefcase":
        return Briefcase;
      case "DollarSign":
        return DollarSign;
      case "Palette":
        return Palette;
      case "Globe":
        return Globe;
      case "Film":
        return Film;
      default:
        return Trophy;
    }
  };

  const unlockedCount = achievements.filter((a) => a.unlocked).length;
  const filtered =
    filter === "All"
      ? achievements
      : achievements.filter((a) =>
          filter === "Unlocked" ? a.unlocked : !a.unlocked
        );

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-6xl mx-auto">
      {/* Trophy Room Hero Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-zinc-900 via-zinc-900/95 to-zinc-900/70 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="absolute -top-16 -right-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
            <Award className="w-4 h-4" /> Personal Hall of Fame
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            ATLAS OS Trophy Room
          </h1>
          <p className="text-sm text-zinc-400 mt-1">
            Celebrating consistency, discipline, and creative milestones.
          </p>
        </div>

        <div className="flex items-center gap-4 bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-black text-white">
              {unlockedCount} / {achievements.length}
            </div>
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              Badges Unlocked
            </div>
          </div>
        </div>
      </div>

      {/* Filter Buttons */}
      <div className="flex items-center gap-2">
        {(["All", "Unlocked", "Locked"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition border ${
              filter === tab
                ? "bg-zinc-800 text-white border-emerald-500/50 shadow-sm"
                : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white"
            }`}
          >
            {tab}{" "}
            <span
              className={`ml-1 px-1.5 py-0.5 rounded-full text-[10px] ${
                filter === tab
                  ? "bg-emerald-500/20 text-emerald-400"
                  : "bg-zinc-800 text-zinc-500"
              }`}
            >
              {tab === "All"
                ? achievements.length
                : tab === "Unlocked"
                ? unlockedCount
                : achievements.length - unlockedCount}
            </span>
          </button>
        ))}
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((badge) => {
          const Icon = getBadgeIcon(badge.icon);

          return (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className={`relative rounded-3xl p-6 border transition flex flex-col justify-between shadow-xl ${
                badge.unlocked
                  ? "bg-[#121215] border-emerald-500/30 hover:border-emerald-500/60"
                  : "bg-[#121215]/60 border-zinc-800/80 opacity-60 hover:opacity-90"
              }`}
            >
              <div>
                {/* Icon & Status */}
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center border ${
                      badge.unlocked
                        ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 shadow-lg shadow-emerald-500/10"
                        : "bg-zinc-900 text-zinc-600 border-zinc-800"
                    }`}
                  >
                    <Icon className="w-7 h-7" />
                  </div>

                  {badge.unlocked ? (
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-extrabold border border-emerald-500/30">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-zinc-900 text-zinc-500 text-xs font-extrabold border border-zinc-800">
                      <Lock className="w-3 h-3" />
                      LOCKED
                    </span>
                  )}
                </div>

                {/* Title and Description */}
                <h3 className="text-xl font-extrabold text-white tracking-tight">
                  {badge.title}
                </h3>
                <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                  {badge.description}
                </p>
              </div>

              {/* Unlocked Date Footer */}
              <div className="mt-6 pt-4 border-t border-zinc-800/80 flex items-center justify-between text-xs font-medium">
                <span className="text-zinc-500 uppercase tracking-wider">
                  Category: {badge.category}
                </span>
                {badge.unlocked && badge.unlockedAt ? (
                  <span className="text-emerald-400 font-semibold">
                    {badge.unlockedAt}
                  </span>
                ) : (
                  <span className="text-zinc-600 italic">In progress</span>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
