"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Timer,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  Flame,
  Award,
  History,
  Maximize2,
  Minimize2,
  Plus,
  Minus,
  Quote,
  Zap,
} from "lucide-react";
import { soundManager } from "@/lib/sound";
import { useAtlasStore } from "@/store/atlas-store";

export function PomodoroView() {
  const {
    focusStats,
    pomodoroSessions,
    skills,
    logPomodoro,
    profile,
  } = useAtlasStore();

  const [mode, setMode] = useState<
    "25/5" | "50/10" | "90min" | "Deep Work" | "custom"
  >("Deep Work");
  const [secondsLeft, setSecondsLeft] = useState(90 * 60);
  const [isActive, setIsActive] = useState(false);
  const [selectedSkillId, setSelectedSkillId] = useState<number | undefined>(
    skills[0]?.id
  );
  const [sessionNotes, setSessionNotes] = useState(
    "After Effects & UI Design System"
  );
  const [sessionSuccess, setSessionSuccess] = useState(false);

  // Fullscreen Deep Work State
  const [isFullscreenDeepWork, setIsFullscreenDeepWork] = useState(false);
  const [interruptions, setInterruptions] = useState(0);

  const focusQuotes = [
    "Work until your portfolio introduces you.",
    "Discipline creates freedom.",
    "Deep work is the superpower of the 21st century.",
    "Stay locked in.",
    "Small actions. Massive results.",
  ];
  const [quoteIndex, setQuoteIndex] = useState(0);

  // Rotate focus quotes every 30 seconds in Deep Work
  useEffect(() => {
    if (isFullscreenDeepWork) {
      const qInt = setInterval(() => {
        setQuoteIndex((i) => (i + 1) % focusQuotes.length);
      }, 30000);
      return () => clearInterval(qInt);
    }
  }, [isFullscreenDeepWork, focusQuotes.length]);

  // Switch mode timers
  const selectMode = (
    m: "25/5" | "50/10" | "90min" | "Deep Work" | "custom"
  ) => {
    setIsActive(false);
    setMode(m);
    if (m === "25/5") setSecondsLeft(25 * 60);
    else if (m === "50/10") setSecondsLeft(50 * 60);
    else if (m === "90min" || m === "Deep Work") setSecondsLeft(90 * 60);
    else setSecondsLeft(60 * 60);
  };

  useEffect(() => {
    let interval: any = null;
    if (isActive && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((s) => s - 1);
      }, 1000);
    } else if (secondsLeft === 0 && isActive) {
      setIsActive(false);
      soundManager.playTimerBell(profile.soundEnabled);
      handleCompleteSession();
    }
    return () => clearInterval(interval);
  }, [isActive, secondsLeft]);

  const handleCompleteSession = async () => {
    const totalMinutes =
      mode === "25/5"
        ? 25
        : mode === "50/10"
        ? 50
        : mode === "90min" || mode === "Deep Work"
        ? 90
        : 60;
    await logPomodoro(
      totalMinutes,
      mode,
      sessionNotes || "Focus Session",
      selectedSkillId
    );
    setSessionSuccess(true);
    setIsFullscreenDeepWork(false);
    setTimeout(() => setSessionSuccess(false), 5000);
  };

  const formatTime = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  const totalModeSecs =
    mode === "25/5"
      ? 25 * 60
      : mode === "50/10"
      ? 50 * 60
      : mode === "90min" || mode === "Deep Work"
      ? 90 * 60
      : 60 * 60;

  const progressPercent = Math.round(
    ((totalModeSecs - secondsLeft) / totalModeSecs) * 100
  );

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-5xl mx-auto">
      {/* 4 Focus Metrics Header */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              Today's Focus
            </div>
            <div className="text-2xl font-black text-emerald-400 mt-1">
              {focusStats.todayHours} <span className="text-xs">hrs</span>
            </div>
          </div>
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
            <Timer className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              Weekly Focus
            </div>
            <div className="text-2xl font-black text-blue-400 mt-1">
              {focusStats.weeklyHours} <span className="text-xs">hrs</span>
            </div>
          </div>
          <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
            <Flame className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              Monthly Focus
            </div>
            <div className="text-2xl font-black text-purple-400 mt-1">
              {focusStats.monthlyHours} <span className="text-xs">hrs</span>
            </div>
          </div>
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center">
            <Award className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              Longest Session
            </div>
            <div className="text-2xl font-black text-amber-400 mt-1">
              {focusStats.longestSessionMinutes || 90}{" "}
              <span className="text-xs">min</span>
            </div>
          </div>
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
            <Zap className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Main Timer Card */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-8 sm:p-12 shadow-2xl flex flex-col items-center justify-center text-center relative overflow-hidden">
        {/* Subtle Ambient Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-tr from-emerald-500/15 via-blue-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        {/* Mode Selector */}
        <div className="flex flex-wrap items-center justify-center gap-2 p-1.5 rounded-2xl bg-zinc-900 border border-zinc-800 mb-8 z-10">
          {(["25/5", "50/10", "90min", "Deep Work"] as const).map((m) => (
            <button
              key={m}
              onClick={() => selectMode(m)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                mode === m
                  ? "bg-zinc-800 text-emerald-400 shadow-sm border border-zinc-700"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              {m === "Deep Work" ? "⚡ Deep Work (90m)" : `${m} Min`}
            </button>
          ))}
        </div>

        {/* Huge Digital Clock Display */}
        <div className="relative my-4 z-10">
          <motion.div
            key={formatTime(secondsLeft)}
            className="text-7xl sm:text-8xl lg:text-9xl font-black text-white font-mono tracking-tighter select-none"
          >
            {formatTime(secondsLeft)}
          </motion.div>
          <div className="mt-2 text-xs font-bold uppercase tracking-widest text-zinc-500">
            {isActive
              ? `FOCUSING — ${progressPercent}% DONE`
              : "READY TO START SESSION"}
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center justify-center gap-4 my-6 z-10">
          {!isActive ? (
            <button
              onClick={() => {
                soundManager.playCheck(profile.soundEnabled);
                setIsActive(true);
              }}
              className="px-8 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-base transition shadow-xl shadow-emerald-500/20 flex items-center gap-2.5"
            >
              <Play className="w-5 h-5 fill-black" />
              Start Focus
            </button>
          ) : (
            <button
              onClick={() => setIsActive(false)}
              className="px-8 py-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-base transition shadow-xl shadow-amber-500/20 flex items-center gap-2.5"
            >
              <Pause className="w-5 h-5 fill-black" />
              Pause
            </button>
          )}

          <button
            onClick={() => {
              setIsActive(false);
              selectMode(mode);
            }}
            title="Reset timer"
            className="p-4 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white transition"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            onClick={() => setIsFullscreenDeepWork(true)}
            title="Enter fullscreen deep work mode"
            className="px-5 py-4 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-blue-400 font-bold text-sm transition flex items-center gap-2"
          >
            <Maximize2 className="w-4 h-4" />
            <span>Fullscreen Mode</span>
          </button>

          <button
            onClick={handleCompleteSession}
            title="Mark session complete now"
            className="px-5 py-4 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-emerald-400 font-bold text-sm transition flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            Finish & Log
          </button>
        </div>

        {/* Skill Attribution & Task Note Input */}
        <div className="w-full max-w-lg mt-4 pt-6 border-t border-zinc-800/80 grid grid-cols-1 sm:grid-cols-2 gap-4 text-left z-10">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              Award XP To Skill Tree
            </label>
            <select
              value={selectedSkillId}
              onChange={(e) => setSelectedSkillId(Number(e.target.value))}
              className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-emerald-500"
            >
              {skills.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.level})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              Session Focus Note
            </label>
            <input
              type="text"
              value={sessionNotes}
              onChange={(e) => setSessionNotes(e.target.value)}
              placeholder="e.g. After Effects kinetic type"
              className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Success Alert */}
        {sessionSuccess && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 px-4 py-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center gap-2 z-10"
          >
            <Sparkles className="w-4 h-4" /> Focus Session Logged! +XP added to
            your Skill Tree & Today's Hours updated.
          </motion.div>
        )}
      </div>

      {/* FULLSCREEN DEEP WORK OVERLAY */}
      <AnimatePresence>
        {isFullscreenDeepWork && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-[#09090B] flex flex-col justify-between p-8 text-center select-none"
          >
            {/* Top Bar: Exit & Interruption Counter */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-extrabold uppercase tracking-widest flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5" /> FULLSCREEN DEEP WORK
                </div>
                <div className="text-xs text-zinc-500">
                  Notifications & distractions muted
                </div>
              </div>

              <div className="flex items-center gap-4">
                {/* Track Interruptions */}
                <div className="flex items-center gap-2 bg-zinc-900/80 border border-zinc-800 rounded-xl px-3 py-1.5">
                  <span className="text-xs font-bold text-zinc-400">
                    Interruptions: {interruptions}
                  </span>
                  <button
                    onClick={() => setInterruptions((i) => i + 1)}
                    title="Log an interruption"
                    className="p-1 rounded bg-zinc-800 hover:bg-zinc-700 text-amber-400"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() =>
                      setInterruptions((i) => Math.max(0, i - 1))
                    }
                    className="p-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-400"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                </div>

                <button
                  onClick={() => setIsFullscreenDeepWork(false)}
                  className="p-2.5 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 transition"
                  title="Exit Fullscreen Mode"
                >
                  <Minimize2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Giant Center Timer */}
            <div className="my-auto space-y-6">
              <motion.div
                key={formatTime(secondsLeft)}
                className="text-8xl sm:text-9xl lg:text-[11rem] font-black text-white font-mono tracking-tighter"
              >
                {formatTime(secondsLeft)}
              </motion.div>

              <div className="text-base font-extrabold text-zinc-400 tracking-wide uppercase">
                {sessionNotes || "DEEP WORK IN PROGRESS"}
              </div>

              {/* Control Buttons */}
              <div className="flex items-center justify-center gap-4 pt-4">
                {!isActive ? (
                  <button
                    onClick={() => {
                      soundManager.playCheck(profile.soundEnabled);
                      setIsActive(true);
                    }}
                    className="px-10 py-5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-lg transition shadow-xl shadow-emerald-500/20 flex items-center gap-3"
                  >
                    <Play className="w-6 h-6 fill-black" />
                    Resume Deep Work
                  </button>
                ) : (
                  <button
                    onClick={() => setIsActive(false)}
                    className="px-10 py-5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-black text-lg transition shadow-xl shadow-amber-500/20 flex items-center gap-3"
                  >
                    <Pause className="w-6 h-6 fill-black" />
                    Pause Session
                  </button>
                )}

                <button
                  onClick={handleCompleteSession}
                  className="px-8 py-5 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-emerald-400 font-extrabold text-base transition flex items-center gap-2.5"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  Complete & Log XP
                </button>
              </div>
            </div>

            {/* Bottom Rotating Focus Quote */}
            <div className="max-w-2xl mx-auto text-zinc-500 text-sm italic font-medium flex items-center justify-center gap-2">
              <Quote className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>"{focusQuotes[quoteIndex]}"</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Recent Pomodoro Sessions Log */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2 font-extrabold text-white">
            <History className="w-4 h-4 text-emerald-400" />
            <span>Recent Focus Logs</span>
          </div>
          <span className="text-xs text-zinc-500">
            {pomodoroSessions.length} total sessions recorded
          </span>
        </div>

        <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
          {pomodoroSessions.slice(0, 10).map((s) => (
            <div
              key={s.id}
              className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 text-sm"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 font-bold text-xs flex items-center justify-center">
                  {s.durationMinutes}m
                </div>
                <div>
                  <div className="font-semibold text-white">{s.notes}</div>
                  <div className="text-xs text-zinc-500">
                    Mode: {s.mode} • Date: {s.date}{" "}
                    {s.interruptions > 0 && `• ${s.interruptions} interruptions`}
                  </div>
                </div>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-zinc-800 text-emerald-400">
                +{(s.durationMinutes / 60).toFixed(1)} hrs
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
