"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Compass,
  Sparkles,
  Award,
  Calendar,
  Plus,
  Trash2,
  Edit3,
  CheckCircle2,
  Image as ImageIcon,
  Quote,
  Volume2,
  VolumeX,
  ArrowRight,
  Shield,
  Heart,
  Target,
  Zap,
  Check,
  X,
  ExternalLink,
  Lock,
  Layers,
  Monitor,
  Camera,
  Laptop,
  Sun,
  BookOpen,
  Layout,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";
import { ambientAudioPlayer, AmbientTrack } from "@/lib/ambient-audio";
import { soundManager } from "@/lib/sound";

export function FutureRoomView() {
  const {
    profile,
    futureRoomData,
    saveFutureRoomConfig,
    addIdentityStatement,
    updateIdentityStatement,
    deleteIdentityStatement,
    addTimelineItem,
    updateTimelineItem,
    deleteTimelineItem,
    visionBoardItems,
    addVisionBoardItem,
    updateVisionBoardItem,
    deleteVisionBoardItem,
    legacyEntries,
    portfolioProjects,
    clients,
    incomeStats,
  } = useAtlasStore();

  // 1. Welcome Screen State
  const [hasEnteredRoom, setHasEnteredRoom] = useState(false);

  // 2. Ambient Audio State
  const [activeAudio, setActiveAudio] = useState<AmbientTrack>("off");

  // Automatically pause ambient audio when component unmounts / leaving tab
  useEffect(() => {
    return () => {
      ambientAudioPlayer.stop();
    };
  }, []);

  const handleSelectAudio = (track: AmbientTrack) => {
    setActiveAudio(track);
    ambientAudioPlayer.play(track, 0.18);
  };

  // 3. Vision Board Category Filtering & Modal
  const visionCategories = [
    "All",
    "Dream Workspace",
    "Dream Laptop",
    "Dream Camera",
    "Dream Office",
    "Dream House",
    "Dream Car",
    "Dream Lifestyle",
    "Travel Goals",
    "Family Goals",
    "Health Goals",
    "Creative Goals",
    "Financial Goals",
    "Personal Growth",
  ];
  const [visionCat, setVisionCat] = useState("All");
  const [isVisionModalOpen, setIsVisionModalOpen] = useState(false);
  const [vTitle, setVTitle] = useState("");
  const [vCategory, setVCategory] = useState("Dream Workspace");
  const [vImageUrl, setVImageUrl] = useState("");
  const [vCaption, setVCaption] = useState("");
  const [vDate, setVDate] = useState("2026-12-31");
  const [vProgress, setVProgress] = useState(40);

  const filteredVision =
    visionCat === "All"
      ? visionBoardItems
      : visionBoardItems.filter((item) => item.category === visionCat);

  const handleAddVision = async (e: React.FormEvent) => {
    e.preventDefault();
    await addVisionBoardItem({
      title: vTitle || "Dream Studio Workspace",
      category: vCategory || "Dream Workspace",
      imageUrl:
        vImageUrl ||
        "https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=800&q=80",
      caption:
        vCaption || "A floor-to-ceiling studio designed for total focus.",
      targetDate: vDate || "2026-12-31",
      progress: Number(vProgress) || 40,
      achieved: false,
    });
    setIsVisionModalOpen(false);
    setVTitle("");
    setVCaption("");
  };

  // 4. Identity Statements Editing State
  const [isAddingIdentity, setIsAddingIdentity] = useState(false);
  const [newStatement, setNewStatement] = useState("");
  const handleAddStatement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStatement.trim()) return;
    await addIdentityStatement(newStatement.trim());
    setNewStatement("");
    setIsAddingIdentity(false);
  };

  // 5. Letter from Future Self State
  const [isEditingLetter, setIsEditingLetter] = useState(false);
  const [letterText, setLetterText] = useState(
    futureRoomData.config.letterFromFuture ||
      `Dear Gift,\n\nThank you for refusing to quit.\n\nThe mornings you wanted to stay in bed...\nThe nights you kept practicing...\nThe projects nobody noticed...\n\nThey changed everything.\n\nYou now own the studio you once dreamed about.\nClients respect your work.\nYour family is proud.\n\nKeep going.\nI'm waiting for you.`
  );
  const [letterSaved, setLetterSaved] = useState(false);

  const handleSaveLetter = async () => {
    await saveFutureRoomConfig({ letterFromFuture: letterText });
    setIsEditingLetter(false);
    setLetterSaved(true);
    setTimeout(() => setLetterSaved(false), 3000);
  };

  // 6. Why I Started State
  const [isEditingWhy, setIsEditingWhy] = useState(false);
  const [whyText, setWhyText] = useState(
    futureRoomData.config.whyIStarted ||
      "Because I refused to settle for an ordinary life. Every day I wake up with the opportunity to build my own future, achieve financial freedom, and create work that inspires the world."
  );
  const [whySaved, setWhySaved] = useState(false);

  const handleSaveWhy = async () => {
    await saveFutureRoomConfig({ whyIStarted: whyText });
    setIsEditingWhy(false);
    setWhySaved(true);
    setTimeout(() => setWhySaved(false), 3000);
  };

  // 7. My Legacy Progress Ring & Traits
  const meaningfulDaysCount = legacyEntries.filter((e) => e.meaningful).length;
  const legacyProgress = Math.min(
    100,
    Math.max(15, Math.round((meaningfulDaysCount / 30) * 100))
  );
  const [newTrait, setNewTrait] = useState("");
  const [isAddingTrait, setIsAddingTrait] = useState(false);

  const handleAddTrait = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTrait.trim()) return;
    const updatedTraits = [
      ...(futureRoomData.config.legacyTraits || []),
      newTrait.trim(),
    ];
    await saveFutureRoomConfig({ legacyTraits: updatedTraits });
    setNewTrait("");
    setIsAddingTrait(false);
  };

  const handleRemoveTrait = async (idxToRemove: number) => {
    const updatedTraits = futureRoomData.config.legacyTraits.filter(
      (_, idx) => idx !== idxToRemove
    );
    await saveFutureRoomConfig({ legacyTraits: updatedTraits });
  };

  // 8. Cost of Quitting & Reward of Consistency State
  const [isAddingCost, setIsAddingCost] = useState(false);
  const [newCost, setNewCost] = useState("");
  const handleAddCost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCost.trim()) return;
    const updated = [
      ...(futureRoomData.config.costOfQuitting || []),
      newCost.trim(),
    ];
    await saveFutureRoomConfig({ costOfQuitting: updated });
    setNewCost("");
    setIsAddingCost(false);
  };

  const [isAddingReward, setIsAddingReward] = useState(false);
  const [newReward, setNewReward] = useState("");
  const handleAddReward = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReward.trim()) return;
    const updated = [
      ...(futureRoomData.config.rewardOfConsistency || []),
      newReward.trim(),
    ];
    await saveFutureRoomConfig({ rewardOfConsistency: updated });
    setNewReward("");
    setIsAddingReward(false);
  };

  // 9. Dream Life Timeline Modal
  const [isTimelineModalOpen, setIsTimelineModalOpen] = useState(false);
  const [tYear, setTYear] = useState("2029");
  const [tTitle, setTTitle] = useState("Global Creative Impact");
  const [tMilestoneStr, setTMilestoneStr] = useState(
    "Open flagship design studio, Scale international team"
  );

  const handleAddTimeline = async (e: React.FormEvent) => {
    e.preventDefault();
    const milestones = tMilestoneStr
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    await addTimelineItem(
      Number(tYear) || 2029,
      tTitle || "New Milestone",
      milestones
    );
    setIsTimelineModalOpen(false);
    setTTitle("");
    setTMilestoneStr("");
  };

  // 10. Rotating Quote of the Future
  const futureQuotes = [
    "The work you avoid today is the life you delay tomorrow.",
    "You are already becoming the person you admire.",
    "Every masterpiece begins with an ordinary day.",
    "Consistency is your superpower.",
    "Future you is counting on today's effort.",
  ];
  const [quoteIdx, setQuoteIdx] = useState(0);

  useEffect(() => {
    const intId = setInterval(() => {
      setQuoteIdx((i) => (i + 1) % futureQuotes.length);
    }, 12000);
    return () => clearInterval(intId);
  }, [futureQuotes.length]);

  // 11. The Future Studio item toggle
  const handleToggleStudioItem = async (itemIndex: number) => {
    const updated = futureRoomData.config.studioItems.map((item, idx) => {
      if (idx === itemIndex) {
        return { ...item, achieved: !item.achieved };
      }
      return item;
    });
    soundManager.playCheck(profile.soundEnabled);
    await saveFutureRoomConfig({ studioItems: updated });
  };

  const achievedStudioCount =
    futureRoomData.config.studioItems?.filter((i) => i.achieved).length || 0;
  const studioTotal = futureRoomData.config.studioItems?.length || 7;
  const studioLifePercent = Math.round(
    (achievedStudioCount / studioTotal) * 100
  );

  // 12. Future Metrics Calculations
  const portfolioPercent = Math.min(
    100,
    Math.round((portfolioProjects.length / 10) * 100)
  );
  const clientsPercent = Math.min(
    100,
    Math.round((clients.length / 12) * 100)
  );
  const incomeGoalPercent = Math.min(
    100,
    Math.round((incomeStats.yearlyIncome / 100000) * 100)
  );
  const afterEffectsPercent = 71;
  const webDevPercent = 90;

  // WELCOME SCREEN OVERLAY
  if (!hasEnteredRoom) {
    return (
      <div className="relative min-h-[85vh] flex items-center justify-center p-6 select-none overflow-hidden">
        {/* Cinematic Ambient Nebula Light & Noise */}
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-emerald-500/20 rounded-full blur-[140px] pointer-events-none animate-pulse" />
        <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-purple-500/20 rounded-full blur-[140px] pointer-events-none animate-pulse" />

        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="relative z-10 max-w-2xl text-center space-y-8 bg-[#121215]/80 border border-white/10 rounded-3xl p-10 sm:p-14 shadow-[0_0_80px_rgba(16,185,129,0.15)] backdrop-blur-2xl"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-black uppercase tracking-widest shadow-lg">
            <Compass className="w-3.5 h-3.5" /> ATLAS OS VISION SANCTUARY
          </div>

          <div className="space-y-3">
            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
              Welcome back, {profile.name}.
            </h1>

            <p className="text-base sm:text-lg font-medium text-zinc-300 leading-relaxed max-w-xl mx-auto">
              Every decision you make today shapes the life you'll live tomorrow.
            </p>
          </div>

          <div className="pt-4">
            <button
              onClick={() => {
                soundManager.playVictory(profile.soundEnabled);
                setHasEnteredRoom(true);
              }}
              className="group relative inline-flex items-center justify-center px-10 py-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-blue-500 text-black font-black text-sm uppercase tracking-widest transition duration-300 shadow-[0_10px_35px_rgba(16,185,129,0.4)] hover:shadow-[0_15px_45px_rgba(16,185,129,0.6)] hover:scale-105 active:scale-98"
            >
              <span>ENTER THE FUTURE</span>
              <ArrowRight className="w-4 h-4 ml-2.5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          <div className="text-xs font-mono font-semibold text-zinc-500 uppercase tracking-widest pt-2">
            "The future is built by today's decisions."
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-12 p-4 sm:p-8 max-w-7xl mx-auto relative overflow-hidden">
      {/* Cinematic Sci-fi Ambient Light Rays */}
      <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-gradient-to-br from-emerald-500/10 via-blue-500/10 to-transparent rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute bottom-1/3 left-0 w-[500px] h-[500px] bg-gradient-to-tr from-purple-500/10 via-emerald-500/5 to-transparent rounded-full blur-[160px] pointer-events-none" />

      {/* 1. PAGE TITLE & OPTIONAL AMBIENT MUSIC PLAYER BAR */}
      <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-400 mb-2">
            <Compass className="w-4 h-4" /> SANCTUARY OF LONG-TERM IDENTITY
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            THE FUTURE ROOM
          </h1>
          <p className="text-sm sm:text-base font-semibold text-zinc-400 mt-1 italic">
            "The future is built by today's decisions."
          </p>
          <div className="pt-3">
            <button
              onClick={() => useAtlasStore.getState().setActiveTab("promise")}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-blue-500/20 hover:from-emerald-500/30 hover:to-blue-500/30 text-emerald-400 text-xs font-black uppercase tracking-wider transition border border-emerald-500/30 flex items-center gap-1.5"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Open The Sacred Covenant (The Promise)</span>
            </button>
          </div>
        </div>

        {/* Ambient Experience Audio Player */}
        <div className="bg-zinc-900/90 border border-white/10 rounded-2xl p-4 flex flex-wrap items-center gap-3 backdrop-blur-md">
          <div className="flex items-center gap-2 mr-1">
            {activeAudio !== "off" ? (
              <Volume2 className="w-4 h-4 text-emerald-400 animate-pulse" />
            ) : (
              <VolumeX className="w-4 h-4 text-zinc-500" />
            )}
            <span className="text-xs font-extrabold uppercase tracking-wider text-zinc-300">
              Ambient Audio:
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {(["rain", "forest", "cafe", "lofi", "ocean", "off"] as const).map(
              (track) => {
                const isSelected = activeAudio === track;
                const labels: Record<AmbientTrack, string> = {
                  rain: "🌧️ Rain",
                  forest: "🌲 Forest",
                  cafe: "☕ Cafe",
                  lofi: "🎧 Lo-fi",
                  ocean: "🌊 Ocean",
                  off: "Off",
                };
                return (
                  <button
                    key={track}
                    onClick={() => handleSelectAudio(track)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition border ${
                      isSelected
                        ? "bg-emerald-500 text-black border-emerald-400 shadow-md shadow-emerald-500/20"
                        : "bg-zinc-800 text-zinc-400 border-zinc-700/80 hover:text-white"
                    }`}
                  >
                    {labels[track]}
                  </button>
                );
              }
            )}
          </div>
        </div>
      </div>

      {/* 2. THE PERSON I AM BECOMING (IDENTITY STATEMENTS) */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#121215]/90 border border-white/10 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-xl"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-800/80 mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-400">
              <Sparkles className="w-4 h-4" /> Psychological Programming
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              The Person I Am Becoming
            </h2>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              Identity precedes action. You do not rise to the level of your goals; you fall to the level of your identity.
            </p>
          </div>

          <button
            onClick={() => setIsAddingIdentity(!isAddingIdentity)}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-black text-xs transition flex items-center gap-1.5 shadow-lg shadow-emerald-600/20"
          >
            <Plus className="w-4 h-4" /> Add Identity Statement
          </button>
        </div>

        {/* Add Statement Drawer */}
        <AnimatePresence>
          {isAddingIdentity && (
            <motion.form
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              onSubmit={handleAddStatement}
              className="bg-zinc-900/90 border border-emerald-500/40 rounded-2xl p-5 mb-6 flex flex-col sm:flex-row items-center gap-3"
            >
              <input
                type="text"
                autoFocus
                value={newStatement}
                onChange={(e) => setNewStatement(e.target.value)}
                placeholder="e.g. I create world-class work every single day."
                className="w-full bg-zinc-800 border border-zinc-700 text-white placeholder-zinc-500 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-emerald-500"
              />
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => setIsAddingIdentity(false)}
                  className="px-4 py-2.5 rounded-xl bg-zinc-800 text-zinc-400 text-xs font-bold hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-black text-xs"
                >
                  Save Statement
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>

        {/* Statements Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {futureRoomData.identityStatements.map((item) => (
            <motion.div
              key={item.id}
              whileHover={{ y: -3 }}
              className="group bg-zinc-900/60 border border-zinc-800/80 hover:border-emerald-500/40 rounded-2xl p-5 shadow-lg flex items-start justify-between transition"
            >
              <div className="flex items-start gap-3">
                <div className="w-7 h-7 rounded-xl bg-emerald-500/10 text-emerald-400 font-black text-xs flex items-center justify-center shrink-0 border border-emerald-500/20">
                  ⚡
                </div>
                <div className="text-base font-extrabold text-white tracking-tight leading-snug">
                  "{item.statement}"
                </div>
              </div>

              <button
                onClick={() => deleteIdentityStatement(item.id)}
                className="opacity-0 group-hover:opacity-100 p-1 text-zinc-500 hover:text-red-400 transition"
                title="Remove statement"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* 3. LETTER FROM MY FUTURE SELF & WHY I STARTED */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Letter From My Future Self */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 shadow-2xl backdrop-blur-xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-6">
              <div>
                <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-400">
                  <BookOpen className="w-4 h-4" /> Long-Term Compass
                </div>
                <h3 className="text-2xl font-black text-white tracking-tight">
                  Letter From My Future Self
                </h3>
              </div>

              {!isEditingLetter ? (
                <button
                  onClick={() => setIsEditingLetter(true)}
                  className="px-3.5 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-zinc-700"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit Letter</span>
                </button>
              ) : (
                <button
                  onClick={handleSaveLetter}
                  className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs transition"
                >
                  Save Letter
                </button>
              )}
            </div>

            {!isEditingLetter ? (
              <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-6 font-mono text-sm sm:text-base text-zinc-200 leading-relaxed whitespace-pre-wrap italic">
                {letterText}
              </div>
            ) : (
              <textarea
                rows={10}
                value={letterText}
                onChange={(e) => setLetterText(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 text-white font-mono text-sm rounded-2xl p-5 focus:outline-none focus:border-emerald-500 leading-relaxed"
              />
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-500">
            <span>Saves automatically to permanent database</span>
            {letterSaved && (
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Saved
              </span>
            )}
          </div>
        </motion.div>

        {/* Why I Started ("Why can't I give up?") */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 shadow-2xl backdrop-blur-xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-6">
              <div>
                <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-blue-400">
                  <Shield className="w-4 h-4" /> Unshakable Foundation
                </div>
                <h3 className="text-2xl font-black text-white tracking-tight">
                  Why I Started
                </h3>
                <div className="text-xs font-bold text-zinc-400 mt-0.5">
                  Why can't I give up?
                </div>
              </div>

              {!isEditingWhy ? (
                <button
                  onClick={() => setIsEditingWhy(true)}
                  className="px-3.5 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-zinc-700"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit Reason</span>
                </button>
              ) : (
                <button
                  onClick={handleSaveWhy}
                  className="px-4 py-1.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-black font-black text-xs transition"
                >
                  Save Reason
                </button>
              )}
            </div>

            {!isEditingWhy ? (
              <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-6 font-sans text-base sm:text-lg font-bold text-zinc-100 leading-relaxed">
                "{whyText}"
              </div>
            ) : (
              <textarea
                rows={8}
                value={whyText}
                onChange={(e) => setWhyText(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 text-white font-sans text-base rounded-2xl p-5 focus:outline-none focus:border-blue-500 leading-relaxed"
              />
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-500">
            <span>Every time you visit this room, remember why you began.</span>
            {whySaved && (
              <span className="text-blue-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Saved
              </span>
            )}
          </div>
        </motion.div>
      </div>

      {/* 4. MY LEGACY & PROGRESS RING */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-10 shadow-2xl backdrop-blur-xl"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left: Attributes (8 cols) */}
          <div className="lg:col-span-8 space-y-5">
            <div>
              <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-purple-400 mb-1">
                <Heart className="w-4 h-4" /> Moral & Character Telemetry
              </div>
              <h3 className="text-3xl font-black text-white tracking-tight">
                My Legacy
              </h3>
              <p className="text-sm font-semibold text-zinc-400 mt-1">
                What kind of man do I want to become? Every completed day in ATLAS OS slowly fills your Legacy Progress Ring.
              </p>
            </div>

            {/* Character Trait Tags */}
            <div className="flex flex-wrap gap-2.5">
              {futureRoomData.config.legacyTraits?.map((trait, idx) => (
                <span
                  key={idx}
                  className="group px-4 py-2 rounded-2xl bg-zinc-900/90 border border-zinc-800 hover:border-purple-500/40 text-sm font-extrabold text-white flex items-center gap-2 transition"
                >
                  <span>{trait}</span>
                  <button
                    onClick={() => handleRemoveTrait(idx)}
                    className="opacity-0 group-hover:opacity-100 text-zinc-500 hover:text-red-400 transition"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </span>
              ))}

              {!isAddingTrait ? (
                <button
                  onClick={() => setIsAddingTrait(true)}
                  className="px-4 py-2 rounded-2xl bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-400 text-xs font-black transition flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Trait</span>
                </button>
              ) : (
                <form
                  onSubmit={handleAddTrait}
                  className="flex items-center gap-2"
                >
                  <input
                    type="text"
                    autoFocus
                    value={newTrait}
                    onChange={(e) => setNewTrait(e.target.value)}
                    placeholder="e.g. Fearless"
                    className="bg-zinc-800 border border-zinc-700 text-white rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-purple-500"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-xl bg-purple-500 text-black font-black text-xs"
                  >
                    Add
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddingTrait(false)}
                    className="text-zinc-500 hover:text-white px-2 text-xs"
                  >
                    Cancel
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Right: Legacy Progress Ring (4 cols) */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center bg-zinc-900/60 border border-white/5 rounded-3xl p-6 text-center shadow-xl">
            <div className="text-xs font-black uppercase tracking-widest text-zinc-400 mb-2">
              Legacy Progress Ring
            </div>

            <div className="relative w-40 h-40 flex items-center justify-center my-2">
              <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  className="stroke-zinc-800"
                  strokeWidth="8"
                  fill="transparent"
                />
                <motion.circle
                  cx="50"
                  cy="50"
                  r="38"
                  className="stroke-purple-500"
                  strokeWidth="8"
                  strokeDasharray={2 * Math.PI * 38}
                  strokeDashoffset={
                    2 * Math.PI * 38 * (1 - legacyProgress / 100)
                  }
                  strokeLinecap="round"
                  fill="transparent"
                  initial={{ strokeDashoffset: 2 * Math.PI * 38 }}
                  animate={{
                    strokeDashoffset:
                      2 * Math.PI * 38 * (1 - legacyProgress / 100),
                  }}
                  transition={{ duration: 1.5, ease: "easeInOut" }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="text-3xl font-black text-white">
                  {legacyProgress}%
                </div>
                <div className="text-[10px] font-extrabold text-purple-400 uppercase tracking-widest">
                  Identity
                </div>
              </div>
            </div>

            <div className="text-xs text-zinc-400 font-semibold mt-2">
              {meaningfulDaysCount} Meaningful Days logged in ATLAS OS
            </div>
          </div>
        </div>
      </motion.div>

      {/* 5. THE COST OF QUITTING & REWARD OF CONSISTENCY */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* The Cost of Quitting */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#121215]/90 border border-red-500/30 rounded-3xl p-8 shadow-2xl backdrop-blur-xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-6">
              <div>
                <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-red-400">
                  <Lock className="w-4 h-4" /> What is at stake
                </div>
                <h3 className="text-2xl font-black text-white tracking-tight">
                  If I quit today...
                </h3>
              </div>

              <button
                onClick={() => setIsAddingCost(!isAddingCost)}
                className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-zinc-700"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Reminder</span>
              </button>
            </div>

            <AnimatePresence>
              {isAddingCost && (
                <motion.form
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  onSubmit={handleAddCost}
                  className="bg-zinc-900 border border-red-500/30 rounded-xl p-3 mb-4 flex items-center gap-2"
                >
                  <input
                    type="text"
                    autoFocus
                    value={newCost}
                    onChange={(e) => setNewCost(e.target.value)}
                    placeholder="e.g. The dreams I'll abandon."
                    className="flex-1 bg-zinc-800 border border-zinc-700 text-white placeholder-zinc-500 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-red-500"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-lg bg-red-500 text-black font-black text-xs"
                  >
                    Add
                  </button>
                </motion.form>
              )}
            </AnimatePresence>

            <div className="space-y-3">
              {futureRoomData.config.costOfQuitting?.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800 text-sm font-bold text-zinc-200"
                >
                  <span>• {item}</span>
                  <button
                    onClick={async () => {
                      const updated = futureRoomData.config.costOfQuitting.filter(
                        (_, i) => i !== idx
                      );
                      await saveFutureRoomConfig({ costOfQuitting: updated });
                    }}
                    className="text-zinc-600 hover:text-red-400"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-zinc-800 text-xs text-zinc-500">
            This section should never feel negative. It simply reminds you what is at stake.
          </div>
        </motion.div>

        {/* The Reward of Consistency */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#121215]/90 border border-emerald-500/30 rounded-3xl p-8 shadow-2xl backdrop-blur-xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-6">
              <div>
                <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-400">
                  <Award className="w-4 h-4" /> Infinite Upside
                </div>
                <h3 className="text-2xl font-black text-white tracking-tight">
                  If I stay consistent...
                </h3>
              </div>

              <button
                onClick={() => setIsAddingReward(!isAddingReward)}
                className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-zinc-700"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Reward</span>
              </button>
            </div>

            <AnimatePresence>
              {isAddingReward && (
                <motion.form
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  onSubmit={handleAddReward}
                  className="bg-zinc-900 border border-emerald-500/30 rounded-xl p-3 mb-4 flex items-center gap-2"
                >
                  <input
                    type="text"
                    autoFocus
                    value={newReward}
                    onChange={(e) => setNewReward(e.target.value)}
                    placeholder="e.g. Financial freedom."
                    className="flex-1 bg-zinc-800 border border-zinc-700 text-white placeholder-zinc-500 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-lg bg-emerald-500 text-black font-black text-xs"
                  >
                    Add
                  </button>
                </motion.form>
              )}
            </AnimatePresence>

            <div className="space-y-3">
              {futureRoomData.config.rewardOfConsistency?.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800 text-sm font-bold text-zinc-200"
                >
                  <span>• {item}</span>
                  <button
                    onClick={async () => {
                      const updated = futureRoomData.config.rewardOfConsistency.filter(
                        (_, i) => i !== idx
                      );
                      await saveFutureRoomConfig({
                        rewardOfConsistency: updated,
                      });
                    }}
                    className="text-zinc-600 hover:text-emerald-400"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-zinc-800 text-xs text-zinc-500">
            Compound consistency turns your future vision into everyday reality.
          </div>
        </motion.div>
      </div>

      {/* 6. VISION BOARD INTERACTIVE EXHIBITION */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#121215]/90 border border-white/10 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-xl space-y-8"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-400">
              <ImageIcon className="w-4 h-4" /> Visual Manifestation
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Interactive Vision Board
            </h2>
            <p className="text-sm text-zinc-400 mt-1">
              Dream Workspace, Laptop, Camera, Office, House, Car, Lifestyle, Travel, Family, Health, Creative, Financial, Personal Growth.
            </p>
          </div>

          <button
            onClick={() => setIsVisionModalOpen(true)}
            className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-extrabold text-xs transition flex items-center gap-2 shadow-lg shadow-emerald-600/20"
          >
            <Plus className="w-4 h-4" />
            <span>Add Vision Card</span>
          </button>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
          {visionCategories.map((cat) => {
            const count =
              cat === "All"
                ? visionBoardItems.length
                : visionBoardItems.filter((item) => item.category === cat)
                    .length;
            const isSelected = visionCat === cat;

            return (
              <button
                key={cat}
                onClick={() => setVisionCat(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap border ${
                  isSelected
                    ? "bg-zinc-800 text-white border-emerald-500/50 shadow-sm"
                    : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white"
                }`}
              >
                <span>{cat}</span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                    isSelected
                      ? "bg-emerald-500/20 text-emerald-400"
                      : "bg-zinc-800 text-zinc-500"
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Vision Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVision.map((item) => (
            <motion.div
              key={item.id}
              whileHover={{ y: -6, scale: 1.01 }}
              className={`group bg-zinc-900/80 border rounded-3xl overflow-hidden shadow-xl transition flex flex-col justify-between ${
                item.achieved
                  ? "border-emerald-500/60 shadow-emerald-500/10"
                  : "border-zinc-800/80 hover:border-emerald-500/40"
              }`}
            >
              <div>
                {/* Thumbnail Image */}
                <div className="relative h-56 w-full overflow-hidden bg-zinc-950">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-bold text-white uppercase tracking-wider">
                    {item.category}
                  </div>

                  {item.achieved && (
                    <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-emerald-500 text-black text-xs font-black flex items-center gap-1 shadow-lg">
                      <CheckCircle2 className="w-3.5 h-3.5" /> ACHIEVED
                    </div>
                  )}
                </div>

                {/* Card Body */}
                <div className="p-6">
                  <h3 className="text-xl font-black text-white tracking-tight mb-2 group-hover:text-emerald-400 transition">
                    {item.title}
                  </h3>
                  <p className="text-xs text-zinc-400 line-clamp-3 mb-4 leading-relaxed">
                    {item.caption}
                  </p>

                  {/* Target Date & Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-mono font-bold">
                      <span className="text-zinc-500">Target: {item.targetDate}</span>
                      <span className="text-emerald-400">{item.progress}%</span>
                    </div>
                    <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-500 to-blue-500 rounded-full"
                        style={{ width: `${item.progress}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Footer */}
              <div className="p-4 px-6 border-t border-zinc-800/80 bg-zinc-950/40 flex items-center justify-between">
                <button
                  onClick={() =>
                    updateVisionBoardItem(item.id, {
                      ...item,
                      achieved: !item.achieved,
                    })
                  }
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    item.achieved
                      ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                      : "bg-zinc-800 text-zinc-300 hover:text-white"
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>
                    {item.achieved ? "Achieved ⭐" : "Mark Achieved"}
                  </span>
                </button>

                <button
                  onClick={() => deleteVisionBoardItem(item.id)}
                  className="p-1.5 text-zinc-600 hover:text-red-400 rounded-lg transition"
                  title="Remove card"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Add Vision Modal */}
        <AnimatePresence>
          {isVisionModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
              <motion.form
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onSubmit={handleAddVision}
                className="w-full max-w-md bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4"
              >
                <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                  <h3 className="text-xl font-black text-white">
                    Add Vision Board Card
                  </h3>
                  <button
                    type="button"
                    onClick={() => setIsVisionModalOpen(false)}
                    className="p-1 text-zinc-500 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Title
                  </label>
                  <input
                    type="text"
                    required
                    value={vTitle}
                    onChange={(e) => setVTitle(e.target.value)}
                    placeholder="e.g. Private Executive Creative Office"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                      Category
                    </label>
                    <select
                      value={vCategory}
                      onChange={(e) => setVCategory(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                    >
                      {visionCategories.slice(1).map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                      Target Date
                    </label>
                    <input
                      type="date"
                      value={vDate}
                      onChange={(e) => setVDate(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Image URL
                  </label>
                  <input
                    type="url"
                    value={vImageUrl}
                    onChange={(e) => setVImageUrl(e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Description
                  </label>
                  <textarea
                    rows={3}
                    value={vCaption}
                    onChange={(e) => setVCaption(e.target.value)}
                    placeholder="Why is this vision important for your future?"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Current Progress (%)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={vProgress}
                    onChange={(e) => setVProgress(Number(e.target.value))}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                  <button
                    type="button"
                    onClick={() => setIsVisionModalOpen(false)}
                    className="px-5 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs"
                  >
                    Save Vision Card
                  </button>
                </div>
              </motion.form>
            </div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* 7. THE FUTURE STUDIO ROOM VISUALIZATION */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-10 shadow-2xl backdrop-blur-xl relative overflow-hidden"
      >
        {/* Luminous Ambient Room Light Ramping Up As Items Are Achieved */}
        <div
          className="absolute -top-32 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full blur-[140px] pointer-events-none transition-all duration-1000"
          style={{
            background: `rgba(16, 185, 129, ${
              0.08 + (studioLifePercent / 100) * 0.22
            })`,
          }}
        />

        <div className="relative z-10 space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-800">
            <div>
              <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-400">
                <Monitor className="w-4 h-4" /> Living Workspace Sanctuary
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                The Future Studio
              </h2>
              <p className="text-sm text-zinc-400 mt-1">
                Desk, Monitor, Laptop, Chair, Lighting, Camera, Studio Inspiration. As items are achieved, the room animates and glows with life.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="px-4 py-2 rounded-2xl bg-zinc-900 border border-zinc-800 text-xs font-mono font-bold text-emerald-400">
                {achievedStudioCount} / {studioTotal} ACHIEVED ({studioLifePercent}%)
              </div>
            </div>
          </div>

          {/* Interactive Mock Studio Room Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {futureRoomData.config.studioItems?.map((item, idx) => {
              const icons: Record<string, any> = {
                Desk: Layout,
                Monitor: Monitor,
                Laptop: Laptop,
                Chair: Layers,
                Lighting: Sun,
                Camera: Camera,
                "Studio Inspiration": Sparkles,
              };
              const Icon = icons[item.category] || Sparkles;

              return (
                <div
                  key={idx}
                  onClick={() => handleToggleStudioItem(idx)}
                  className={`group relative rounded-3xl p-5 border transition cursor-pointer select-none overflow-hidden ${
                    item.achieved
                      ? "bg-zinc-900/90 border-emerald-500/50 shadow-lg shadow-emerald-500/10"
                      : "bg-zinc-900/40 border-zinc-800/80 hover:border-zinc-700 opacity-70 hover:opacity-100"
                  }`}
                >
                  <div className="relative h-36 w-full rounded-2xl overflow-hidden mb-4 bg-zinc-950">
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                    />
                    <div className="absolute top-2 left-2 px-2.5 py-1 rounded-full bg-black/80 text-[10px] font-bold text-white uppercase">
                      {item.category}
                    </div>

                    {item.achieved && (
                      <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-emerald-500 text-black text-[10px] font-black flex items-center gap-1 shadow-md">
                        <CheckCircle2 className="w-3 h-3" /> ACTIVE
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-extrabold text-white text-sm">
                        {item.name}
                      </div>
                      <div className="text-xs text-zinc-500 mt-0.5">
                        {item.achieved ? "Studio Equipment Ready" : "Target Gear Milestone"}
                      </div>
                    </div>

                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center border transition ${
                        item.achieved
                          ? "bg-emerald-500 text-black border-emerald-400 shadow-md shadow-emerald-500/20"
                          : "bg-zinc-800 text-zinc-500 border-zinc-700"
                      }`}
                    >
                      <Check className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </motion.div>

      {/* 8. DREAM LIFE TIMELINE */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-10 shadow-2xl backdrop-blur-xl"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-800 mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-blue-400">
              <Calendar className="w-4 h-4" /> Multi-Year Strategy
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Dream Life Timeline
            </h2>
            <p className="text-sm text-zinc-400 mt-1">
              "We overestimate what we can do in one year and underestimate what we can do in three years."
            </p>
          </div>

          <button
            onClick={() => setIsTimelineModalOpen(true)}
            className="px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-black font-extrabold text-xs transition flex items-center gap-2 shadow-lg shadow-blue-600/20"
          >
            <Plus className="w-4 h-4" />
            <span>Add Target Year</span>
          </button>
        </div>

        {/* Timeline Horizontal / Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
          {futureRoomData.dreamTimeline.map((item, idx) => (
            <div
              key={item.id}
              className="bg-zinc-900/80 border border-zinc-800 hover:border-blue-500/40 rounded-3xl p-6 shadow-xl flex flex-col justify-between transition group relative"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-3xl font-black text-blue-400 font-mono">
                    {item.year}
                  </span>
                  <button
                    onClick={() => deleteTimelineItem(item.id)}
                    className="opacity-0 group-hover:opacity-100 p-1 text-zinc-500 hover:text-red-400 transition"
                    title="Delete milestone year"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <h3 className="text-xl font-black text-white tracking-tight mb-4">
                  {item.title}
                </h3>

                <ul className="space-y-2.5">
                  {item.milestones?.map((m, i) => (
                    <li
                      key={i}
                      className="flex items-center gap-2.5 text-sm font-semibold text-zinc-300"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{m}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-6 pt-3 border-t border-zinc-800/80 text-xs text-zinc-500 font-semibold">
                Milestone Phase {idx + 1}
              </div>
            </div>
          ))}
        </div>

        {/* Add Timeline Modal */}
        <AnimatePresence>
          {isTimelineModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
              <motion.form
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onSubmit={handleAddTimeline}
                className="w-full max-w-md bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4"
              >
                <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                  <h3 className="text-xl font-black text-white">
                    Add Timeline Milestone Year
                  </h3>
                  <button
                    type="button"
                    onClick={() => setIsTimelineModalOpen(false)}
                    className="p-1 text-zinc-500 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Year
                  </label>
                  <input
                    type="number"
                    required
                    value={tYear}
                    onChange={(e) => setTYear(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Phase Title
                  </label>
                  <input
                    type="text"
                    required
                    value={tTitle}
                    onChange={(e) => setTTitle(e.target.value)}
                    placeholder="e.g. Agency Scale & Independence"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Milestones (comma separated)
                  </label>
                  <textarea
                    rows={3}
                    value={tMilestoneStr}
                    onChange={(e) => setTMilestoneStr(e.target.value)}
                    placeholder="Open studio, Hire first employee, Reach international clients"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-3 text-sm focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                  <button
                    type="button"
                    onClick={() => setIsTimelineModalOpen(false)}
                    className="px-5 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-black font-bold text-xs"
                  >
                    Save Timeline Phase
                  </button>
                </div>
              </motion.form>
            </div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* 9. FUTURE METRICS (LONG-TERM STRATEGIC TELEMETRY) */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-10 shadow-2xl backdrop-blur-xl"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-800 mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-400">
              <Target className="w-4 h-4" /> Quantitative Mastery
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Future Metrics
            </h2>
            <p className="text-sm text-zinc-400 mt-1">
              Progress toward long-term identity and financial independence milestones.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Portfolio Metric */}
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-black text-white uppercase tracking-wider">
                Portfolio
              </span>
              <span className="text-sm font-mono font-black text-emerald-400">
                82%
              </span>
            </div>
            <div className="text-xs font-mono text-zinc-400 tracking-wider">
              ████████░░ 82%
            </div>
            <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 rounded-full" style={{ width: "82%" }} />
            </div>
            <div className="text-xs text-zinc-500">
              {portfolioProjects.length} case studies published in gallery
            </div>
          </div>

          {/* Clients Metric */}
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-black text-white uppercase tracking-wider">
                Clients
              </span>
              <span className="text-sm font-mono font-black text-blue-400">
                51%
              </span>
            </div>
            <div className="text-xs font-mono text-zinc-400 tracking-wider">
              █████░░░░░ 51%
            </div>
            <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-blue-500 rounded-full" style={{ width: "51%" }} />
            </div>
            <div className="text-xs text-zinc-500">
              {clients.length} deals actively tracked in CRM
            </div>
          </div>

          {/* Income Goal Metric */}
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-black text-white uppercase tracking-wider">
                Income Goal
              </span>
              <span className="text-sm font-mono font-black text-emerald-300">
                40%
              </span>
            </div>
            <div className="text-xs font-mono text-zinc-400 tracking-wider">
              ████░░░░░░ 40%
            </div>
            <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400 rounded-full" style={{ width: "40%" }} />
            </div>
            <div className="text-xs text-zinc-500">
              ${incomeStats.yearlyIncome.toLocaleString()} / $100,000 yearly target
            </div>
          </div>

          {/* After Effects Metric */}
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-black text-white uppercase tracking-wider">
                After Effects
              </span>
              <span className="text-sm font-mono font-black text-purple-400">
                71%
              </span>
            </div>
            <div className="text-xs font-mono text-zinc-400 tracking-wider">
              ███████░░░ 71%
            </div>
            <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-purple-500 rounded-full" style={{ width: "71%" }} />
            </div>
            <div className="text-xs text-zinc-500">
              Motion graphics kinetic reels & 3D title mastery
            </div>
          </div>

          {/* Web Development Metric */}
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-black text-white uppercase tracking-wider">
                Web Development
              </span>
              <span className="text-sm font-mono font-black text-emerald-400">
                90%
              </span>
            </div>
            <div className="text-xs font-mono text-zinc-400 tracking-wider">
              ████████░░ 90%
            </div>
            <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 rounded-full" style={{ width: "90%" }} />
            </div>
            <div className="text-xs text-zinc-500">
              Next.js, React, Tailwind & TypeScript full-stack mastery
            </div>
          </div>
        </div>
      </motion.div>

      {/* 10. QUOTE OF THE FUTURE & ENDING MESSAGE */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-900/60 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl text-center space-y-8 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-3 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-black uppercase tracking-widest">
            <Quote className="w-3.5 h-3.5" /> Quote of the Future
          </div>

          <motion.blockquote
            key={quoteIdx}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-snug"
          >
            "{futureQuotes[quoteIdx]}"
          </motion.blockquote>
        </div>

        <div className="w-24 h-px bg-zinc-800 mx-auto" />

        {/* Ending Message */}
        <div className="space-y-2 max-w-2xl mx-auto">
          <div className="text-base sm:text-lg font-extrabold text-emerald-400 tracking-wide">
            "The future isn't waiting for you."
          </div>
          <div className="text-base sm:text-lg font-bold text-zinc-300">
            "It is being created by what you choose to do today."
          </div>
        </div>
      </motion.div>
    </div>
  );
}
