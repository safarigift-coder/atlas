"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Image as ImageIcon,
  Plus,
  Trash2,
  CheckCircle2,
  Calendar,
  Sparkles,
  ExternalLink,
  X,
  Compass,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";

export function VisionBoardView() {
  const {
    visionBoardItems,
    addVisionBoardItem,
    updateVisionBoardItem,
    deleteVisionBoardItem,
  } = useAtlasStore();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Setup");
  const [imageUrl, setImageUrl] = useState("");
  const [caption, setCaption] = useState("");
  const [targetDate, setTargetDate] = useState("2026-12-31");

  const categories = ["All", "Setup", "Gear", "Finance", "Career", "Education"];
  const [activeCat, setActiveCat] = useState("All");

  const filtered =
    activeCat === "All"
      ? visionBoardItems
      : visionBoardItems.filter((i) => i.category === activeCat);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await addVisionBoardItem({
      title: title || "Dream Studio Setup",
      category: category || "Setup",
      imageUrl:
        imageUrl ||
        "https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=800&q=80",
      caption: caption || "My long-term creative vision milestone.",
      targetDate: targetDate || "2026-12-31",
      achieved: false,
    });
    setIsModalOpen(false);
    setTitle("");
    setCaption("");
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
            <Compass className="w-4 h-4" /> Personal Blueprint
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            ATLAS OS Vision Board
          </h1>
          <p className="text-sm text-zinc-400 mt-1">
            Dream Studio, MacBook, Professional Camera, Office Setup, Financial Goals, Career Goals.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition flex items-center gap-2 shadow-lg shadow-emerald-600/20"
        >
          <Plus className="w-4 h-4" /> Add Vision Item
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        {categories.map((cat) => {
          const count =
            cat === "All"
              ? visionBoardItems.length
              : visionBoardItems.filter((i) => i.category === cat).length;
          const isSelected = activeCat === cat;

          return (
            <button
              key={cat}
              onClick={() => setActiveCat(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap border ${
                isSelected
                  ? "bg-zinc-800 text-white border-emerald-500/50 shadow-sm"
                  : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white"
              }`}
            >
              <span>{cat}</span>
              <span
                className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                  isSelected
                    ? "bg-emerald-500/20 text-emerald-400"
                    : "bg-zinc-800 text-zinc-500"
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Vision Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`group bg-[#121215] border rounded-3xl overflow-hidden shadow-xl transition flex flex-col justify-between ${
              item.achieved
                ? "border-emerald-500/50"
                : "border-zinc-800 hover:border-zinc-700"
            }`}
          >
            <div>
              {/* Image */}
              <div className="relative h-60 w-full overflow-hidden bg-zinc-900">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                />
                <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-bold text-white uppercase tracking-wider">
                  {item.category}
                </div>

                {item.achieved && (
                  <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-emerald-500 text-black text-xs font-black flex items-center gap-1 shadow-lg">
                    <CheckCircle2 className="w-3.5 h-3.5" /> ACHIEVED
                  </div>
                )}
              </div>

              {/* Body */}
              <div className="p-6">
                <h3 className="text-xl font-extrabold text-white tracking-tight mb-2">
                  {item.title}
                </h3>
                <p className="text-xs text-zinc-400 line-clamp-3 mb-4 leading-relaxed">
                  {item.caption}
                </p>

                <div className="text-xs font-mono text-zinc-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Target Date: {item.targetDate}</span>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 px-6 border-t border-zinc-800/80 bg-zinc-900/30 flex items-center justify-between">
              <button
                onClick={() =>
                  updateVisionBoardItem(item.id, {
                    ...item,
                    achieved: !item.achieved,
                  })
                }
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  item.achieved
                    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                    : "bg-zinc-800 text-zinc-300 hover:text-white"
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>
                  {item.achieved ? "Marked Achieved" : "Mark Achieved"}
                </span>
              </button>

              <button
                onClick={() => deleteVisionBoardItem(item.id)}
                className="p-1.5 text-zinc-500 hover:text-red-400 rounded-lg transition"
                title="Delete item"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Add Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.form
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleSubmit}
              className="w-full max-w-md bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <h3 className="text-xl font-extrabold text-white">
                  Add Vision Board Milestone
                </h3>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-zinc-500 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Sony FX3 Cinema Camera"
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Setup">Setup</option>
                    <option value="Gear">Gear</option>
                    <option value="Finance">Finance</option>
                    <option value="Career">Career</option>
                    <option value="Education">Education</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Target Date
                  </label>
                  <input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Image URL
                </label>
                <input
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Caption / Vision Meaning
                </label>
                <textarea
                  rows={3}
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  placeholder="Why is this milestone important for your creative journey?"
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs"
                >
                  Save Vision Item
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
