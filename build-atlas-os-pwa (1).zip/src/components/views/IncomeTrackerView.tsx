"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DollarSign,
  TrendingUp,
  Award,
  Plus,
  Trash2,
  Calendar,
  CheckCircle2,
  Clock,
  X,
} from "lucide-react";
import { EmptyState } from "@/components/brand/EmptyState";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useAtlasStore } from "@/store/atlas-store";

export function IncomeTrackerView() {
  const {
    incomeTransactions,
    incomeStats,
    addIncome,
    deleteIncome,
    clients,
  } = useAtlasStore();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [clientName, setClientName] = useState("");
  const [amount, setAmount] = useState("2500");
  const [service, setService] = useState("Brand & UI Design");
  const [status, setStatus] = useState<"Paid" | "Pending">("Paid");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);

  // Aggregate monthly earnings for the Recharts graph
  const monthlyDataMap: Record<string, number> = {
    Jan: 2400,
    Feb: 3800,
    Mar: 4200,
    Apr: 5100,
    May: 6800,
    Jun: 4900,
    Jul: 7200,
  };

  const graphData = Object.entries(monthlyDataMap).map(([month, val]) => ({
    month,
    earnings: val,
  }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await addIncome({
      date,
      clientName: clientName || "Creative Retainer",
      amount: Number(amount) || 1000,
      service: service || "Design & Motion",
      status,
    });
    setIsModalOpen(false);
    setClientName("");
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-7xl mx-auto">
      {/* 4 Key Income Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Monthly Earnings
          </div>
          <div className="text-3xl font-black text-emerald-400">
            ${incomeStats.monthlyIncome.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            +18% from last month
          </div>
        </div>

        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Yearly Earnings
          </div>
          <div className="text-3xl font-black text-white">
            ${incomeStats.yearlyIncome.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            Target: $100,000 / yr
          </div>
        </div>

        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Avg Project Value
          </div>
          <div className="text-3xl font-black text-blue-400">
            ${incomeStats.avgProjectValue.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            Based on completed invoices
          </div>
        </div>

        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Highest Paying Client
          </div>
          <div className="text-xl font-extrabold text-purple-400 truncate">
            {incomeStats.highestPayingClient.name}
          </div>
          <div className="mt-1 text-xs text-zinc-400 font-semibold">
            ${incomeStats.highestPayingClient.amount.toLocaleString()} earned
          </div>
        </div>
      </div>

      {/* Income Graph */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-emerald-400">
              Income Graph
            </div>
            <h3 className="text-xl font-extrabold text-white tracking-tight">
              Monthly Creative Revenue Over Time
            </h3>
          </div>
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition flex items-center gap-1.5 shadow-lg shadow-emerald-600/20"
          >
            <Plus className="w-4 h-4" /> Record Income
          </button>
        </div>

        <div className="w-full h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={graphData}
              margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
            >
              <XAxis
                dataKey="month"
                stroke="#52525B"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="#52525B"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => `$${val}`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#18181B",
                  border: "1px solid #27272A",
                  borderRadius: "12px",
                  color: "#fff",
                }}
                formatter={(val: any) => [
                  `$${Number(val).toLocaleString()}`,
                  "Earnings",
                ]}
              />
              <Bar
                dataKey="earnings"
                fill="#10B981"
                radius={[8, 8, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-zinc-800">
          <h3 className="text-lg font-extrabold text-white">
            Invoice & Transaction History
          </h3>
          <span className="text-xs text-zinc-500">
            {incomeTransactions.length} transactions
          </span>
        </div>

        {incomeTransactions.length === 0 ? (
          <EmptyState
            title="No Income Tracked Yet"
            subtitle="Your value compounds with every rep."
            actionLabel="Record First Income"
            onAction={() => setIsModalOpen(true)}
            streak={14}
          />
        ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-zinc-800 text-xs font-bold uppercase text-zinc-500">
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Client</th>
                <th className="py-3 px-4">Service</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 text-sm">
              {incomeTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-zinc-900/50 transition">
                  <td className="py-3.5 px-4 text-zinc-400 font-mono text-xs">
                    {tx.date}
                  </td>
                  <td className="py-3.5 px-4 font-bold text-white">
                    {tx.clientName}
                  </td>
                  <td className="py-3.5 px-4 text-zinc-400">{tx.service}</td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border ${
                        tx.status === "Paid"
                          ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                          : "bg-amber-500/10 text-amber-400 border-amber-500/30"
                      }`}
                    >
                      {tx.status === "Paid" ? (
                        <CheckCircle2 className="w-3 h-3" />
                      ) : (
                        <Clock className="w-3 h-3" />
                      )}
                      {tx.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right font-black text-white">
                    ${tx.amount.toLocaleString()}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => deleteIncome(tx.id)}
                      className="p-1.5 text-zinc-500 hover:text-red-400 rounded-lg transition"
                      title="Delete transaction"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        )}
      </div>

      {/* Record Income Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.form
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleSubmit}
              className="w-full max-w-md bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <h3 className="text-xl font-extrabold text-white">
                  Record Income Transaction
                </h3>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-zinc-500 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Client / Source Name
                </label>
                <input
                  type="text"
                  required
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Veloce Robotics"
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Amount ($ USD)
                  </label>
                  <input
                    type="number"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e: any) => setStatus(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Paid">Paid</option>
                    <option value="Pending">Pending</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Service Provided
                </label>
                <input
                  type="text"
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  placeholder="UI/UX Design & Next.js Website"
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs"
                >
                  Save Transaction
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
