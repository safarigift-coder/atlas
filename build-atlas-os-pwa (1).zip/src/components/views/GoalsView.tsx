"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Target,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  TrendingUp,
  MinusCircle,
  PlusCircle,
  X,
} from "lucide-react";
import { soundManager } from "@/lib/sound";
import { useAtlasStore } from "@/store/atlas-store";

export function GoalsView() {
  const { goals, addGoal, updateGoal, deleteGoal, profile } = useAtlasStore();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<any | null>(null);

  // Form State
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Career");
  const [targetValue, setTargetValue] = useState("100");
  const [currentValue, setCurrentValue] = useState("0");
  const [unit, setUnit] = useState("%");

  const openAddModal = () => {
    setEditingGoal(null);
    setTitle("");
    setCategory("Career");
    setTargetValue("100");
    setCurrentValue("0");
    setUnit("%");
    setIsModalOpen(true);
  };

  const openEditModal = (g: any) => {
    setEditingGoal(g);
    setTitle(g.title);
    setCategory(g.category);
    setTargetValue(String(g.targetValue));
    setCurrentValue(String(g.currentValue));
    setUnit(g.unit);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      title: title || "New Goal",
      category: category || "Career",
      targetValue: Number(targetValue) || 100,
      currentValue: Number(currentValue) || 0,
      unit: unit || "%",
      completed: Number(currentValue) >= Number(targetValue),
    };

    if (editingGoal) {
      await updateGoal(editingGoal.id, data);
    } else {
      await addGoal(data);
    }
    setIsModalOpen(false);
  };

  const handleAdjustProgress = async (g: any, delta: number) => {
    soundManager.playCheck(profile.soundEnabled);
    const newVal = Math.max(0, g.currentValue + delta);
    await updateGoal(g.id, {
      ...g,
      currentValue: newVal,
      completed: newVal >= g.targetValue,
    });
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-6xl mx-auto">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
            <Target className="w-4 h-4" /> Long-Term Vision
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Editable Creative Goals
          </h1>
          <p className="text-sm text-zinc-400 mt-1">
            "Nobody owes you success." Define clear targets and execute with daily consistency.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition flex items-center gap-2 shadow-lg shadow-emerald-600/20"
        >
          <Plus className="w-4 h-4" /> Add New Goal
        </button>
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {goals.map((goal) => {
          const progressPercent = Math.min(
            100,
            Math.round((goal.currentValue / goal.targetValue) * 100)
          );

          return (
            <motion.div
              key={goal.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#121215] border border-zinc-800 hover:border-zinc-700 rounded-3xl p-6 shadow-xl flex flex-col justify-between transition group"
            >
              <div>
                {/* Category & Status Badge */}
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-xs font-bold text-zinc-400">
                    {goal.category}
                  </span>

                  {progressPercent >= 100 ? (
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-extrabold">
                      <CheckCircle2 className="w-3.5 h-3.5" /> ACHIEVED
                    </span>
                  ) : (
                    <span className="text-xs font-mono font-bold text-zinc-400">
                      {progressPercent}% Complete
                    </span>
                  )}
                </div>

                {/* Goal Title */}
                <h3 className="text-xl font-extrabold text-white tracking-tight mb-4 group-hover:text-emerald-400 transition">
                  {goal.title}
                </h3>

                {/* Progress Bar & Values */}
                <div className="space-y-2 mb-6">
                  <div className="flex items-center justify-between text-sm font-bold">
                    <span className="text-zinc-400">Current Progress:</span>
                    <span className="text-white">
                      {goal.currentValue.toLocaleString()} /{" "}
                      {goal.targetValue.toLocaleString()} {goal.unit}
                    </span>
                  </div>

                  <div className="w-full h-3 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${progressPercent}%` }}
                      transition={{ duration: 0.8 }}
                      className="h-full bg-gradient-to-r from-emerald-500 via-emerald-400 to-blue-500 rounded-full"
                    />
                  </div>
                </div>
              </div>

              {/* Adjust Progress Controls */}
              <div className="flex items-center justify-between pt-4 border-t border-zinc-800/80">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleAdjustProgress(goal, -1)}
                    title="Decrease progress"
                    className="p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 transition"
                  >
                    <MinusCircle className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleAdjustProgress(goal, 1)}
                    title="Increase progress (+1)"
                    className="p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-emerald-400 hover:text-emerald-300 border border-zinc-800 transition"
                  >
                    <PlusCircle className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleAdjustProgress(goal, 10)}
                    title="Increase progress (+10)"
                    className="px-2.5 py-1 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold transition"
                  >
                    +10
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEditModal(goal)}
                    className="p-1.5 text-zinc-500 hover:text-white rounded-lg transition"
                    title="Edit goal"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteGoal(goal.id)}
                    className="p-1.5 text-zinc-500 hover:text-red-400 rounded-lg transition"
                    title="Delete goal"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Add / Edit Goal Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.form
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleSubmit}
              className="w-full max-w-md bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <h3 className="text-xl font-extrabold text-white">
                  {editingGoal ? "Edit Goal" : "Add Creative Goal"}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-zinc-500 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Goal Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Become financially independent"
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Finance">Finance</option>
                    <option value="Skill">Skill</option>
                    <option value="Portfolio">Portfolio</option>
                    <option value="Career">Career</option>
                    <option value="Education">Education</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Unit
                  </label>
                  <input
                    type="text"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    placeholder="%, projects, $/yr"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Current Value
                  </label>
                  <input
                    type="number"
                    required
                    value={currentValue}
                    onChange={(e) => setCurrentValue(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Target Value
                  </label>
                  <input
                    type="number"
                    required
                    value={targetValue}
                    onChange={(e) => setTargetValue(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs"
                >
                  Save Goal
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
