"use client";

import React, { useState } from "react";
import {
  Settings as SettingsIcon,
  Volume2,
  VolumeX,
  Download,
  Upload,
  RefreshCw,
  Moon,
  Smartphone,
  CheckCircle2,
  Shield,
  Database,
  Bell,
  Clock,
  User,
  Edit3,
  Save,
  Compass,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";
import {
  saveLocalOnboardingData,
  getLocalOnboardingData,
} from "@/lib/onboarding-storage";

export function SettingsView() {
  const {
    profile,
    updateProfile,
    resetDemoData,
    offlineMode,
    setOfflineMode,
    setInstallModalOpen,
    futureRoomData,
    promiseState,
    portfolioProjects,
    clients,
    journalEntries,
    legacyEntries,
    goals,
    skills,
    achievements,
  } = useAtlasStore();

  const [reminderTime, setReminderTime] = useState(
    profile.dailyReminderTime || "08:00"
  );
  const [restoreMessage, setRestoreMessage] = useState("");
  const [isResetting, setIsResetting] = useState(false);

  // Profile Edit State
  const [preferredName, setPreferredName] = useState(
    profile.preferredName || profile.name || "Creator"
  );
  const [firstName, setFirstName] = useState(
    profile.firstName || profile.name || "Creator"
  );
  const [lastName, setLastName] = useState(profile.lastName || "");
  const [occupation, setOccupation] = useState(
    profile.occupation || profile.title || "Creative Entrepreneur"
  );
  const [country, setCountry] = useState(profile.country || "United States");
  const [city, setCity] = useState(profile.city || "");
  const [photoUrl, setPhotoUrl] = useState(
    profile.profilePhotoUrl ||
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80"
  );
  const [profileSaved, setProfileSaved] = useState(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const displayName =
      preferredName.trim() || firstName.trim() || "Creator";
    await updateProfile({
      name: displayName,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      preferredName: displayName,
      title: occupation.trim(),
      occupation: occupation.trim(),
      country: country.trim(),
      city: city.trim(),
      profilePhotoUrl: photoUrl.trim(),
    });

    const localData = getLocalOnboardingData();
    if (localData) {
      saveLocalOnboardingData({
        ...localData,
        preferredName: displayName,
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        occupation: occupation.trim(),
        country: country.trim(),
        profilePhotoUrl: photoUrl.trim(),
      });
    }

    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 3000);
  };

  const handleBackup = () => {
    const fullProfileExport = {
      version: "ATLAS_OS_3.0_MULTI_USER",
      exportedAt: new Date().toISOString(),
      profile,
      goals,
      futureRoom: futureRoomData,
      promiseState,
      projects: portfolioProjects,
      clients,
      journal: journalEntries,
      legacy: legacyEntries,
      achievements,
      skills,
    };
    const blob = new Blob(
      [JSON.stringify(fullProfileExport, null, 2)],
      { type: "application/json" }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ATLAS_OS_PROFILE_${
      profile.preferredName || "USER"
    }_${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const json = JSON.parse(text);

      const res = await fetch("/api/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(json),
      });

      if (res.ok) {
        setRestoreMessage("ATLAS OS database restored successfully!");
        setTimeout(() => setRestoreMessage(""), 5000);
      } else {
        setRestoreMessage("Restore failed. Check JSON format.");
      }
    } catch (err: any) {
      setRestoreMessage("Error reading file: " + err.message);
    }
  };

  const handleReset = async () => {
    if (
      !confirm(
        "Are you sure you want to reset all data back to the default rich seed?"
      )
    )
      return;
    setIsResetting(true);
    await resetDemoData();
    setIsResetting(false);
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
          <SettingsIcon className="w-4 h-4" /> System Configuration
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          ATLAS OS Settings
        </h1>
        <p className="text-sm text-zinc-400 mt-1">
          Manage system sound effects, reminder schedules, database backups, and PWA offline mode.
        </p>
      </div>

      <div className="space-y-6">
        {/* 0. PROFILE & IDENTITY PREFERENCES */}
        <form
          onSubmit={handleSaveProfile}
          className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6"
        >
          <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
            <div>
              <div className="text-xs font-black uppercase tracking-widest text-emerald-400 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" /> Multi-User Identity
              </div>
              <h3 className="text-xl font-black text-white">
                Personal Profile & Preferences
              </h3>
              <p className="text-xs text-zinc-400">
                Edit your name, occupation, profile picture, and location. Everything updates instantly across your OS.
              </p>
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs transition flex items-center gap-1.5 shadow-lg shadow-emerald-500/20"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{profileSaved ? "Saved!" : "Save Profile"}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-zinc-400 mb-1">
                Preferred Name *
              </label>
              <input
                type="text"
                required
                value={preferredName}
                onChange={(e) => setPreferredName(e.target.value)}
                placeholder="Gift"
                className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2.5 text-xs font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-zinc-400 mb-1">
                First Name
              </label>
              <input
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="Gift"
                className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-zinc-400 mb-1">
                Last Name
              </label>
              <input
                type="text"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="Safari"
                className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-zinc-400 mb-1">
                Occupation
              </label>
              <input
                type="text"
                value={occupation}
                onChange={(e) => setOccupation(e.target.value)}
                placeholder="Creative Entrepreneur"
                className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-zinc-400 mb-1">
                Country
              </label>
              <input
                type="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                placeholder="United States"
                className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-zinc-400 mb-1">
                City (optional)
              </label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="San Francisco"
                className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-zinc-400 mb-1">
              Profile Picture URL
            </label>
            <input
              type="url"
              value={photoUrl}
              onChange={(e) => setPhotoUrl(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>
        </form>

        {/* 1. SOUND & NOTIFICATIONS */}
        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl space-y-4">
          <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
            <Bell className="w-4 h-4 text-emerald-400" />
            <span>Sound & Notifications</span>
          </h3>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
            <div>
              <div className="font-bold text-white text-sm">
                System Acoustic Feedback
              </div>
              <div className="text-xs text-zinc-400">
                Crisp checkmark pops, victory fanfares, and pomodoro timer bells
              </div>
            </div>

            <button
              onClick={() =>
                updateProfile({ soundEnabled: !profile.soundEnabled })
              }
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                profile.soundEnabled
                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                  : "bg-zinc-800 text-zinc-400 border border-zinc-700"
              }`}
            >
              {profile.soundEnabled ? (
                <>
                  <Volume2 className="w-4 h-4" /> Sound Enabled
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4" /> Sound Muted
                </>
              )}
            </button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
            <div>
              <div className="font-bold text-white text-sm">
                Daily Reminder Time
              </div>
              <div className="text-xs text-zinc-400">
                Morning briefing reminder for your daily mission
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-zinc-500" />
              <input
                type="time"
                value={reminderTime}
                onChange={(e) => {
                  setReminderTime(e.target.value);
                  updateProfile({ dailyReminderTime: e.target.value });
                }}
                className="bg-zinc-800 border border-zinc-700 text-white rounded-xl px-3 py-1.5 text-xs font-mono focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* 2. PWA & OFFLINE MODE */}
        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl space-y-4">
          <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-blue-400" />
            <span>Progressive Web App & Offline Mode</span>
          </h3>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30">
            <div>
              <div className="font-extrabold text-white text-sm flex items-center gap-1.5">
                <span>Install ATLAS OS Native PWA</span>
              </div>
              <div className="text-xs text-emerald-300/90">
                Install as a standalone app on your iOS, Android, macOS, or Windows Dock
              </div>
            </div>

            <button
              onClick={() => setInstallModalOpen(true)}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs transition flex items-center gap-1.5 shadow-md shadow-emerald-500/20"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install App</span>
            </button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
            <div>
              <div className="font-bold text-white text-sm">
                Offline Mode Caching
              </div>
              <div className="text-xs text-zinc-400">
                Service worker cache enabled for fast loading anywhere
              </div>
            </div>

            <button
              onClick={() => setOfflineMode(!offlineMode)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition border ${
                offlineMode
                  ? "bg-blue-500/20 text-blue-400 border-blue-500/30"
                  : "bg-zinc-800 text-zinc-400 border-zinc-700"
              }`}
            >
              {offlineMode ? "Offline Mode Active" : "Online Sync"}
            </button>
          </div>

          <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800 text-xs text-zinc-400 space-y-1">
            <div className="font-bold text-white">
              Install ATLAS OS on iOS / Android:
            </div>
            <div>
              1. Tap the Share button in Safari / Chrome
            </div>
            <div>
              2. Select "Add to Home Screen" to install as a standalone PWA
            </div>
          </div>
        </div>

        {/* 3. DATABASE BACKUP, RESTORE & RESET */}
        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl space-y-4">
          <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
            <Database className="w-4 h-4 text-purple-400" />
            <span>Database Backup, Restore & Reset</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button
              onClick={handleBackup}
              className="p-5 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 flex items-center justify-between text-left transition group"
            >
              <div>
                <div className="font-bold text-white text-sm group-hover:text-emerald-400 transition">
                  Export JSON Backup
                </div>
                <div className="text-xs text-zinc-500 mt-0.5">
                  Download full database state
                </div>
              </div>
              <Download className="w-5 h-5 text-zinc-500 group-hover:text-emerald-400" />
            </button>

            <label className="p-5 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 flex items-center justify-between text-left transition group cursor-pointer">
              <div>
                <div className="font-bold text-white text-sm group-hover:text-blue-400 transition">
                  Restore from JSON
                </div>
                <div className="text-xs text-zinc-500 mt-0.5">
                  Upload backup file to restore
                </div>
              </div>
              <Upload className="w-5 h-5 text-zinc-500 group-hover:text-blue-400" />
              <input
                type="file"
                accept=".json"
                onChange={handleRestoreFile}
                className="hidden"
              />
            </label>
          </div>

          {restoreMessage && (
            <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs">
              {restoreMessage}
            </div>
          )}

          <div className="pt-4 border-t border-zinc-800 flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-white">
                Reset Demo Database
              </div>
              <div className="text-xs text-zinc-500">
                Restore default seed records for Gift Safari
              </div>
            </div>

            <button
              onClick={handleReset}
              disabled={isResetting}
              className="px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-red-500/20 hover:text-red-400 text-zinc-300 border border-zinc-700 text-xs font-bold transition flex items-center gap-2"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{isResetting ? "Resetting..." : "Reset to Seed"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
