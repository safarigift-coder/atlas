"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Compass,
  Shield,
  Sparkles,
  Award,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Plus,
  Trash2,
  Edit3,
  Save,
  Quote,
  Flame,
  ArrowRight,
  UserCheck,
  RotateCcw,
  Check,
  X,
  History,
  Lock,
  Heart,
  FileText,
  Clock,
  Volume2,
  VolumeX,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";
import { soundManager } from "@/lib/sound";
import { ambientAudioPlayer, AmbientTrack } from "@/lib/ambient-audio";

export function PromiseView() {
  const {
    profile,
    promiseState,
    promiseWallMilestones,
    savePromise,
    signPromise,
    resetPromise,
    addPromiseWallMilestone,
    deletePromiseWallMilestone,
    focusStats,
    portfolioProjects,
    clients,
    incomeStats,
    legacyEntries,
    skills,
    journalEntries,
    promiseReminderModalOpen,
    setPromiseReminderModalOpen,
    anniversaryModalOpen,
    setAnniversaryModalOpen,
  } = useAtlasStore();

  // Mode: if isSigned is false (or user explicitly triggers onboarding), show sacred onboarding
  const [showSacredOnboarding, setShowSacredOnboarding] = useState(
    !promiseState?.isSigned
  );

  // Sync if store changes
  useEffect(() => {
    if (promiseState && !promiseState.isSigned) {
      setShowSacredOnboarding(true);
    }
  }, [promiseState?.isSigned]);

  // Ambient soundscape for sacred room
  const [activeAudio, setActiveAudio] = useState<AmbientTrack>("off");
  useEffect(() => {
    return () => {
      ambientAudioPlayer.stop();
    };
  }, []);

  const toggleAmbientTrack = (track: AmbientTrack) => {
    setActiveAudio(track);
    ambientAudioPlayer.play(track, 0.18);
  };

  // Sacred Onboarding Form State
  const [pText, setPText] = useState(
    promiseState?.promiseText ||
      "I promise that I will show up every single day, build my creative portfolio, and honor the vision I have for my family and my future. I refuse to settle for an ordinary life."
  );
  const [whoForList, setWhoForList] = useState<string[]>(
    promiseState?.whoFor || [
      "Myself",
      "My family",
      "My future children",
      "My dreams",
    ]
  );
  const [customWho, setCustomWho] = useState("");
  const [quitText, setQuitText] = useState(
    promiseState?.whatIfQuit ||
      "I'll remain stuck. I'll never build my business. I'll waste my potential. I'll regret not trying."
  );
  const [consistentText, setConsistentText] = useState(
    promiseState?.whatIfConsistent ||
      "Financial freedom. Creative confidence. Helping my family. Owning my studio. Working with dream clients. Building a meaningful life."
  );
  const [signatureInput, setSignatureInput] = useState(
    promiseState?.signatureName || profile.name || "Gift Safari"
  );
  const todayStr = new Date().toISOString().split("T")[0];

  // Autosave indicator
  const [isAutosaved, setIsAutosaved] = useState(false);
  useEffect(() => {
    if (!showSacredOnboarding) return;
    const timer = setTimeout(() => {
      savePromise({
        promiseText: pText,
        whoFor: whoForList,
        whatIfQuit: quitText,
        whatIfConsistent: consistentText,
        signatureName: signatureInput,
      });
      setIsAutosaved(true);
      setTimeout(() => setIsAutosaved(false), 3000);
    }, 4000);
    return () => clearTimeout(timer);
  }, [pText, whoForList, quitText, consistentText, signatureInput, showSacredOnboarding]);

  // Toggle Who am I doing this for options
  const defaultWhoOptions = [
    "Myself",
    "My family",
    "My future children",
    "My parents",
    "My faith",
    "My dreams",
    "My future business",
    "My future team",
  ];

  const toggleWhoOption = (opt: string) => {
    if (whoForList.includes(opt)) {
      setWhoForList(whoForList.filter((x) => x !== opt));
    } else {
      setWhoForList([...whoForList, opt]);
    }
  };

  const handleAddCustomWho = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customWho.trim()) return;
    if (!whoForList.includes(customWho.trim())) {
      setWhoForList([...whoForList, customWho.trim()]);
    }
    setCustomWho("");
  };

  // Sign My Promise Action
  const handleSignPromise = async () => {
    soundManager.playVictory(profile.soundEnabled);
    await signPromise({
      promiseText: pText,
      whoFor: whoForList,
      whatIfQuit: quitText,
      whatIfConsistent: consistentText,
      signatureName: signatureInput || profile.name || "Gift Safari",
      signedDate: todayStr,
    });
    setShowSacredOnboarding(false);
  };

  // Calculate Days Since Promise
  const calculateDaysSince = (dateStr: string) => {
    if (!dateStr) return 18;
    try {
      const signed = new Date(dateStr).getTime();
      const now = Date.now();
      const diffDays = Math.floor((now - signed) / (1000 * 3600 * 24));
      return Math.max(1, diffDays);
    } catch (e) {
      return 18;
    }
  };

  const daysSincePromise = calculateDaysSince(
    promiseState?.signedDate || "2026-03-01"
  );

  // Calculate Legacy Score
  const meaningfulDays = legacyEntries.filter((x) => x.meaningful).length;
  const legacyScore = Math.min(
    100,
    Math.max(25, Math.round((meaningfulDays / 30) * 100))
  );

  // The Wall Custom Milestone Form
  const [isAddingMilestone, setIsAddingMilestone] = useState(false);
  const [mTitle, setMTitle] = useState("");
  const [mDate, setMDate] = useState(todayStr);
  const [mCat, setMCat] = useState("milestone");

  const handleAddMilestone = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mTitle.trim()) return;
    await addPromiseWallMilestone(
      mTitle.trim(),
      mDate || todayStr,
      mCat || "milestone"
    );
    setMTitle("");
    setIsAddingMilestone(false);
  };

  // Edit promise in room mode
  const [isEditingInRoom, setIsEditingInRoom] = useState(false);
  const [roomText, setRoomText] = useState(promiseState?.promiseText || pText);
  const handleSaveRoomText = async () => {
    await savePromise({ promiseText: roomText });
    setIsEditingInRoom(false);
  };

  // =========================================================
  // SACRED FIRST-LAUNCH ONBOARDING EXPERIENCE
  // =========================================================
  if (showSacredOnboarding) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
        className="relative min-h-screen bg-[#070709] text-zinc-100 p-6 sm:p-12 lg:p-20 select-none overflow-x-hidden"
      >
        {/* Cinematic Slow Particle Background & Soft Light */}
        <div className="fixed inset-0 pointer-events-none z-0">
          <div className="absolute top-1/4 left-1/3 w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-[160px] animate-pulse" />
          <div className="absolute bottom-1/3 right-1/4 w-[600px] h-[600px] bg-purple-500/10 rounded-full blur-[160px] animate-pulse" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-500/5 rounded-full blur-[180px]" />
        </div>

        {/* Ambient Audio Switcher */}
        <div className="relative z-10 flex justify-end mb-8">
          <div className="flex items-center gap-2 bg-zinc-900/60 border border-white/10 rounded-full px-3 py-1.5 backdrop-blur-md">
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-zinc-400 mr-1">
              Sanctuary Acoustics:
            </span>
            {(["rain", "forest", "cafe", "lofi", "ocean", "off"] as const).map(
              (trk) => {
                const labels: Record<string, string> = {
                  rain: "🌧️ Rain",
                  forest: "🌲 Forest",
                  cafe: "☕ Cafe",
                  lofi: "🎧 Lo-fi",
                  ocean: "🌊 Ocean",
                  off: "Off",
                };
                return (
                  <button
                    key={trk}
                    onClick={() => toggleAmbientTrack(trk)}
                    className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition ${
                      activeAudio === trk
                        ? "bg-emerald-500 text-black shadow-md"
                        : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    {labels[trk]}
                  </button>
                );
              }
            )}
          </div>
        </div>

        {/* Main Sacred Envelope */}
        <div className="relative z-10 max-w-4xl mx-auto space-y-16">
          {/* Top Mirror Message */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.3 }}
            className="text-center space-y-6 max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-zinc-300 text-xs font-black uppercase tracking-widest backdrop-blur-md">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>THE PROMISE</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight">
              Before you begin...
            </h1>

            <div className="text-base sm:text-xl font-light text-zinc-300 leading-relaxed space-y-4">
              <p>
                This application cannot build your future.{" "}
                <span className="text-white font-extrabold">Only you can.</span>
              </p>
              <p className="text-zinc-400">
                This is simply a mirror. It reflects the choices you make every single day.
              </p>
              <p className="text-zinc-300">
                Years from now, your future self will either thank you or wish you had started sooner.
              </p>
              <p className="text-emerald-400 font-extrabold italic pt-2">
                "Before entering ATLAS OS, make one promise. Not to this app. To yourself."
              </p>
            </div>
          </motion.div>

          <div className="w-24 h-px bg-white/10 mx-auto" />

          {/* 1. MY PROMISE WRITING AREA */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.5 }}
            className="bg-[#121215]/80 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl backdrop-blur-xl space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div>
                <div className="text-xs font-black uppercase tracking-widest text-emerald-400">
                  Sacred Commitment
                </div>
                <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  My Promise
                </h2>
              </div>
              <div className="text-xs font-mono text-zinc-500">
                {isAutosaved ? (
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Autosaved
                  </span>
                ) : (
                  <span>Unlimited markdown writing</span>
                )}
              </div>
            </div>

            <textarea
              rows={6}
              value={pText}
              onChange={(e) => setPText(e.target.value)}
              placeholder="I promise that..."
              className="w-full bg-black/40 border border-white/10 text-white font-serif text-lg sm:text-xl rounded-2xl p-6 leading-relaxed focus:outline-none focus:border-emerald-500/60 transition whitespace-pre-wrap"
            />
          </motion.div>

          {/* 2. WHY THIS PROMISE MATTERS ("Who am I doing this for?") */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.7 }}
            className="bg-[#121215]/80 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl backdrop-blur-xl space-y-6"
          >
            <div>
              <div className="text-xs font-black uppercase tracking-widest text-blue-400">
                WHY THIS PROMISE MATTERS
              </div>
              <h3 className="text-2xl font-black text-white tracking-tight">
                Who am I doing this for?
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400 mt-1">
                Select multiple choices or add custom answers that anchor your daily consistency.
              </p>
            </div>

            <div className="flex flex-wrap gap-3">
              {defaultWhoOptions.map((opt) => {
                const isSelected = whoForList.includes(opt);
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => toggleWhoOption(opt)}
                    className={`px-5 py-3 rounded-2xl text-sm font-extrabold transition flex items-center gap-2 border ${
                      isSelected
                        ? "bg-emerald-500 text-black border-emerald-400 shadow-lg shadow-emerald-500/20"
                        : "bg-zinc-900/80 text-zinc-300 border-zinc-800 hover:border-zinc-700"
                    }`}
                  >
                    <span>{opt}</span>
                    {isSelected && <Check className="w-4 h-4" />}
                  </button>
                );
              })}

              {/* Display any custom added items not in default */}
              {whoForList
                .filter((x) => !defaultWhoOptions.includes(x))
                .map((customOpt) => (
                  <button
                    key={customOpt}
                    type="button"
                    onClick={() => toggleWhoOption(customOpt)}
                    className="px-5 py-3 rounded-2xl text-sm font-extrabold bg-emerald-500 text-black border border-emerald-400 shadow-lg shadow-emerald-500/20 flex items-center gap-2"
                  >
                    <span>{customOpt}</span>
                    <Check className="w-4 h-4" />
                  </button>
                ))}
            </div>

            {/* Add custom Who form */}
            <form
              onSubmit={handleAddCustomWho}
              className="flex items-center gap-3 pt-2 max-w-md"
            >
              <input
                type="text"
                value={customWho}
                onChange={(e) => setCustomWho(e.target.value)}
                placeholder="Add another answer (e.g. My future team)..."
                className="flex-1 bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:border-emerald-500"
              />
              <button
                type="submit"
                className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-black text-xs"
              >
                + Add
              </button>
            </form>
          </motion.div>

          {/* 3. WHAT HAPPENS IF I QUIT? vs WHAT HAPPENS IF I STAY CONSISTENT? */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* What happens if I quit? */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.2, delay: 0.9 }}
              className="bg-[#121215]/80 border border-red-500/30 rounded-3xl p-8 shadow-2xl backdrop-blur-xl flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div>
                  <div className="text-xs font-black uppercase tracking-widest text-red-400">
                    WHAT HAPPENS IF I QUIT?
                  </div>
                  <h3 className="text-xl font-black text-white tracking-tight">
                    The Cost of Comfort
                  </h3>
                  <p className="text-xs text-zinc-400 mt-1">
                    Never to shame you—its purpose is awareness.
                  </p>
                </div>

                <textarea
                  rows={6}
                  value={quitText}
                  onChange={(e) => setQuitText(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 text-zinc-200 text-sm sm:text-base rounded-2xl p-5 leading-relaxed focus:outline-none focus:border-red-500/60 transition"
                />
              </div>

              <div className="text-[11px] text-zinc-500 mt-4 italic">
                Examples: I'll remain stuck. I'll never build my business. I'll waste my potential. I'll regret not trying.
              </div>
            </motion.div>

            {/* What happens if I stay consistent? */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.2, delay: 1.0 }}
              className="bg-[#121215]/80 border border-emerald-500/30 rounded-3xl p-8 shadow-2xl backdrop-blur-xl flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div>
                  <div className="text-xs font-black uppercase tracking-widest text-emerald-400">
                    WHAT HAPPENS IF I STAY CONSISTENT?
                  </div>
                  <h3 className="text-xl font-black text-white tracking-tight">
                    The Compound Reward
                  </h3>
                  <p className="text-xs text-zinc-400 mt-1">
                    Your long-term upside of daily discipline.
                  </p>
                </div>

                <textarea
                  rows={6}
                  value={consistentText}
                  onChange={(e) => setConsistentText(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 text-zinc-200 text-sm sm:text-base rounded-2xl p-5 leading-relaxed focus:outline-none focus:border-emerald-500/60 transition"
                />
              </div>

              <div className="text-[11px] text-zinc-500 mt-4 italic">
                Examples: Financial freedom. Creative confidence. Helping my family. Owning my studio. Working with dream clients.
              </div>
            </motion.div>
          </div>

          {/* 4. SIGN THE PROMISE DIGITAL SIGNATURE */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 1.1 }}
            className="bg-gradient-to-r from-[#121215] via-[#161a1e] to-[#121215] border-2 border-emerald-500/40 rounded-3xl p-8 sm:p-14 shadow-2xl backdrop-blur-2xl text-center space-y-8"
          >
            <div className="space-y-2">
              <div className="text-xs font-black uppercase tracking-widest text-emerald-400">
                SIGN THE PROMISE
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                Digital Commitment
              </h2>
              <p className="text-sm text-zinc-400">
                Save permanently. Never overwritten unless you explicitly choose to rewrite it.
              </p>
            </div>

            <div className="max-w-md mx-auto space-y-4 text-left">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-400 mb-1.5">
                  Your Signature Name
                </label>
                <input
                  type="text"
                  value={signatureInput}
                  onChange={(e) => setSignatureInput(e.target.value)}
                  placeholder="Gift Safari"
                  className="w-full bg-black/60 border border-white/20 text-white font-serif text-xl rounded-2xl px-5 py-4 focus:outline-none focus:border-emerald-500 text-center tracking-wide"
                />
              </div>

              <div className="flex items-center justify-between text-xs font-mono text-zinc-500 px-2">
                <span>Date Signed: {todayStr}</span>
                <span>Permanent Database Lock</span>
              </div>
            </div>

            <div className="bg-black/30 border border-white/10 rounded-2xl p-6 max-w-xl mx-auto">
              <p className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tight italic">
                "I choose discipline over comfort."
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={handleSignPromise}
                className="group relative inline-flex items-center justify-center px-12 py-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-blue-500 text-black font-black text-base uppercase tracking-widest shadow-[0_15px_40px_rgba(16,185,129,0.45)] hover:shadow-[0_20px_60px_rgba(16,185,129,0.7)] transition duration-300 hover:scale-105 active:scale-98"
              >
                <span>SIGN MY PROMISE</span>
                <ArrowRight className="w-5 h-5 ml-3 transition-transform group-hover:translate-x-1" />
              </button>
            </div>

            <div className="text-[11px] text-zinc-500 uppercase tracking-widest pt-2">
              "The strongest contract you'll ever sign is the one you make with yourself."
            </div>
          </motion.div>
        </div>
      </motion.div>
    );
  }

  // =========================================================
  // THE PROMISE ROOM (`/promise`) - ALWAYS ACCESSIBLE
  // =========================================================
  return (
    <div className="space-y-12 p-4 sm:p-8 max-w-7xl mx-auto relative overflow-hidden select-none">
      {/* Cinematic Ambient Nebula Light Rays */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 right-1/3 w-[600px] h-[600px] bg-gradient-to-br from-emerald-500/10 via-blue-500/10 to-transparent rounded-full blur-[160px]" />
        <div className="absolute bottom-1/4 left-0 w-[500px] h-[500px] bg-gradient-to-tr from-purple-500/10 via-emerald-500/5 to-transparent rounded-full blur-[160px]" />
      </div>

      {/* 1. TOP HEADER & SANCTUARY AUDIO CONTROLS */}
      <div className="relative z-10 bg-[#121215]/90 border border-white/10 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-400 mb-1">
            <Shield className="w-4 h-4" /> THE SACRED COVENANT
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            The Promise
          </h1>
          <p className="text-sm text-zinc-400 mt-1 italic">
            "The strongest contract you'll ever sign is the one you make with yourself."
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Re-experience onboarding button */}
          <button
            onClick={() => setShowSacredOnboarding(true)}
            className="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white text-xs font-bold transition border border-zinc-700 flex items-center gap-1.5"
            title="Re-experience the breathtaking first-launch onboarding"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Sacred Onboarding Mirror</span>
          </button>

          {/* Anniversary Button */}
          <button
            onClick={() => setAnniversaryModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-500/20 to-blue-500/20 hover:from-purple-500/30 hover:to-blue-500/30 text-purple-300 hover:text-white text-xs font-black transition border border-purple-500/30 flex items-center gap-1.5 shadow-md"
          >
            <Award className="w-3.5 h-3.5" />
            <span>Anniversary Reflection</span>
          </button>

          {/* Promise Reminder Trigger */}
          <button
            onClick={() => setPromiseReminderModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-xs font-black transition border border-amber-500/30 flex items-center gap-1.5"
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span>Promise Reminder</span>
          </button>
        </div>
      </div>

      {/* 2. PROMISE STATUS & ENCOURAGEMENT BANNER */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 bg-gradient-to-r from-emerald-500/20 via-emerald-500/10 to-transparent border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-6"
      >
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shrink-0">
            <UserCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {profile.currentStreak > 0
                ? `You have honored your promise for ${daysSincePromise} days.`
                : `You broke your streak, but your promise still stands. Begin again today.`}
            </div>
            <div className="text-xs sm:text-sm text-emerald-300 font-medium mt-1">
              Never use guilt. Always encourage. Every morning is an invitation to execute your identity.
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-2xl font-black text-emerald-400">
              {daysSincePromise} Days
            </div>
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-400">
              Since Signing
            </div>
          </div>
        </div>
      </motion.div>

      {/* 3. CORE METRICS OVERVIEW (PROGRESS SINCE SIGNING) */}
      <div className="relative z-10 grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Current Streak
          </div>
          <div className="text-3xl font-black text-orange-400 flex items-center gap-1.5">
            <Flame className="w-6 h-6 fill-orange-400" />
            {profile.currentStreak} Days
          </div>
          <div className="text-xs text-zinc-500 mt-1">Unbroken momentum</div>
        </div>

        <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Legacy Score
          </div>
          <div className="text-3xl font-black text-purple-400">
            {legacyScore}%
          </div>
          <div className="text-xs text-zinc-500 mt-1">
            Meaningful days ratio
          </div>
        </div>

        <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Focus Since Signing
          </div>
          <div className="text-3xl font-black text-emerald-400">
            {focusStats.totalHours} hrs
          </div>
          <div className="text-xs text-zinc-500 mt-1">Deep work logged</div>
        </div>

        <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Projects & Clients
          </div>
          <div className="text-3xl font-black text-blue-400">
            {portfolioProjects.length} / {clients.length}
          </div>
          <div className="text-xs text-zinc-500 mt-1">Shipped & signed</div>
        </div>
      </div>

      {/* 4. MY PROMISE & MY SIGNATURE ENVELOPE */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 bg-gradient-to-r from-[#121215] via-[#161a1f] to-[#121215] border-2 border-emerald-500/30 rounded-3xl p-8 sm:p-12 shadow-2xl backdrop-blur-xl"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/10 mb-8">
          <div>
            <div className="text-xs font-black uppercase tracking-widest text-emerald-400 flex items-center gap-1.5">
              <Shield className="w-4 h-4" /> Permanent Digital Covenant
            </div>
            <h2 className="text-3xl font-black text-white tracking-tight">
              My Promise
            </h2>
          </div>

          {!isEditingInRoom ? (
            <button
              onClick={() => setIsEditingInRoom(true)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-zinc-700"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Rewrite Promise</span>
            </button>
          ) : (
            <button
              onClick={handleSaveRoomText}
              className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs transition flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Changes</span>
            </button>
          )}
        </div>

        {!isEditingInRoom ? (
          <div className="bg-black/40 border border-white/10 rounded-2xl p-8 font-serif text-xl sm:text-2xl text-zinc-100 leading-relaxed whitespace-pre-wrap italic shadow-inner">
            "{promiseState?.promiseText || pText}"
          </div>
        ) : (
          <textarea
            rows={6}
            value={roomText}
            onChange={(e) => setRoomText(e.target.value)}
            className="w-full bg-black/50 border border-white/20 text-white font-serif text-lg rounded-2xl p-6 leading-relaxed focus:outline-none focus:border-emerald-500"
          />
        )}

        {/* Digital Signature Footer */}
        <div className="mt-8 pt-6 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="text-right sm:text-left">
              <div className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                Digital Signature
              </div>
              <div className="text-2xl font-black text-emerald-400 font-serif tracking-wide">
                {promiseState?.signatureName || "Gift Safari"}
              </div>
            </div>
          </div>

          <div className="text-center sm:text-right">
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-400">
              Date Signed
            </div>
            <div className="text-base font-mono font-bold text-white">
              {promiseState?.signedDate || "2026-03-01"}
            </div>
          </div>
        </div>

        <div className="mt-6 text-center text-sm font-extrabold text-emerald-300 italic">
          "I choose discipline over comfort."
        </div>
      </motion.div>

      {/* 5. THE WALL - CHRONOLOGICAL TIMELINE OF SACRED MILESTONES */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-10 shadow-2xl backdrop-blur-xl"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-800 mb-8">
          <div>
            <div className="text-xs font-black uppercase tracking-widest text-blue-400 flex items-center gap-1.5">
              <History className="w-4 h-4" /> Chronological Milestone Timeline
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              The Wall
            </h2>
            <p className="text-sm text-zinc-400 mt-1">
              The wall tells the story of your journey after signing the promise.
            </p>
          </div>

          <button
            onClick={() => setIsAddingMilestone(!isAddingMilestone)}
            className="px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-black font-extrabold text-xs transition flex items-center gap-2 shadow-lg shadow-blue-600/20"
          >
            <Plus className="w-4 h-4" />
            <span>Add Milestone to Wall</span>
          </button>
        </div>

        {/* Add Milestone Drawer */}
        <AnimatePresence>
          {isAddingMilestone && (
            <motion.form
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              onSubmit={handleAddMilestone}
              className="bg-zinc-900 border border-blue-500/40 rounded-2xl p-5 mb-8 space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Milestone Title
                  </label>
                  <input
                    type="text"
                    required
                    value={mTitle}
                    onChange={(e) => setMTitle(e.target.value)}
                    placeholder="e.g. Mastered After Effects"
                    className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    value={mDate}
                    onChange={(e) => setMDate(e.target.value)}
                    className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase mb-1">
                    Category
                  </label>
                  <select
                    value={mCat}
                    onChange={(e) => setMCat(e.target.value)}
                    className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-blue-500"
                  >
                    <option value="milestone">Milestone</option>
                    <option value="streak">Streak</option>
                    <option value="income">Income</option>
                    <option value="creative">Creative</option>
                    <option value="promise">Promise</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingMilestone(false)}
                  className="px-4 py-2 rounded-xl bg-zinc-800 text-zinc-400 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 text-black font-black text-xs"
                >
                  Add Card to Wall
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>

        {/* The Wall Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {promiseWallMilestones.map((item, idx) => {
            const getBorderColor = (cat: string) => {
              switch (cat) {
                case "promise":
                  return "border-emerald-500/60 bg-emerald-500/5 shadow-emerald-500/10";
                case "streak":
                  return "border-orange-500/50 bg-orange-500/5";
                case "income":
                  return "border-emerald-400/40 bg-emerald-400/5";
                case "creative":
                  return "border-purple-500/50 bg-purple-500/5";
                default:
                  return "border-blue-500/50 bg-blue-500/5";
              }
            };

            return (
              <motion.div
                key={item.id}
                whileHover={{ y: -5 }}
                className={`group rounded-3xl p-6 border transition flex flex-col justify-between shadow-xl relative overflow-hidden ${getBorderColor(
                  item.category
                )}`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-mono font-bold text-zinc-400">
                      {item.date}
                    </span>
                    <span className="px-2.5 py-1 rounded-full bg-black/60 text-[10px] font-extrabold uppercase tracking-wider text-zinc-300">
                      {item.category}
                    </span>
                  </div>

                  <h3 className="text-xl font-black text-white tracking-tight mb-2">
                    {item.title}
                  </h3>
                </div>

                <div className="mt-6 pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs text-zinc-500 font-semibold">
                  <span>Milestone #{idx + 1}</span>
                  <button
                    onClick={() => deletePromiseWallMilestone(item.id)}
                    className="opacity-0 group-hover:opacity-100 text-zinc-500 hover:text-red-400 transition"
                    title="Remove milestone card"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* 6. FINAL MESSAGE QUOTE */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-900 border border-white/10 rounded-3xl p-10 sm:p-14 shadow-2xl text-center space-y-4"
      >
        <div className="w-16 h-1 bg-emerald-500/50 rounded-full mx-auto mb-4" />
        <p className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-snug">
          "The strongest contract you'll ever sign is the one you make with yourself."
        </p>
        <div className="text-xs font-mono text-zinc-500 uppercase tracking-widest pt-2">
          ATLAS OS • YOUR PROMISE IS PERMANENT
        </div>
      </motion.div>

      {/* =========================================================
          PROMISE REMINDER MODAL ("Before continuing... Read your promise")
         ========================================================= */}
      <AnimatePresence>
        {promiseReminderModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl">
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: 15 }}
              className="relative w-full max-w-2xl bg-[#121215] border-2 border-emerald-500/40 rounded-3xl p-8 sm:p-10 shadow-2xl space-y-6 text-left max-h-[90vh] overflow-y-auto"
            >
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase tracking-widest">
                  <AlertCircle className="w-3.5 h-3.5" /> PROMISE REMINDER
                </div>
                <h3 className="text-2xl sm:text-3xl font-black text-white">
                  Before continuing... Read your promise.
                </h3>
                <p className="text-xs text-zinc-400">
                  When momentum fades, revisit the sacred commitment you made to yourself.
                </p>
              </div>

              {/* Display full promise text */}
              <div className="bg-black/50 border border-white/10 rounded-2xl p-6 font-serif text-lg sm:text-xl text-zinc-100 leading-relaxed italic shadow-inner">
                "{promiseState?.promiseText || pText}"
              </div>

              {/* Signature stamp */}
              <div className="flex items-center justify-between text-xs font-mono text-zinc-400 px-2">
                <span>Signed: {promiseState?.signatureName || "Gift Safari"}</span>
                <span>Date: {promiseState?.signedDate || "2026-03-01"}</span>
              </div>

              <div className="pt-2">
                <p className="text-base sm:text-lg font-black text-white mb-4 text-center">
                  Are you ready to continue becoming the person you promised yourself you'd become?
                </p>
                <button
                  onClick={() => setPromiseReminderModalOpen(false)}
                  className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-sm uppercase tracking-widest transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2"
                >
                  <span>Continue the Mission</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================
          ANNIVERSARY REFLECTION MODAL ("One year ago today... You made a promise")
         ========================================================= */}
      <AnimatePresence>
        {anniversaryModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl">
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: 15 }}
              className="relative w-full max-w-3xl bg-gradient-to-br from-[#121215] via-[#1a1624] to-[#121215] border-2 border-purple-500/40 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-8 text-center max-h-[90vh] overflow-y-auto"
            >
              <div className="space-y-3">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-black uppercase tracking-widest">
                  <Award className="w-4 h-4" /> ANNIVERSARY REFLECTION
                </div>
                <h3 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
                  One year ago today...
                </h3>
                <p className="text-lg sm:text-xl font-bold text-emerald-400">
                  You made a promise.
                </p>
              </div>

              <div className="text-sm sm:text-base text-zinc-300 font-medium max-w-xl mx-auto">
                Since then, your consistency and discipline have compounded into extraordinary creative transformation:
              </div>

              {/* Anniversary Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 max-w-2xl mx-auto text-left">
                <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4">
                  <div className="text-xs font-bold uppercase text-zinc-500">
                    Focus Hours
                  </div>
                  <div className="text-2xl font-black text-emerald-400 mt-1">
                    {focusStats.totalHours} hrs
                  </div>
                </div>

                <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4">
                  <div className="text-xs font-bold uppercase text-zinc-500">
                    Portfolio Projects
                  </div>
                  <div className="text-2xl font-black text-purple-400 mt-1">
                    {portfolioProjects.length} Shipped
                  </div>
                </div>

                <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4">
                  <div className="text-xs font-bold uppercase text-zinc-500">
                    Clients Won
                  </div>
                  <div className="text-2xl font-black text-blue-400 mt-1">
                    {clients.length} Clients
                  </div>
                </div>

                <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4">
                  <div className="text-xs font-bold uppercase text-zinc-500">
                    Income Generated
                  </div>
                  <div className="text-2xl font-black text-emerald-300 mt-1">
                    ${incomeStats.totalIncome.toLocaleString()}
                  </div>
                </div>

                <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4">
                  <div className="text-xs font-bold uppercase text-zinc-500">
                    Skills Mastered
                  </div>
                  <div className="text-2xl font-black text-amber-400 mt-1">
                    {skills.length} Skills
                  </div>
                </div>

                <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4">
                  <div className="text-xs font-bold uppercase text-zinc-500">
                    Longest Streak
                  </div>
                  <div className="text-2xl font-black text-orange-400 mt-1">
                    {profile.longestStreak} Days
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 space-y-4">
                <div className="text-2xl sm:text-3xl font-black text-white italic tracking-tight">
                  "Thank you for keeping your word."
                </div>

                <button
                  onClick={() => setAnniversaryModalOpen(false)}
                  className="px-10 py-4 rounded-2xl bg-purple-600 hover:bg-purple-500 text-black font-black text-sm uppercase tracking-widest transition shadow-lg shadow-purple-600/20"
                >
                  Close Reflection
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
