"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Briefcase,
  Plus,
  Trash2,
  DollarSign,
  Calendar,
  Phone,
  Mail,
  Edit2,
  CheckCircle2,
  Filter,
  X,
  Columns,
  LayoutGrid,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";
import { EmptyState } from "@/components/brand/EmptyState";

export function ClientCrmView() {
  const { clients, addClient, updateClient, deleteClient } = useAtlasStore();

  const [viewMode, setViewMode] = useState<"kanban" | "grid">("kanban");
  const [activeFilter, setActiveFilter] = useState("All");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<any | null>(null);
  const [draggedClientId, setDraggedClientId] = useState<number | null>(null);

  // Form State
  const [name, setName] = useState("");
  const [business, setBusiness] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [services, setServices] = useState("");
  const [price, setPrice] = useState("3500");
  const [deadline, setDeadline] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [status, setStatus] = useState("Lead");
  const [notes, setNotes] = useState("");

  const pipelineStages = [
    "Lead",
    "Contacted",
    "Meeting",
    "Proposal Sent",
    "Negotiation",
    "Working",
    "Revision",
    "Completed",
    "Paid",
  ];

  const todayStr = new Date().toISOString().split("T")[0];

  const totalEarnings = clients
    .filter((c) => c.status === "Paid")
    .reduce((acc, c) => acc + (c.price || 0), 0);

  const activeDealsValue = clients
    .filter(
      (c) =>
        c.status === "Working" ||
        c.status === "Negotiation" ||
        c.status === "Proposal Sent" ||
        c.status === "Revision"
    )
    .reduce((acc, c) => acc + (c.price || 0), 0);

  const overdueClients = clients.filter(
    (c) => c.deadline < todayStr && c.status !== "Paid" && c.status !== "Completed"
  );

  const filteredClients =
    activeFilter === "All"
      ? clients
      : clients.filter((c) => c.status === activeFilter);

  const openAddModal = () => {
    setEditingClient(null);
    setName("");
    setBusiness("");
    setPhone("+1 ");
    setEmail("");
    setServices("Brand & UI Design");
    setPrice("3500");
    setDeadline(new Date().toISOString().split("T")[0]);
    setStatus("Lead");
    setNotes("");
    setIsModalOpen(true);
  };

  const openEditModal = (c: any) => {
    setEditingClient(c);
    setName(c.name);
    setBusiness(c.business);
    setPhone(c.phone);
    setEmail(c.email);
    setServices(c.services);
    setPrice(String(c.price));
    setDeadline(c.deadline);
    setStatus(c.status);
    setNotes(c.notes || "");
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      name: name || "New Lead",
      business: business || "Company",
      phone: phone || "+1 000-000-0000",
      email: email || "client@email.com",
      services: services || "Design",
      price: Number(price) || 1000,
      deadline: deadline || "2026-12-31",
      status: status || "Lead",
      notes: notes || "",
    };

    if (editingClient) {
      await updateClient(editingClient.id, data);
    } else {
      await addClient(data);
    }
    setIsModalOpen(false);
  };

  const handleStageChange = async (client: any, newStage: string) => {
    await updateClient(client.id, {
      ...client,
      status: newStage,
    });
  };

  const handleDragStart = (clientId: number) => {
    setDraggedClientId(clientId);
  };

  const handleDrop = async (stage: string) => {
    if (draggedClientId === null) return;
    const client = clients.find((c) => c.id === draggedClientId);
    if (client && client.status !== stage) {
      await handleStageChange(client, stage);
    }
    setDraggedClientId(null);
  };

  const getStatusColor = (s: string) => {
    switch (s) {
      case "Paid":
        return "bg-emerald-500/10 text-emerald-400 border-emerald-500/30";
      case "Working":
      case "Proposal Sent":
        return "bg-blue-500/10 text-blue-400 border-blue-500/30";
      case "Negotiation":
      case "Revision":
        return "bg-purple-500/10 text-purple-400 border-purple-500/30";
      case "Meeting":
        return "bg-amber-500/10 text-amber-400 border-amber-500/30";
      case "Completed":
        return "bg-teal-500/10 text-teal-400 border-teal-500/30";
      default:
        return "bg-zinc-800 text-zinc-400 border-zinc-700";
    }
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header & Earnings Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
              <Briefcase className="w-4 h-4" /> Client Pipeline
            </div>
            <h1 className="text-2xl font-black text-white tracking-tight">
              CRM Overview
            </h1>
            <p className="text-xs text-zinc-400 mt-0.5">
              {clients.length} deals tracked
            </p>
          </div>
          <button
            onClick={openAddModal}
            className="px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition flex items-center gap-1.5 shadow-lg shadow-emerald-600/20"
          >
            <Plus className="w-4 h-4" /> Add Deal
          </button>
        </div>

        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              Total Revenue (Paid)
            </div>
            <div className="text-3xl font-black text-emerald-400 mt-1">
              ${totalEarnings.toLocaleString()}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              Active Pipeline Value
            </div>
            <div className="text-3xl font-black text-blue-400 mt-1">
              ${activeDealsValue.toLocaleString()}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
            <Briefcase className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              Overdue Projects
            </div>
            <div className="text-3xl font-black text-red-400 mt-1">
              {overdueClients.length}
            </div>
            <div className="text-xs text-zinc-500 mt-0.5">
              Requires immediate follow-up
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-red-500/10 text-red-400 flex items-center justify-center">
            <AlertCircle className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* View Switcher & Stage Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* View Switcher: Kanban vs Grid */}
        <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-zinc-900 border border-zinc-800">
          <button
            onClick={() => setViewMode("kanban")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              viewMode === "kanban"
                ? "bg-zinc-800 text-white shadow-sm border border-zinc-700"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <Columns className="w-4 h-4 text-emerald-400" />
            <span>Visual Kanban</span>
          </button>

          <button
            onClick={() => setViewMode("grid")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              viewMode === "grid"
                ? "bg-zinc-800 text-white shadow-sm border border-zinc-700"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <LayoutGrid className="w-4 h-4 text-blue-400" />
            <span>Grid View</span>
          </button>
        </div>

        {/* Stage Pills (in Grid View) */}
        {viewMode === "grid" && (
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {["All", ...pipelineStages].map((stage) => {
              const count =
                stage === "All"
                  ? clients.length
                  : clients.filter((c) => c.status === stage).length;
              const isSelected = activeFilter === stage;
              return (
                <button
                  key={stage}
                  onClick={() => setActiveFilter(stage)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap border ${
                    isSelected
                      ? "bg-zinc-800 text-white border-emerald-500/50"
                      : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white"
                  }`}
                >
                  <span>{stage}</span>
                  <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-zinc-800 text-zinc-500">
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 1. EMPTY STATE IF NO CLIENTS IN DATABASE */}
      {clients.length === 0 ? (
        <EmptyState
          title="No Clients Yet"
          subtitle="The first client changes everything."
          actionLabel="Add Your First Client"
          onAction={openAddModal}
          streak={14}
        />
      ) : viewMode === "kanban" ? (
        <div className="overflow-x-auto pb-4">
          <div className="flex gap-4 min-w-[1500px]">
            {pipelineStages.map((stage) => {
              const stageClients = clients.filter((c) => c.status === stage);
              const stageIndex = pipelineStages.indexOf(stage);

              return (
                <div
                  key={stage}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={() => handleDrop(stage)}
                  className="flex-1 bg-[#121215]/80 border border-zinc-800/80 rounded-3xl p-4 min-w-[260px] flex flex-col justify-between"
                >
                  <div>
                    {/* Column Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-3">
                      <span className="font-extrabold text-sm text-white">
                        {stage}
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-zinc-800 text-xs font-bold text-zinc-400">
                        {stageClients.length}
                      </span>
                    </div>

                    {/* Stage Cards */}
                    <div className="space-y-3">
                      {stageClients.map((client) => {
                        const isOverdue =
                          client.deadline < todayStr &&
                          client.status !== "Paid" &&
                          client.status !== "Completed";

                        return (
                          <div
                            key={client.id}
                            draggable
                            onDragStart={() => handleDragStart(client.id)}
                            className="bg-zinc-900/90 border border-zinc-800 hover:border-zinc-700 rounded-2xl p-3.5 shadow-md transition cursor-grab active:cursor-grabbing space-y-2 group"
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-black text-emerald-400">
                                ${client.price.toLocaleString()}
                              </span>

                              {isOverdue ? (
                                <span className="text-[10px] font-extrabold text-red-400 bg-red-500/10 px-2 py-0.5 rounded-full border border-red-500/30 flex items-center gap-1">
                                  <AlertCircle className="w-3 h-3" /> Overdue
                                </span>
                              ) : (
                                <span className="text-[10px] text-zinc-500 font-mono">
                                  {client.deadline}
                                </span>
                              )}
                            </div>

                            <div className="font-extrabold text-white text-sm">
                              {client.business}
                            </div>
                            <div className="text-xs text-zinc-400 truncate">
                              {client.name} • {client.services}
                            </div>

                            {/* Stage Move Buttons */}
                            <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between text-[11px]">
                              {stageIndex > 0 ? (
                                <button
                                  onClick={() =>
                                    handleStageChange(
                                      client,
                                      pipelineStages[stageIndex - 1]
                                    )
                                  }
                                  className="text-zinc-500 hover:text-white flex items-center gap-1"
                                  title={`Move to ${
                                    pipelineStages[stageIndex - 1]
                                  }`}
                                >
                                  <ArrowLeft className="w-3 h-3" /> Prev
                                </button>
                              ) : (
                                <span />
                              )}

                              <button
                                onClick={() => openEditModal(client)}
                                className="text-zinc-400 hover:text-white font-semibold underline"
                              >
                                Edit
                              </button>

                              {stageIndex < pipelineStages.length - 1 ? (
                                <button
                                  onClick={() =>
                                    handleStageChange(
                                      client,
                                      pipelineStages[stageIndex + 1]
                                    )
                                  }
                                  className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1"
                                  title={`Move to ${
                                    pipelineStages[stageIndex + 1]
                                  }`}
                                >
                                  Next <ArrowRight className="w-3 h-3" />
                                </button>
                              ) : (
                                <span />
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* 2. GRID VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredClients.map((client) => {
            const isOverdue =
              client.deadline < todayStr &&
              client.status !== "Paid" &&
              client.status !== "Completed";

            return (
              <motion.div
                key={client.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 shadow-xl flex flex-col justify-between hover:border-zinc-700 transition group"
              >
                <div>
                  {/* Status Badge & Price */}
                  <div className="flex items-center justify-between mb-4">
                    <select
                      value={client.status}
                      onChange={async (e) => {
                        await updateClient(client.id, {
                          ...client,
                          status: e.target.value,
                        });
                      }}
                      className={`text-xs font-bold px-3 py-1 rounded-full border cursor-pointer focus:outline-none ${getStatusColor(
                        client.status
                      )}`}
                    >
                      {pipelineStages.map((s) => (
                        <option
                          key={s}
                          value={s}
                          className="bg-zinc-900 text-white"
                        >
                          {s}
                        </option>
                      ))}
                    </select>

                    <div className="text-lg font-black text-white">
                      ${client.price.toLocaleString()}
                    </div>
                  </div>

                  {/* Business & Client Name */}
                  <h3 className="text-xl font-extrabold text-white tracking-tight">
                    {client.business}
                  </h3>
                  <div className="text-sm font-medium text-zinc-400 mb-3">
                    {client.name} • {client.services}
                  </div>

                  {/* Deadline & Contact info */}
                  <div className="space-y-1.5 text-xs text-zinc-400 bg-zinc-900/60 border border-zinc-800 rounded-2xl p-3.5 mb-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Deadline: {client.deadline}</span>
                      </div>
                      {isOverdue && (
                        <span className="text-[10px] font-extrabold text-red-400 bg-red-500/10 px-2 py-0.5 rounded-full border border-red-500/30">
                          Overdue
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-blue-400" />
                      <span>{client.phone}</span>
                    </div>
                    <div className="flex items-center gap-2 truncate">
                      <Mail className="w-3.5 h-3.5 text-purple-400" />
                      <span className="truncate">{client.email}</span>
                    </div>
                  </div>

                  {client.notes && (
                    <p className="text-xs text-zinc-400 italic bg-zinc-900/30 p-3 rounded-xl border border-zinc-800/80 mb-4 line-clamp-3">
                      "{client.notes}"
                    </p>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between pt-4 border-t border-zinc-800/80">
                  <button
                    onClick={() => openEditModal(client)}
                    className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold transition flex items-center gap-1.5"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    Edit Deal
                  </button>

                  <button
                    onClick={() => deleteClient(client.id)}
                    className="p-2 text-zinc-500 hover:text-red-400 rounded-xl transition"
                    title="Delete client"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Client Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.form
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleSubmit}
              className="w-full max-w-lg bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <h3 className="text-xl font-extrabold text-white">
                  {editingClient ? "Edit Client Deal" : "Add New Client"}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-zinc-500 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Client Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Marcus Thorne"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Business / Company
                  </label>
                  <input
                    type="text"
                    required
                    value={business}
                    onChange={(e) => setBusiness(e.target.value)}
                    placeholder="Aura Audio Studios"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Phone
                  </label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 (415) 883-9201"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="marcus@aura.co"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Services
                  </label>
                  <input
                    type="text"
                    value={services}
                    onChange={(e) => setServices(e.target.value)}
                    placeholder="Brand & Next.js Website"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Price ($ USD)
                  </label>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="3500"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Deadline (YYYY-MM-DD)
                  </label>
                  <input
                    type="date"
                    value={deadline}
                    onChange={(e) => setDeadline(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                    Pipeline Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-emerald-500"
                  >
                    {pipelineStages.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-400 uppercase mb-1">
                  Notes / Progress
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Feedback meeting notes, wire transfers, Figma handoff..."
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-3 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs"
                >
                  {editingClient ? "Update Client" : "Create Client"}
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
