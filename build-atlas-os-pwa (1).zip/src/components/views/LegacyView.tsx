"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Heart,
  CheckCircle2,
  XCircle,
  Sparkles,
  Calendar,
  Compass,
  BookOpen,
  Award,
  ArrowRight,
  TrendingUp,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";
import { soundManager } from "@/lib/sound";

export function LegacyView() {
  const { legacyEntries, saveLegacyEntry, profile } = useAtlasStore();

  const [reflectionText, setReflectionText] = useState("");
  const [hasAnsweredToday, setHasAnsweredToday] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<boolean | null>(null);

  const todayStr = new Date().toISOString().split("T")[0];
  const existingToday = legacyEntries.find((e) => e.date === todayStr);

  const meaningfulDaysCount = legacyEntries.filter((e) => e.meaningful).length;
  const totalEntries = Math.max(1, legacyEntries.length);
  const legacyScore = Math.round((meaningfulDaysCount / totalEntries) * 100);

  const handleAnswer = async (isMeaningful: boolean) => {
    soundManager.playVictory(profile.soundEnabled);
    setSelectedAnswer(isMeaningful);
    setHasAnsweredToday(true);
    await saveLegacyEntry({
      date: todayStr,
      meaningful: isMeaningful,
      reflection:
        reflectionText ||
        (isMeaningful
          ? "Today moved me closer to the person I promised myself I would become."
          : "Reflecting and adjusting course for tomorrow."),
    });
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-6xl mx-auto">
      {/* 1. EMOTIONALLY POWERFUL CINEMATIC HEADER */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#121215] via-[#1a1622] to-[#121215] border border-white/10 p-8 sm:p-12 shadow-2xl backdrop-blur-2xl text-center sm:text-left"
      >
        <div className="absolute top-0 right-0 w-[450px] h-[450px] bg-gradient-to-br from-emerald-500/15 via-purple-500/15 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-extrabold uppercase tracking-widest">
              <Compass className="w-3.5 h-3.5" /> Identity & Purpose Telemetry
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
              Legacy System
            </h1>

            <p className="text-base text-zinc-300 leading-relaxed">
              "We are what we repeatedly do. Excellence, then, is not an act, but a habit." Measure the emotional and strategic trajectory of your life.
            </p>
          </div>

          {/* Legacy Score Badge */}
          <div className="flex flex-col items-center justify-center bg-zinc-900/80 border border-white/10 rounded-3xl p-6 min-w-[180px] shadow-xl">
            <div className="text-4xl font-black text-emerald-400">
              {legacyScore}%
            </div>
            <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider mt-1">
              Legacy Score
            </div>
            <div className="text-[11px] text-zinc-500 mt-1">
              {meaningfulDaysCount} Meaningful Days
            </div>
          </div>
        </div>
      </motion.div>

      {/* 2. TODAY'S LEGACY QUESTION CARD */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-[#121215] border-2 border-emerald-500/30 rounded-3xl p-8 sm:p-10 shadow-2xl text-center relative overflow-hidden"
      >
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl mx-auto space-y-6">
          <div className="inline-flex items-center gap-2 text-xs font-extrabold uppercase tracking-widest text-emerald-400">
            <Sparkles className="w-4 h-4" /> End of Day Executive Evaluation
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-snug">
            Did today move you closer to the person you want to become?
          </h2>

          <p className="text-sm text-zinc-400">
            Be honest with yourself. This answer forms the moral compass of ATLAS OS.
          </p>

          {/* YES / NO Buttons */}
          <div className="grid grid-cols-2 gap-4 max-w-md mx-auto pt-2">
            <button
              onClick={() => handleAnswer(true)}
              className={`py-5 rounded-2xl font-black text-base transition flex items-center justify-center gap-2 border shadow-xl ${
                existingToday?.meaningful || selectedAnswer === true
                  ? "bg-emerald-500 text-black border-emerald-400 shadow-emerald-500/20"
                  : "bg-zinc-900/90 hover:bg-emerald-500/20 text-white border-zinc-800 hover:border-emerald-500/40"
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>YES</span>
            </button>

            <button
              onClick={() => handleAnswer(false)}
              className={`py-5 rounded-2xl font-black text-base transition flex items-center justify-center gap-2 border shadow-xl ${
                existingToday && !existingToday.meaningful
                  ? "bg-amber-500 text-black border-amber-400"
                  : "bg-zinc-900/90 hover:bg-amber-500/20 text-zinc-300 hover:text-white border-zinc-800 hover:border-amber-500/40"
              }`}
            >
              <XCircle className="w-5 h-5" />
              <span>NO</span>
            </button>
          </div>

          {/* Optional Reflection note input */}
          <div className="pt-2">
            <input
              type="text"
              value={reflectionText}
              onChange={(e) => setReflectionText(e.target.value)}
              placeholder="Optional: Why was today meaningful? What challenged you?"
              className="w-full bg-zinc-900/80 border border-zinc-800 text-white placeholder-zinc-500 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500"
            />
          </div>

          {(existingToday || hasAnsweredToday) && (
            <div className="px-4 py-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-bold text-xs flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4" /> Day logged in your permanent Legacy History.
            </div>
          )}
        </div>
      </motion.div>

      {/* 3. LIFE PROGRESS & REFLECTION CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Life Progress Card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="bg-[#121215] border border-white/10 rounded-3xl p-6 shadow-xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-2">
              <Compass className="w-4 h-4" /> Life Progress
            </div>
            <h3 className="text-xl font-extrabold text-white tracking-tight mb-1">
              30-Day Operation Lock In
            </h3>
            <p className="text-xs text-zinc-400 mb-6">
              You are currently on Day {profile.dayOfChallenge} of your 30-day transformation sprint.
            </p>

            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between text-xs font-extrabold">
                <span className="text-zinc-400">Sprint Completion</span>
                <span className="text-emerald-400 font-mono">
                  {Math.round((profile.dayOfChallenge / 30) * 100)}%
                </span>
              </div>
              <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{
                    width: `${Math.round((profile.dayOfChallenge / 30) * 100)}%`,
                  }}
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-zinc-800/80 text-xs text-zinc-400 flex items-center justify-between font-semibold">
            <span>Streak: {profile.currentStreak} Days</span>
            <span className="text-emerald-400">Momentum Active</span>
          </div>
        </motion.div>

        {/* Monthly Reflection */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[#121215] border border-white/10 rounded-3xl p-6 shadow-xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-400 mb-2">
              <Calendar className="w-4 h-4" /> Monthly Reflection
            </div>
            <h3 className="text-xl font-extrabold text-white tracking-tight mb-1">
              Current Month Review
            </h3>
            <p className="text-xs text-zinc-400 mb-4">
              "What were the 3 highest impact actions you took this month?"
            </p>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 text-xs text-zinc-300 space-y-2">
              <div>• Shipped Veloce Robotics UI & Next.js Website</div>
              <div>• Maintained 14-day alive streak without breaking</div>
              <div>• Expanded Client CRM pipeline to 6 active deals</div>
            </div>
          </div>

          <div className="pt-4 border-t border-zinc-800/80 text-xs text-blue-400 font-bold flex items-center justify-between">
            <span>Monthly Growth: +18%</span>
            <ArrowRight className="w-4 h-4" />
          </div>
        </motion.div>

        {/* Yearly Reflection */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="bg-[#121215] border border-white/10 rounded-3xl p-6 shadow-xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-purple-400 mb-2">
              <Award className="w-4 h-4" /> Yearly Reflection
            </div>
            <h3 className="text-xl font-extrabold text-white tracking-tight mb-1">
              2026 Creative Blueprint
            </h3>
            <p className="text-xs text-zinc-400 mb-4">
              "What is the single legacy you want this year to leave behind?"
            </p>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 text-xs text-zinc-300 space-y-2 italic">
              "To become financially independent through world-class design, motion graphics, and full-stack software engineering."
            </div>
          </div>

          <div className="pt-4 border-t border-zinc-800/80 text-xs text-purple-400 font-bold flex items-center justify-between">
            <span>Target Revenue: $100,000 / yr</span>
            <ArrowRight className="w-4 h-4" />
          </div>
        </motion.div>
      </div>

      {/* 4. PAST LEGACY ARCHIVE LOG */}
      <div className="bg-[#121215] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-zinc-800">
          <h3 className="text-lg font-extrabold text-white">
            Meaningful Days Archive
          </h3>
          <span className="text-xs text-zinc-500">
            {legacyEntries.length} logged entries
          </span>
        </div>

        <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
          {legacyEntries.map((entry) => (
            <div
              key={entry.id}
              className="flex items-center justify-between p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 text-sm"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
                    entry.meaningful
                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                      : "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                  }`}
                >
                  {entry.meaningful ? "YES" : "NO"}
                </div>
                <div>
                  <div className="font-bold text-white">{entry.reflection}</div>
                  <div className="text-xs font-mono text-zinc-500">
                    Date: {entry.date}
                  </div>
                </div>
              </div>
              <span className="text-xs font-bold text-emerald-400">
                Meaningful Day
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
