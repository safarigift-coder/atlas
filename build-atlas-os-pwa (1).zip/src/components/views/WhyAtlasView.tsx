"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Compass,
  Sparkles,
  Shield,
  Award,
  Layers,
  Palette,
  Type,
  Box,
  Share2,
  Download,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Flame,
  Zap,
  Sun,
  Layout,
  BookOpen,
  Coffee,
  ShoppingBag,
  ExternalLink,
} from "lucide-react";
import { AtlasLogo } from "@/components/brand/AtlasLogo";
import { useAtlasStore } from "@/store/atlas-store";

export function WhyAtlasView() {
  const { profile, resetDemoData, resetToEmptyState } = useAtlasStore();

  const [selectedStreakTab, setSelectedStreakTab] = useState<number>(14);
  const [activeSection, setActiveSection] = useState<
    | "story"
    | "evolving"
    | "rules"
    | "colors"
    | "typography"
    | "merch"
    | "system"
    | "voice"
  >("story");
  const [isResetting, setIsResetting] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");

  const handleSetEmptyState = async () => {
    if (
      !confirm(
        "Make the app new without user's data? This will clear all clients, projects, transactions, and journals to showcase the clean empty states."
      )
    )
      return;
    setIsResetting(true);
    await resetToEmptyState();
    setIsResetting(false);
    setStatusMsg("ATLAS OS reset to clean empty state!");
    setTimeout(() => setStatusMsg(""), 4000);
  };

  const handleLoadDemoState = async () => {
    setIsResetting(true);
    await resetDemoData();
    setIsResetting(false);
    setStatusMsg("Loaded rich demo sample data!");
    setTimeout(() => setStatusMsg(""), 4000);
  };

  // Color Palette Definitions
  const colorSystem = [
    {
      name: "Primary Background",
      hex: "#09090B",
      tailwind: "bg-[#09090B] / bg-zinc-950",
      cssVar: "--atlas-bg-primary",
      role: "Main OS viewport canvas",
    },
    {
      name: "Secondary Background",
      hex: "#121215",
      tailwind: "bg-[#121215]",
      cssVar: "--atlas-bg-secondary",
      role: "Card & section container background",
    },
    {
      name: "Surface",
      hex: "#18181B",
      tailwind: "bg-zinc-900",
      cssVar: "--atlas-surface",
      role: "Hover states & interactive surface layers",
    },
    {
      name: "Borders",
      hex: "#27272A",
      tailwind: "border-zinc-800",
      cssVar: "--atlas-border",
      role: "Clean subtle division lines",
    },
    {
      name: "Primary Text",
      hex: "#F4F4F5",
      tailwind: "text-zinc-100",
      cssVar: "--atlas-text-primary",
      role: "Main headings and active labels",
    },
    {
      name: "Secondary Text",
      hex: "#A1A1AA",
      tailwind: "text-zinc-400",
      cssVar: "--atlas-text-secondary",
      role: "Subheadings, descriptions & metadata",
    },
    {
      name: "Muted Text",
      hex: "#71717A",
      tailwind: "text-zinc-500",
      cssVar: "--atlas-text-muted",
      role: "Captions, timestamps & placeholders",
    },
    {
      name: "Accent / Success",
      hex: "#10B981",
      tailwind: "text-emerald-500 / bg-emerald-500",
      cssVar: "--atlas-accent / --atlas-success",
      role: "Primary action buttons, active checks & progress",
    },
    {
      name: "Focus / Information",
      hex: "#3B82F6",
      tailwind: "text-blue-500 / bg-blue-500",
      cssVar: "--atlas-focus",
      role: "Pomodoro focus states & command center highlights",
    },
    {
      name: "Warning / XP",
      hex: "#F59E0B",
      tailwind: "text-amber-500 / bg-amber-500",
      cssVar: "--atlas-warning / --atlas-xp",
      role: "RPG XP badges, level-up gold & cautions",
    },
    {
      name: "Streak Flame",
      hex: "#F97316",
      tailwind: "text-orange-500 / bg-orange-500",
      cssVar: "--atlas-streak",
      role: "Alive streak fire & momentum counters",
    },
    {
      name: "Legacy System",
      hex: "#A855F7",
      tailwind: "text-purple-500 / bg-purple-500",
      cssVar: "--atlas-legacy",
      role: "Identity programming & character rings",
    },
    {
      name: "The Future Room",
      hex: "#06B6D4",
      tailwind: "text-cyan-500 / bg-cyan-500",
      cssVar: "--atlas-futureroom",
      role: "Sanctuary cyan ambient accents",
    },
    {
      name: "Sacred Covenant (Promise)",
      hex: "#10B981",
      tailwind: "text-emerald-400 / border-emerald-400",
      cssVar: "--atlas-promise",
      role: "The Promise signature & milestone wall",
    },
  ];

  // Merchandise Mockups
  const merchItems = [
    {
      title: "ATLAS Obsidian Hardcover Notebook",
      category: "Notebook",
      desc: "Matte black Italian leather with embossed geometric mountain summit logo on center.",
      specs: "192 dotted pages • 120gsm Swiss paper • Ribbon bookmark",
      imageUrl:
        "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Minimalist Heavyweight Hoodie",
      category: "Hoodie",
      desc: "450gsm organic black cotton with subtle tonal embroidered logo on left chest.",
      specs: "100% Organic French Terry • Oversized executive cut",
      imageUrl:
        "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Studio Ceramic Coffee Mug",
      category: "Coffee Mug",
      desc: "Matte obsidian ceramic with emerald green interior glaze and laser-etched summit.",
      specs: "12oz capacity • Double-walled thermal insulation",
      imageUrl:
        "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Acoustic Desk Mouse Pad",
      category: "Mouse Pad",
      desc: "Full-width merino wool felt desk mat with embossed bottom-right logo mark.",
      specs: "900mm x 400mm • Anti-slip rubber base • Sound damping",
      imageUrl:
        "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Chrome Laptop Sticker Pack",
      category: "Laptop Sticker",
      desc: "Die-cut metallic chrome and matte black vinyl stickers for MacBook Pro lids.",
      specs: "Waterproof UV vinyl • Zero-residue adhesive",
      imageUrl:
        "https://images.unsplash.com/photo-1572375992501-4b0892d50c69?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Insulated Obsidian Water Bottle",
      category: "Water Bottle",
      desc: "Double-walled matte black stainless steel bottle with laser-etched summit.",
      specs: "750ml • 24hr cold / 12hr hot • Powder-coated grip",
      imageUrl:
        "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Minimalist Executive T-shirt",
      category: "T-shirt",
      desc: "280gsm heavyweight combed black cotton with subtle logo tab on hem.",
      specs: "Pre-shrunk cotton • Structured collar • Breathable weave",
      imageUrl:
        "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Brushed Metal Business Card",
      category: "Business Card",
      desc: "0.8mm anodized matte black aluminum card with laser-engraved details.",
      specs: "NFC enabled • Laser etched typography • Swiss minimal",
      imageUrl:
        "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Keynote & Presentation Deck",
      category: "Presentation Slides",
      desc: "40-slide Apple Keynote & Figma pitch deck template with dark-mode glassmorphism.",
      specs: "16:9 Retina • Modular components • Auto-layout grids",
      imageUrl:
        "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Official Website Hero Banner",
      category: "Website Hero",
      desc: "Billion-dollar software hero visual with floating evolving logo and ambient glow.",
      specs: "4K Retina asset • Transparent PNG & vector SVG",
      imageUrl:
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Executive Email Signature",
      category: "Email Signature",
      desc: "Minimalist HTML email signature with inline SVG logo and founder credential lockup.",
      specs: "Dark & Light compatible • Responsive mobile table",
      imageUrl:
        "https://images.unsplash.com/photo-1555421689-491a97ff2040?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "ATLAS Social Media Header Suite",
      category: "Social Media Banner",
      desc: "Optimized banners for X (Twitter), LinkedIn, YouTube, and GitHub profiles.",
      specs: "1500x500px • Safe-area aligned • High-contrast vector",
      imageUrl:
        "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80",
    },
  ];

  return (
    <div className="space-y-12 p-4 sm:p-8 max-w-7xl mx-auto select-none pb-20">
      {/* 1. HERO HEADER */}
      <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-400">
            <Compass className="w-4 h-4" /> OFFICIAL BRAND IDENTITY & DESIGN SYSTEM
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            Why Atlas?
          </h1>
          <p className="text-sm sm:text-base font-semibold text-zinc-400 max-w-2xl">
            "A mountain to climb. Progress upward. Direction. Purpose. Strength. Stability. Growth."
          </p>
        </div>

        {/* Clean Slate vs Demo State Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 bg-zinc-900/80 border border-white/10 rounded-2xl p-4">
          <div className="text-xs font-extrabold uppercase tracking-widest text-zinc-400 mr-2">
            Data State:
          </div>

          <button
            onClick={handleSetEmptyState}
            disabled={isResetting}
            className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white text-xs font-extrabold transition border border-zinc-700 flex items-center gap-1.5"
            title="Make the app new without user's data to test empty states"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isResetting ? "animate-spin" : ""}`}
            />
            <span>New (Clean Without Data)</span>
          </button>

          <button
            onClick={handleLoadDemoState}
            disabled={isResetting}
            className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs transition shadow-lg shadow-emerald-500/20 flex items-center gap-1.5"
            title="Load rich demo sample data"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Load Demo Data</span>
          </button>
        </div>
      </div>

      {statusMsg && (
        <div className="px-5 py-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-between">
          <span>{statusMsg}</span>
          <CheckCircle2 className="w-4 h-4" />
        </div>
      )}

      {/* SECTION NAVIGATION TABS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        {[
          { id: "story", label: "🏔️ The Logo Story", icon: Compass },
          { id: "evolving", label: "⚡ The Evolving Logo", icon: Zap },
          { id: "rules", label: "📐 Logo Rules & Usage", icon: Shield },
          { id: "colors", label: "🎨 Color Palette", icon: Palette },
          { id: "typography", label: "Aa Typography", icon: Type },
          { id: "merch", label: "🛍️ Brand Merchandise", icon: ShoppingBag },
          { id: "system", label: "⚙️ Design System", icon: Layout },
          { id: "voice", label: "🗣️ Brand Mentor Voice", icon: Sparkles },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSection(tab.id as any)}
            className={`px-5 py-2.5 rounded-2xl text-xs font-extrabold transition flex items-center gap-2 whitespace-nowrap border ${
              activeSection === tab.id
                ? "bg-zinc-800 text-white border-emerald-500/50 shadow-lg shadow-emerald-500/10"
                : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white"
            }`}
          >
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* 1. THE LOGO STORY & PHILOSOPHY */}
      {(activeSection === "story" || activeSection === "evolving") && (
        <div className="space-y-8">
          <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-emerald-500/10 via-blue-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
              <div className="lg:col-span-8 space-y-6">
                <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-extrabold uppercase tracking-widest">
                  <Compass className="w-3.5 h-3.5" /> BRAND PHILOSOPHY
                </div>

                <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                  Why Atlas? The Mountain, The Climb & The Promise
                </h2>

                <div className="text-base sm:text-lg font-light text-zinc-300 leading-relaxed space-y-4">
                  <p>
                    ATLAS is not a habit tracker. It is a{" "}
                    <span className="text-white font-extrabold">
                      Personal Operating System
                    </span>{" "}
                    designed to help creators become the people they promised themselves they would become.
                  </p>
                  <p>
                    The logo represents a{" "}
                    <span className="text-emerald-400 font-extrabold">
                      mountain peak to climb
                    </span>
                    —symbolizing upward trajectory, purposeful direction, strength, stability, and enduring growth.
                  </p>
                  <p className="text-sm text-zinc-400 italic">
                    "We never explain this directly with popups inside the app. Instead, we communicate it through every animation, every sound, and every visual interaction."
                  </p>
                </div>

                {/* 7 Core Brand Attributes Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                  {[
                    "Discipline",
                    "Creativity",
                    "Progress",
                    "Identity",
                    "Legacy",
                    "Consistency",
                    "Growth",
                  ].map((val) => (
                    <div
                      key={val}
                      className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-3 text-center text-xs font-extrabold text-white uppercase tracking-wider shadow-sm"
                    >
                      ✓ {val}
                    </div>
                  ))}
                </div>
              </div>

              {/* Huge Evolving Logo Showcase (4 cols) */}
              <div className="lg:col-span-4 flex flex-col items-center justify-center bg-zinc-900/60 border border-white/10 rounded-3xl p-8 text-center shadow-xl">
                <AtlasLogo size="hero" variant="evolving" streak={profile.currentStreak} animated />
                <div className="mt-4 text-xs font-black uppercase tracking-widest text-emerald-400">
                  OFFICIAL ATLAS LOGO
                </div>
                <div className="text-xs text-zinc-500 mt-1">
                  Geometric Summit Ascent Mark
                </div>
              </div>
            </div>
          </div>

          {/* 2. THE EVOLVING LOGO SYSTEM SHOWCASE */}
          <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-8">
            <div>
              <div className="text-xs font-black uppercase tracking-widest text-emerald-400 mb-1">
                ONE OF THE DEFINING FEATURES OF ATLAS
              </div>
              <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                The Evolving Logo System
              </h3>
              <p className="text-sm text-zinc-400 mt-1">
                The logo itself never changes shape. Instead, its presentation evolves as your streak and consistency compound over time.
              </p>
            </div>

            {/* Interactive Streak State Selector */}
            <div className="flex flex-wrap items-center gap-2">
              {[
                { days: 1, label: "0-6 Days: Normal", color: "text-zinc-300" },
                { days: 7, label: "7 Days: Soft Glow", color: "text-emerald-400" },
                { days: 30, label: "30 Days: Gold Outline", color: "text-amber-400" },
                { days: 100, label: "100 Days: Shimmer Animation", color: "text-emerald-300" },
                { days: 365, label: "365 Days: Sunrise Gradient", color: "text-orange-400" },
                { days: 1000, label: "1000 Days: Founder Theme", color: "text-yellow-300" },
              ].map((item) => (
                <button
                  key={item.days}
                  onClick={() => setSelectedStreakTab(item.days)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition border ${
                    selectedStreakTab === item.days
                      ? "bg-zinc-800 text-white border-emerald-500/60 shadow-lg shadow-emerald-500/10"
                      : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white"
                  }`}
                >
                  <span className={item.color}>{item.label}</span>
                </button>
              ))}
            </div>

            {/* Live Evolving Logo Preview Card */}
            <div className="bg-zinc-950 border border-white/10 rounded-3xl p-10 flex flex-col sm:flex-row items-center justify-around gap-8 text-center sm:text-left">
              <div className="flex flex-col items-center justify-center p-8 bg-zinc-900/50 rounded-3xl border border-zinc-800 min-w-[240px]">
                <AtlasLogo
                  size="3xl"
                  variant="evolving"
                  streak={selectedStreakTab}
                  animated
                />
                <div className="mt-4 text-xs font-mono font-bold text-zinc-400">
                  STREAK = {selectedStreakTab} DAYS
                </div>
              </div>

              <div className="space-y-3 max-w-xl">
                <div className="text-xs font-extrabold uppercase tracking-wider text-emerald-400">
                  Visual Specifications
                </div>
                <h4 className="text-2xl font-black text-white">
                  {selectedStreakTab >= 1000
                    ? "1000 Day Streak: Special Founder Theme"
                    : selectedStreakTab >= 365
                    ? "365 Day Streak: Sunrise Gradient Orbit"
                    : selectedStreakTab >= 100
                    ? "100 Day Streak: Gentle Shimmer Animation"
                    : selectedStreakTab >= 30
                    ? "30 Day Streak: Thin Gold Outline"
                    : selectedStreakTab >= 7
                    ? "7 Day Streak: Soft Ambient Emerald Glow"
                    : "0-6 Day Streak: Pristine Obsidian Summit"}
                </h4>
                <p className="text-sm text-zinc-300 leading-relaxed">
                  {selectedStreakTab >= 1000
                    ? "A golden aura surrounds the obsidian peak with brushed gold linear gradients—honoring the top 0.01% of creators who have compounded 3 years of unbroken discipline."
                    : selectedStreakTab >= 365
                    ? "A warm sunrise gradient (amber, orange, purple) orbits behind the logo summit, symbolizing a full year of daily renewal."
                    : selectedStreakTab >= 100
                    ? "A subtle light shimmer sweep passes horizontally across the mountain summit every 3 seconds."
                    : selectedStreakTab >= 30
                    ? "A thin 3.5px gold (#F59E0B) outline frame defines the summit edges—celebrating your first full month of discipline."
                    : selectedStreakTab >= 7
                    ? "A soft emerald/cyan drop shadow glow (#10B981) radiates around the mark—your first week of momentum."
                    : "The clean geometric peak in its purest monochrome state."}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. LOGO RULES, SAFE AREA, MINIMUM SIZE & VARIATIONS */}
      {(activeSection === "story" || activeSection === "rules") && (
        <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-8">
          <div>
            <div className="text-xs font-black uppercase tracking-widest text-emerald-400 mb-1">
              BRAND SPECIFICATIONS
            </div>
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Logo Rules, Safe Area & Minimum Size
            </h3>
            <p className="text-sm text-zinc-400 mt-1">
              Guidelines to maintain visual authority across digital and print applications.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Safe Area Rule */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 space-y-4">
              <div className="text-xs font-extrabold uppercase text-emerald-400">
                Safe Area Clearance
              </div>
              <div className="relative h-40 bg-zinc-950 rounded-2xl border border-dashed border-zinc-700 flex items-center justify-center">
                <div className="absolute inset-4 border border-emerald-500/40 rounded-xl flex items-center justify-center">
                  <AtlasLogo size="lg" variant="monochrome" />
                </div>
              </div>
              <p className="text-xs text-zinc-300">
                Always maintain a minimum clearance equal to 50% of the logo height around all edges. Never crowd the mountain summit.
              </p>
            </div>

            {/* Minimum Size Rule */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 space-y-4">
              <div className="text-xs font-extrabold uppercase text-blue-400">
                Minimum Size Threshold
              </div>
              <div className="relative h-40 bg-zinc-950 rounded-2xl border border-zinc-800 flex items-center justify-around">
                <div className="flex flex-col items-center">
                  <AtlasLogo size="sm" variant="white" />
                  <span className="text-[10px] text-zinc-400 mt-2 font-mono">
                    24px (Digital Min)
                  </span>
                </div>
                <div className="flex flex-col items-center">
                  <AtlasLogo size="md" variant="white" />
                  <span className="text-[10px] text-zinc-400 mt-2 font-mono">
                    32px (Optimal)
                  </span>
                </div>
              </div>
              <p className="text-xs text-zinc-300">
                Do not reproduce the logo smaller than 18px on screens or 6mm in print to preserve geometric interior facet contrast.
              </p>
            </div>

            {/* Incorrect Usage */}
            <div className="bg-zinc-900/80 border border-red-500/30 rounded-3xl p-6 space-y-4">
              <div className="text-xs font-extrabold uppercase text-red-400">
                Incorrect Usage
              </div>
              <div className="relative h-40 bg-zinc-950 rounded-2xl border border-zinc-800 flex items-center justify-around">
                <div className="flex flex-col items-center opacity-40 transform rotate-12 scale-x-125">
                  <AtlasLogo size="md" variant="white" />
                  <span className="text-[10px] text-red-400 font-bold mt-2">
                    ✕ Don't Stretch/Rotate
                  </span>
                </div>
                <div className="flex flex-col items-center opacity-40">
                  <AtlasLogo size="md" variant="black" />
                  <span className="text-[10px] text-red-400 font-bold mt-2">
                    ✕ No Black on Dark
                  </span>
                </div>
              </div>
              <p className="text-xs text-zinc-300">
                Never distort proportions, rotate the summit angle, or place the monochrome black mark on dark backgrounds without contrast.
              </p>
            </div>
          </div>

          {/* Icon Variations Grid */}
          <div className="space-y-4 pt-4">
            <h4 className="text-lg font-black text-white">
              Icon Variations & Lockups
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col items-center justify-center text-center space-y-2">
                <AtlasLogo size="lg" variant="white" showText />
                <span className="text-xs font-bold text-zinc-400">
                  Horizontal Lockup
                </span>
              </div>

              <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col items-center justify-center text-center space-y-2">
                <AtlasLogo size="lg" variant="white" />
                <span className="text-xs font-bold text-zinc-400">
                  App Icon / Favicon
                </span>
              </div>

              <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col items-center justify-center text-center space-y-2">
                <AtlasLogo size="lg" variant="monochrome" />
                <span className="text-xs font-bold text-zinc-400">
                  Monochrome Emerald
                </span>
              </div>

              <div className="bg-white text-black rounded-2xl p-4 flex flex-col items-center justify-center text-center space-y-2">
                <AtlasLogo size="lg" variant="black" />
                <span className="text-xs font-bold text-zinc-800">
                  Black on Light Surface
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. COLOR SYSTEM PALETTE TABLE */}
      {(activeSection === "story" || activeSection === "colors") && (
        <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-8">
          <div>
            <div className="text-xs font-black uppercase tracking-widest text-emerald-400 mb-1">
              COLOR SYSTEM
            </div>
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Billion-Dollar Software Palette
            </h3>
            <p className="text-sm text-zinc-400 mt-1">
              Every HEX value, Tailwind utility class, and CSS variable in the ATLAS OS design system.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {colorSystem.map((c) => (
              <div
                key={c.name}
                className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4 flex items-center justify-between shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl border border-white/10 shadow-inner shrink-0"
                    style={{ backgroundColor: c.hex }}
                  />
                  <div>
                    <div className="text-sm font-black text-white">
                      {c.name}
                    </div>
                    <div className="text-xs font-mono font-bold text-emerald-400">
                      {c.hex}
                    </div>
                    <div className="text-[11px] text-zinc-500">{c.role}</div>
                  </div>
                </div>
                <div className="text-right text-[10px] font-mono text-zinc-400">
                  <div>{c.cssVar}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. TYPOGRAPHY & HIERARCHY */}
      {(activeSection === "story" || activeSection === "typography") && (
        <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-8">
          <div>
            <div className="text-xs font-black uppercase tracking-widest text-emerald-400 mb-1">
              TYPOGRAPHY
            </div>
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Swiss Editorial & Technical Clarity
            </h3>
            <p className="text-sm text-zinc-400 mt-1">
              Recommended font pairings: Inter / SF Pro Display for UI hierarchy, JetBrains Mono for telemetry & timers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 space-y-4">
              <div className="text-xs font-extrabold uppercase text-emerald-400">
                Headings & Subheadings
              </div>
              <h1 className="text-4xl font-black text-white tracking-tight">
                H1 Hero Summit (36px–48px)
              </h1>
              <h2 className="text-2xl font-black text-white tracking-tight">
                H2 Section Header (24px–30px)
              </h2>
              <h3 className="text-lg font-bold text-zinc-300">
                H3 Subheading & Card Title (18px)
              </h3>
              <p className="text-sm text-zinc-400 leading-relaxed">
                Body text (14px) uses -apple-system / Inter with balanced line-height for effortless reading across long-form markdown journals.
              </p>
            </div>

            <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 space-y-4">
              <div className="text-xs font-extrabold uppercase text-blue-400">
                Telemetry, Timers & Numbers (Mono)
              </div>
              <div className="text-5xl font-black font-mono text-emerald-400 tracking-tighter">
                00:45:00
              </div>
              <div className="text-2xl font-black font-mono text-amber-400">
                +1,450 XP • LEVEL 14
              </div>
              <div className="text-xs font-mono text-zinc-500 uppercase tracking-widest">
                CAPTIONS & METADATA (10px–12px MONO)
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. BRAND MERCHANDISE MOCKUPS */}
      {(activeSection === "story" || activeSection === "merch") && (
        <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-8">
          <div>
            <div className="text-xs font-black uppercase tracking-widest text-emerald-400 mb-1">
              MERCHANDISE & BRAND ASSETS
            </div>
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Billion-Dollar Software Merchandise System
            </h3>
            <p className="text-sm text-zinc-400 mt-1">
              Branding specifications for Notebook, Hoodie, Coffee Mug, Mouse Pad, Laptop Sticker, Water Bottle, T-shirt, Business Card, Slides, Website Hero, Email Signature, and Social Banner.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {merchItems.map((item, idx) => (
              <motion.div
                key={idx}
                whileHover={{ y: -5 }}
                className="group bg-zinc-900/80 border border-zinc-800 hover:border-emerald-500/40 rounded-3xl overflow-hidden shadow-xl transition flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-56 w-full overflow-hidden bg-zinc-950">
                    <img
                      src={item.imageUrl}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                    />
                    <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-[10px] font-bold text-white uppercase tracking-wider">
                      {item.category}
                    </div>

                    <div className="absolute bottom-3 right-3 px-3 py-1 rounded-full bg-black/80 backdrop-blur-md border border-white/10 flex items-center gap-1.5">
                      <AtlasLogo size="xs" variant="monochrome" />
                      <span className="text-[10px] font-black text-white">
                        ATLAS
                      </span>
                    </div>
                  </div>

                  <div className="p-6">
                    <h4 className="text-lg font-black text-white tracking-tight mb-2 group-hover:text-emerald-400 transition">
                      {item.title}
                    </h4>
                    <p className="text-xs text-zinc-400 leading-relaxed mb-4">
                      {item.desc}
                    </p>
                    <div className="text-[11px] font-mono font-bold text-emerald-400">
                      SPECS: {item.specs}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* 7. DESIGN SYSTEM & BRAND MENTOR VOICE */}
      {(activeSection === "story" || activeSection === "system" || activeSection === "voice") && (
        <div className="bg-[#121215]/90 border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-8">
          <div>
            <div className="text-xs font-black uppercase tracking-widest text-emerald-400 mb-1">
              VOICE & UI DESIGN SYSTEM
            </div>
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              The Mentor Tone & Component System
            </h3>
            <p className="text-sm text-zinc-400 mt-1">
              "Never speak like a teacher or a parent. Never guilt the user. Always speak with calm executive clarity."
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Mentor Voice Rules */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 space-y-4">
              <div className="text-xs font-extrabold uppercase text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> Brand Voice Directives
              </div>

              <div className="space-y-3">
                {[
                  {
                    phrase: "Good morning. Let's build.",
                    note: "Calm executive greeting.",
                  },
                  {
                    phrase: "Keep climbing. Progress is enough.",
                    note: "Encouraging incremental discipline.",
                  },
                  {
                    phrase: "Rest. Tomorrow we climb again.",
                    note: "Honoring recovery without shame.",
                  },
                  {
                    phrase: "You broke your streak, but your promise still stands.",
                    note: "Zero guilt. Begin again today.",
                  },
                ].map((item, i) => (
                  <div
                    key={i}
                    className="p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between"
                  >
                    <span className="font-extrabold text-white text-sm">
                      "{item.phrase}"
                    </span>
                    <span className="text-[11px] text-zinc-500 font-mono">
                      {item.note}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Micro Branding & Component Token System */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 space-y-4">
              <div className="text-xs font-extrabold uppercase text-blue-400">
                Design System Tokens
              </div>
              <div className="text-xs text-zinc-300 space-y-2">
                <div>
                  • <span className="font-bold text-white">Spacing:</span> 8px grid (p-4, p-6, p-8, p-12)
                </div>
                <div>
                  • <span className="font-bold text-white">Border Radius:</span> Rounded-2xl (16px) for cards, rounded-3xl (24px) for containers
                </div>
                <div>
                  • <span className="font-bold text-white">Buttons:</span> Premium emerald gradient with subtle glow shadow
                </div>
                <div>
                  • <span className="font-bold text-white">Micro Branding:</span> Subtle `<AtlasLogo size="xs" />` watermark on exports, PDFs, and certificates
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
