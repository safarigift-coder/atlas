"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Calendar as CalendarIcon,
  Timer,
  DollarSign,
  Palette,
  BookOpen,
  X,
  Flame,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";

export function CalendarView() {
  const { calendarDays, journalEntries } = useAtlasStore();
  const [selectedDay, setSelectedDay] = useState<any | null>(null);

  const getStatusBg = (status: string) => {
    switch (status) {
      case "Green":
        return "bg-emerald-500/10 border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/20";
      case "Yellow":
        return "bg-amber-500/10 border-amber-500/40 text-amber-400 hover:bg-amber-500/20";
      case "Red":
        return "bg-red-500/10 border-red-500/40 text-red-400 hover:bg-red-500/20";
      default:
        return "bg-zinc-900 border-zinc-800 text-zinc-500 hover:bg-zinc-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Green":
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case "Yellow":
        return <HelpCircle className="w-4 h-4 text-amber-400" />;
      case "Red":
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      default:
        return null;
    }
  };

  const getDayJournal = (dateStr: string) => {
    return (
      journalEntries.find((j) => j.date === dateStr) || {
        contentMarkdown: "No markdown journal recorded for this date.",
        qCompleted: "",
        qChallenged: "",
        qLearned: "",
        qGrateful: "",
        qTomorrow: "",
      }
    );
  };

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-6xl mx-auto">
      {/* Header Bar */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
            <CalendarIcon className="w-4 h-4" /> 30-Day Discipline Map
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Color-Coded Consistency Calendar
          </h1>
          <p className="text-sm text-zinc-400 mt-1">
            "Never miss two days in a row." Click any day to inspect focus hours, income, projects, and journal reflection.
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-xs font-bold">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-3 h-3 rounded-full bg-emerald-500" /> Complete
          </span>
          <span className="flex items-center gap-1.5 text-amber-400">
            <span className="w-3 h-3 rounded-full bg-amber-500" /> Partial
          </span>
          <span className="flex items-center gap-1.5 text-red-400">
            <span className="w-3 h-3 rounded-full bg-red-500" /> Missed
          </span>
        </div>
      </div>

      {/* 30 Days Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-7 gap-3">
        {calendarDays.map((day) => {
          return (
            <motion.button
              key={day.id}
              onClick={() => setSelectedDay(day)}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
              className={`p-4 rounded-2xl border text-left flex flex-col justify-between transition shadow-md h-32 ${getStatusBg(
                day.status
              )}`}
            >
              <div className="flex items-center justify-between w-full">
                <span className="text-xs font-mono font-bold text-zinc-300">
                  {day.date.slice(5)}
                </span>
                {getStatusIcon(day.status)}
              </div>

              <div>
                <div className="text-base font-extrabold text-white">
                  {day.hoursFocused}h
                </div>
                <div className="text-[11px] text-zinc-400 truncate">
                  {day.mood}
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] text-zinc-400 pt-1 border-t border-zinc-800/40">
                <span>🎨 {day.projectsCompleted}</span>
                <span>${day.incomeEarned}</span>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Day Details Slide-Over / Modal */}
      <AnimatePresence>
        {selectedDay && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="w-full max-w-xl bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 max-h-[85vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                <div>
                  <div className="text-xs font-bold uppercase tracking-widest text-emerald-400">
                    Day Reflection details
                  </div>
                  <h3 className="text-2xl font-black text-white">
                    {selectedDay.date}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedDay(null)}
                  className="p-1 text-zinc-500 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* 4 Stats Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-3 text-center">
                  <div className="text-xs text-zinc-500 uppercase">Hours</div>
                  <div className="text-lg font-black text-emerald-400 mt-0.5">
                    {selectedDay.hoursFocused} hrs
                  </div>
                </div>
                <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-3 text-center">
                  <div className="text-xs text-zinc-500 uppercase">Mood</div>
                  <div className="text-sm font-extrabold text-white mt-0.5 truncate">
                    {selectedDay.mood}
                  </div>
                </div>
                <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-3 text-center">
                  <div className="text-xs text-zinc-500 uppercase">Projects</div>
                  <div className="text-lg font-black text-purple-400 mt-0.5">
                    {selectedDay.projectsCompleted}
                  </div>
                </div>
                <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-3 text-center">
                  <div className="text-xs text-zinc-500 uppercase">Income</div>
                  <div className="text-lg font-black text-blue-400 mt-0.5">
                    ${selectedDay.incomeEarned}
                  </div>
                </div>
              </div>

              {/* Journal Section */}
              <div className="space-y-4">
                <div className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-emerald-400" />
                  <span>Daily Journal Entry</span>
                </div>

                <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 text-sm text-zinc-300 leading-relaxed whitespace-pre-wrap font-sans">
                  {getDayJournal(selectedDay.date).contentMarkdown}
                </div>

                {selectedDay.notes && (
                  <div className="text-xs text-zinc-400 italic bg-zinc-900/40 p-3 rounded-xl border border-zinc-800">
                    Day Note: "{selectedDay.notes}"
                  </div>
                )}
              </div>

              <div className="flex justify-end pt-4 border-t border-zinc-800">
                <button
                  onClick={() => setSelectedDay(null)}
                  className="px-6 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs"
                >
                  Close Reflection
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
