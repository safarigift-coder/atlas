"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  BarChart3,
  Flame,
  Award,
  Timer,
  DollarSign,
  Palette,
  Globe,
  Briefcase,
  TrendingUp,
  Calendar,
  CheckCircle2,
} from "lucide-react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useAtlasStore } from "@/store/atlas-store";

export function AnalyticsView() {
  const {
    profile,
    focusStats,
    incomeStats,
    portfolioStats,
    clients,
    dailyMissions,
    calendarDays,
  } = useAtlasStore();

  const [reviewTab, setReviewTab] = useState<"Weekly" | "Monthly" | "Yearly">(
    "Weekly"
  );

  const missionsCompleted = dailyMissions.filter((m) => m.completed).length;
  const missionsTotal = dailyMissions.length;
  const completionPercent =
    missionsTotal > 0
      ? Math.round((missionsCompleted / missionsTotal) * 100)
      : 85;

  const paidClientsCount = clients.filter((c) => c.status === "Paid").length;

  // Review charts data
  const weeklyData = [
    { name: "Mon", hours: 2.5, output: 80 },
    { name: "Tue", hours: 3.8, output: 95 },
    { name: "Wed", hours: 1.5, output: 60 },
    { name: "Thu", hours: 4.2, output: 100 },
    { name: "Fri", hours: 3.0, output: 85 },
    { name: "Sat", hours: 5.0, output: 100 },
    { name: "Sun", hours: 2.8, output: 90 },
  ];

  const monthlyData = [
    { name: "Week 1", hours: 16.5, output: 82 },
    { name: "Week 2", hours: 19.0, output: 91 },
    { name: "Week 3", hours: 14.8, output: 78 },
    { name: "Week 4", hours: 21.2, output: 96 },
  ];

  const yearlyData = [
    { name: "Q1", hours: 140, output: 85 },
    { name: "Q2", hours: 175, output: 92 },
    { name: "Q3", hours: 190, output: 94 },
    { name: "Q4", hours: 210, output: 98 },
  ];

  const activeChartData =
    reviewTab === "Weekly"
      ? weeklyData
      : reviewTab === "Monthly"
      ? monthlyData
      : yearlyData;

  // Github style heatmap from last 30 days
  const heatmapDays = calendarDays.slice(0, 30).reverse();

  return (
    <div className="space-y-8 p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header Bar */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-400 mb-1">
          <BarChart3 className="w-4 h-4" /> Comprehensive Telemetry
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          Creative OS Analytics & Insights
        </h1>
        <p className="text-sm text-zinc-400 mt-1">
          Quantitative tracking of discipline, focus hours, income, and creative shipping velocity.
        </p>
      </div>

      {/* 11 Key Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {/* 1. Current Streak */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Current Streak
          </div>
          <div className="text-3xl font-black text-orange-400 flex items-center gap-1.5">
            <Flame className="w-6 h-6 fill-orange-400" />
            {profile.currentStreak} Days
          </div>
          <div className="mt-1 text-xs text-zinc-500">Unbroken momentum</div>
        </div>

        {/* 2. Longest Streak */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Longest Streak
          </div>
          <div className="text-3xl font-black text-white">
            {profile.longestStreak} Days
          </div>
          <div className="mt-1 text-xs text-zinc-500">All-time record</div>
        </div>

        {/* 3. Completion % */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Completion %
          </div>
          <div className="text-3xl font-black text-emerald-400">
            {completionPercent}%
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            Today's mission checklist
          </div>
        </div>

        {/* 4. Most Productive Day */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Most Productive Day
          </div>
          <div className="text-2xl font-black text-purple-400">Saturday</div>
          <div className="mt-1 text-xs text-zinc-500">
            Avg 5.0h focus logged
          </div>
        </div>

        {/* 5. Best Week */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Best Week
          </div>
          <div className="text-2xl font-black text-blue-400">21.2 Hours</div>
          <div className="mt-1 text-xs text-zinc-500">
            Week 4 • 96% completion
          </div>
        </div>

        {/* 6. Best Month */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Best Month
          </div>
          <div className="text-2xl font-black text-emerald-400">
            July ($7,200)
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            Highest revenue month
          </div>
        </div>

        {/* 7. Hours Worked */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Total Hours Worked
          </div>
          <div className="text-3xl font-black text-white">
            {focusStats.totalHours} hrs
          </div>
          <div className="mt-1 text-xs text-zinc-500">Deep work focus</div>
        </div>

        {/* 8. Designs Created */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Designs Created
          </div>
          <div className="text-3xl font-black text-purple-400">54</div>
          <div className="mt-1 text-xs text-zinc-500">
            UI kits, logos & motion
          </div>
        </div>

        {/* 9. Websites Built */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Websites Built
          </div>
          <div className="text-3xl font-black text-emerald-400">
            {portfolioStats.websitesBuilt}
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            Next.js & Tailwind sites
          </div>
        </div>

        {/* 10. Clients Won */}
        <div className="bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Clients Won
          </div>
          <div className="text-3xl font-black text-blue-400">
            {paidClientsCount || 4}
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            {clients.length} total in pipeline
          </div>
        </div>

        {/* 11. Total Income */}
        <div className="col-span-2 sm:col-span-1 lg:col-span-2 bg-[#121215] border border-zinc-800 rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            All-Time Tracked Income
          </div>
          <div className="text-3xl font-black text-emerald-400">
            ${incomeStats.totalIncome.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            Avg Project: ${incomeStats.avgProjectValue.toLocaleString()}
          </div>
        </div>
      </div>

      {/* GitHub-Style 30-Day Activity Heatmap */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-zinc-800">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-emerald-400">
              Consistency Heatmap
            </div>
            <h3 className="text-xl font-extrabold text-white">
              30-Day Discipline & Output Grid
            </h3>
          </div>
          <div className="flex items-center gap-2 text-xs font-semibold text-zinc-400">
            <span>Less</span>
            <span className="w-3 h-3 rounded bg-zinc-800 border border-zinc-700" />
            <span className="w-3 h-3 rounded bg-emerald-900 border border-emerald-800" />
            <span className="w-3 h-3 rounded bg-emerald-600" />
            <span className="w-3 h-3 rounded bg-emerald-400" />
            <span>More</span>
          </div>
        </div>

        <div className="grid grid-cols-6 sm:grid-cols-10 md:grid-cols-15 gap-2">
          {heatmapDays.map((day) => {
            const level =
              day.hoursFocused >= 4
                ? "bg-emerald-400 text-black border-emerald-300"
                : day.hoursFocused >= 2.5
                ? "bg-emerald-600 text-white border-emerald-500"
                : day.hoursFocused > 0
                ? "bg-emerald-900/80 text-emerald-300 border-emerald-800"
                : "bg-zinc-900 text-zinc-600 border-zinc-800";

            return (
              <div
                key={day.id}
                title={`${day.date}: ${day.hoursFocused}h focused • ${day.mood}`}
                className={`p-2.5 rounded-xl border flex flex-col items-center justify-center text-center transition hover:scale-110 cursor-pointer ${level}`}
              >
                <span className="text-[10px] font-mono font-bold">
                  {day.date.slice(5)}
                </span>
                <span className="text-xs font-black">{day.hoursFocused}h</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recharts Review Charts with Tabs */}
      <div className="bg-[#121215] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-emerald-400">
              Timeframe Reviews
            </div>
            <h3 className="text-xl font-extrabold text-white">
              {reviewTab} Discipline & Focus Output
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {(["Weekly", "Monthly", "Yearly"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setReviewTab(t)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition border ${
                  reviewTab === t
                    ? "bg-zinc-800 text-white border-emerald-500/50 shadow-sm"
                    : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white"
                }`}
              >
                {t} Review
              </button>
            ))}
          </div>
        </div>

        <div className="w-full h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={activeChartData}
              margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
            >
              <defs>
                <linearGradient
                  id="analyticsGrad"
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="name"
                stroke="#52525B"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="#52525B"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#18181B",
                  border: "1px solid #27272A",
                  borderRadius: "12px",
                  color: "#fff",
                }}
              />
              <Area
                type="monotone"
                dataKey="hours"
                name="Focus Hours"
                stroke="#10B981"
                strokeWidth={3}
                fillOpacity={1}
                fill="url(#analyticsGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
