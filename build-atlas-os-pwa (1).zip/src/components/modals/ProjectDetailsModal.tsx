"use client";

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ExternalLink,
  Globe,
  X,
  Calendar,
  Layers,
  CheckCircle2,
  Briefcase,
  Share2,
} from "lucide-react";
import { useAtlasStore } from "@/store/atlas-store";

export function ProjectDetailsModal() {
  const {
    projectModalOpen,
    setProjectModalOpen,
    selectedProject,
  } = useAtlasStore();

  if (!projectModalOpen || !selectedProject) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 15 }}
          className="relative w-full max-w-3xl bg-[#121215] border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col"
        >
          {/* Top Hero Image */}
          <div className="relative h-64 sm:h-80 w-full bg-zinc-900 overflow-hidden shrink-0">
            <img
              src={selectedProject.thumbnail}
              alt={selectedProject.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#121215] via-transparent to-transparent" />

            <button
              onClick={() => setProjectModalOpen(false)}
              className="absolute top-4 right-4 p-2.5 rounded-full bg-black/70 hover:bg-black text-zinc-300 hover:text-white border border-white/10 backdrop-blur-md transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between">
              <span className="px-3.5 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-white/10 text-xs font-bold text-emerald-400 uppercase tracking-wider">
                {selectedProject.category}
              </span>

              <span className="px-3 py-1 rounded-full bg-emerald-500 text-black text-xs font-extrabold flex items-center gap-1.5 shadow-lg">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {selectedProject.status}
              </span>
            </div>
          </div>

          {/* Modal Content Body */}
          <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
            <div>
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                {selectedProject.title}
              </h2>
              <div className="flex flex-wrap items-center gap-4 text-xs text-zinc-400 mt-2">
                <span className="flex items-center gap-1.5 font-semibold text-zinc-300">
                  <Briefcase className="w-3.5 h-3.5 text-blue-400" />
                  Client: {selectedProject.client}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                  Completed: {selectedProject.completionDate}
                </span>
              </div>
            </div>

            {/* Case Study Description */}
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                Case Study & Creative Overview
              </h4>
              <p className="text-sm text-zinc-300 leading-relaxed whitespace-pre-wrap">
                {selectedProject.description}
              </p>
            </div>

            {/* Tools & Tech Stack */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-2.5">
                Tools & Technologies Used
              </h4>
              <div className="flex flex-wrap gap-2">
                {selectedProject.toolsUsed
                  .split(",")
                  .map((tool: string, idx: number) => (
                    <span
                      key={idx}
                      className="px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-bold text-zinc-200"
                    >
                      {tool.trim()}
                    </span>
                  ))}
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="p-5 sm:px-8 border-t border-zinc-800/80 bg-zinc-900/40 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <a
                href={selectedProject.behanceLink}
                target="_blank"
                rel="noreferrer"
                className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs transition flex items-center justify-center gap-2 border border-zinc-700/60"
              >
                <span>View on Behance</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href={selectedProject.liveWebsite}
                target="_blank"
                rel="noreferrer"
                className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-black font-extrabold text-xs transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
              >
                <Globe className="w-4 h-4" />
                <span>Visit Live Site</span>
              </a>
            </div>

            <button
              onClick={() => setProjectModalOpen(false)}
              className="px-6 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white font-semibold text-xs transition"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
